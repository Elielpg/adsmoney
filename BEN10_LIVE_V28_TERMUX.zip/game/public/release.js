export const BUILD_ID='28.0.0';
export const BUILD_LABEL='Ben 10 · Estrada Infinita LIVE · 28.0.0';
