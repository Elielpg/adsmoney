import {FORM_IDS} from './transformations.js';
import {SPEAKERS} from './characters.js';
import {CITIES,CITY_LENGTH,cityForDistance,nextCityDistance} from './traversal.js';
import {MISSION_KINDS,offersForCity} from './mission-catalog.js';
import {DEFAULT_GIFT_RULES,normalizeGiftRules,ruleActionLabel} from './audience.js';

const $=id=>document.getElementById(id);
const element=(tag,text,className)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;};
const metres=value=>Math.max(0,Math.floor(Number(value)||0)).toLocaleString('pt-BR')+' m';

/** The journey controls use the same server actions as chat and live events. */
export function createJourneyUI({api,onAdventure=()=>{},onConfig=()=>{},onError=()=>{}}){
 let current=null,config={},draft=[],boardKey='',saving=false,selectedCity='';
 function open(tab='missions'){
  for(const button of $('tabs').children){const selected=button.dataset.tab===tab;button.classList.toggle('selected',selected);$('tab-'+button.dataset.tab).hidden=!selected;}
  if(!$('panel').open)$('panel').showModal();
 }
 function renderRoute(distance){
  const z=Math.max(0,Number(distance)||0),city=cityForDistance(z),index=CITIES.findIndex(item=>item.id===city.id),within=z%CITY_LENGTH;
  $('route-city').textContent=city.name;
  $('route-distance').textContent=metres(z);
  $('route-progress').value=within;
  $('route-next').textContent='Próxima: '+CITIES[(index+1)%CITIES.length].name+' · '+metres(CITY_LENGTH-within);
 }
 async function mission(selection){
  try{const next=await api('adventure',{action:'mission',...selection});onAdventure(next);sync(next);}catch(error){onError(error);}
 }
 function renderBoard(state){
  const q=state.quest,active=q?.status==='active',generating=state.missionState?.status==='generating';
  const city=CITIES.find(item=>item.id===(selectedCity||state.city))||CITIES[0],remote=city.id!==state.city;
  const offers=selectedCity?offersForCity(selectedCity):state.offers||[];
  $('mission-city-label').textContent=city.name+' · '+(state.completedByCity?.[city.id]||0)+' concluídas';
  $('journey-total').textContent=String(state.completed||0);
  $('journey-active').textContent=active?q.title:generating?'Criando um novo pedido…':'Escolha um pedido ou deixe os NPCs chamarem você.';
  $('journey-instruction').textContent=active?(q.goal?.label||q.objectiveHint||MISSION_KINDS[q.kind]?.instruction||''):'Cada cidade oferece resgates, escoltas, entregas, corridas, reparos, incêndios, defesa e busca.';
  $('cancel-mission').hidden=!active;
  const key=JSON.stringify([state.city,selectedCity,active,!!generating,offers,state.history]);if(key===boardKey){renderTravelDistances(state.worldDistance??state.position?.[2]);return;}boardKey=key;
  $('mission-offers').replaceChildren(...offers.map(offer=>{
   const card=element('article',undefined,'mission-card');
   const top=element('div',undefined,'mission-card-top');top.append(element('small',MISSION_KINDS[offer.kind]?.name||offer.kind),element('span',SPEAKERS[offer.form]?.name||offer.form));
   const title=element('h4',offer.title.split(' · ')[0]);
   const description=element('p',offer.request);
   const meta=element('p',offer.npc+' · '+(offer.instruction||MISSION_KINDS[offer.kind]?.instruction||''),'mission-meta');
   const travel=element('p',undefined,'mission-travel-distance');travel.dataset.city=offer.city;
   const acceptLabel=remote?'Viajar e aceitar →':'Aceitar pedido →';
   const button=element('button',active?'Conclua ou encerre o pedido atual':acceptLabel);button.type='button';button.disabled=active||generating;
   button.onclick=async()=>{button.disabled=true;button.textContent='Aceitando…';await mission({missionKey:offer.key});if(!current?.quest||current.quest.status!=='active'){button.disabled=false;button.textContent=acceptLabel;}};
   card.append(top,title,description,meta,travel,button);return card;
  }));
  renderTravelDistances(state.worldDistance??state.position?.[2]);
  $('mission-history').replaceChildren(...(state.history||[]).map(item=>element('li',(MISSION_KINDS[item.kind]?.name||'Missão')+' · '+item.title)));
  $('mission-history-empty').hidden=!!state.history?.length;
 }
 function sync(state){current=state;renderRoute(state.worldDistance??state.position?.[2]);renderBoard(state);}
 function renderTravelDistances(distance){const z=Math.max(0,Number(distance)||0);for(const node of $('mission-offers').querySelectorAll('.mission-travel-distance'))node.textContent='Trajeto estimado: '+metres(nextCityDistance(z,node.dataset.city)+34-z)+' à frente';}
 function worldStatus(status){const distance=status.worldDistance??status.distance??status.position?.[2];if(Number.isFinite(distance)){renderRoute(distance);renderTravelDistances(distance);}}

 function field(label,node){const wrapper=element('label',label);wrapper.append(node);return wrapper;}
 function renderGiftEditor(){
  $('gift-editor').replaceChildren(...draft.map((rule,index)=>{
   const row=element('div',undefined,'gift-rule-card');
   const head=element('div',undefined,'gift-rule-head');head.append(element('strong','Presente '+(index+1)));
   const remove=element('button','Remover');remove.type='button';remove.onclick=()=>{draft.splice(index,1);renderGiftEditor();};head.append(remove);
   const grid=element('div',undefined,'gift-rule-grid');
   const name=element('input');name.value=rule.name;name.maxLength=80;name.placeholder='Nome do presente no TikTok';name.oninput=()=>rule.name=name.value;
   const form=element('select');for(const id of FORM_IDS){const option=element('option',SPEAKERS[id].name);option.value=id;form.append(option);}form.value=rule.action;
   const points=element('input');points.type='number';points.min='0';points.max='10000';points.step='1';points.value=rule.points;points.oninput=()=>rule.points=Number(points.value);
   const power=element('input');power.type='checkbox';power.checked=!!rule.power;power.onchange=()=>rule.power=power.checked;
   const powerLabel=field('Usar o poder após transformar',power);powerLabel.className='gift-power';
   const move=element('select');
   function movementOptions(){move.replaceChildren();for(const [id,title] of [['','Sem movimento extra'],['run','Correr'],['dash','Dash do XLR8'],['fly','Voar']]){if(id==='dash'&&rule.action!=='volt'||id==='fly'&&!['blaze','shade','nova'].includes(rule.action))continue;const option=element('option',title);option.value=id;move.append(option);}move.value=rule.movement||'';if(!move.value)delete rule.movement;}
   form.onchange=()=>{rule.action=form.value;movementOptions();};movementOptions();move.onchange=()=>{if(move.value)rule.movement=move.value;else delete rule.movement;};
   grid.append(field('Nome exato',name),field('Transformação',form),field('Pontos por unidade',points),field('Movimento',move));row.append(head,grid,powerLabel);
   return row;
  }));
 }
 function setConfig(value){config=value;draft=(value.giftRules||[]).map(rule=>({...rule}));renderGiftEditor();$('gift-editor-message').textContent='As regras abaixo são usadas nos eventos reais e no teste DEMO.';}
 $('add-gift-rule').onclick=()=>{if(draft.length>=50)return;draft.push({name:'',points:10,action:'base',power:true});renderGiftEditor();};
 $('suggest-gift-rules').onclick=()=>{draft=DEFAULT_GIFT_RULES.map(rule=>({...rule}));renderGiftEditor();$('gift-editor-message').textContent='Sugestões carregadas para revisão. Toque em Salvar presentes para aplicá-las.';};
 $('save-gift-editor').onclick=async()=>{
  if(saving)return;saving=true;$('save-gift-editor').disabled=true;
  try{const rules=normalizeGiftRules(draft);const result=await api('config',{giftRules:rules});config=result;draft=result.giftRules.map(rule=>({...rule}));$('rules').value=JSON.stringify(result.giftRules,null,2);onConfig(result);renderGiftEditor();$('gift-editor-message').textContent='Presentes salvos. Cada evento entra na fila de ações.';}catch(error){$('gift-editor-message').textContent=error.message;onError(error);}finally{saving=false;$('save-gift-editor').disabled=false;}
 };
 function setGiftActions(state){
  const active=state?.active,waiting=state?.waiting||state?.items||[];
  const node=$('gift-action-status');node.hidden=!active&&!waiting.length;
  if(active){const event=active.event||active,action={...event,action:event.form||event.action};node.replaceChildren(element('strong','🎁 '+(event.user||'Público')+' · '+(event.count>1?event.count+'× ':'')+(event.gift||event.name||'presente')+(waiting.length?' · +'+waiting.length+' na fila':'')),element('span',(active.label||ruleActionLabel(action))+' · '+(active.status||'Preparando ação')));}
  else node.textContent='🎁 '+waiting.length+' ações de presentes aguardando';
 }
 $('open-missions').onclick=()=>open('missions');
 $('cancel-mission').onclick=async()=>{try{const state=await api('adventure',{action:'cancel'});onAdventure(state);sync(state);}catch(error){onError(error);}};
 for(const city of CITIES){const option=element('option',city.name);option.value=city.id;$('mission-city-select').append(option);}
 $('mission-city-select').onchange=()=>{selectedCity=$('mission-city-select').value;boardKey='';if(current)renderBoard(current);};
 $('mission-surprise').onclick=()=>{const offers=selectedCity?offersForCity(selectedCity):null;return mission(offers?{missionKey:offers[Math.floor(Math.random()*offers.length)].key}:{});};
 renderRoute(0);
 return {sync,setConfig,setGiftActions,worldStatus,open};
}
