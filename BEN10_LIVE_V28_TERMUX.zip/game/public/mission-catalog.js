import {CITIES} from './traversal.js';
export const MISSION_KINDS={
 rescue:{name:'Resgate',instruction:'Libere o morador com o poder e acompanhe-o até um lugar seguro.'},
 escort:{name:'Escolta',instruction:'Encontre o morador e caminhe com ele até o próximo quarteirão.'},
 delivery:{name:'Entrega',instruction:'Recolha a encomenda, transporte-a e aguarde a entrega no destino.'},
 race:{name:'Corrida',instruction:'Passe pelos três portais em sequência antes do prazo.'},
 repair:{name:'Reparo',instruction:'Use a habilidade correta duas vezes junto ao equipamento.'},
 fire:{name:'Incêndio',instruction:'Apague os três focos, aproximando-se de cada um.'},
 defense:{name:'Defesa',instruction:'Proteja a área com duas habilidades e permaneça junto dela por cinco segundos.'},
 search:{name:'Busca',instruction:'Fareje duas pistas em pontos diferentes do trajeto.'}
};
export const MISSION_NPCS={gwen:'Gwen Tennyson',max:'Vô Max',lia:'Lia · florista',caio:'Caio · comerciante',bia:'Bia · guia'};
export const MISSION_BLUEPRINTS=[
 {key:'rescue',kind:'rescue',title:'Passagem de emergência',request:'Uma entrega caiu sobre a passagem de um morador. Quatro Braços, libere a saída e acompanhe-o até o ponto seguro!',thanks:'Todos chegaram em segurança. Valeu, Ben!',speaker:'max',form:'fourarms',object:'crates'},
 {key:'escort',kind:'escort',title:'Um caminho acompanhado',request:'Ben, um visitante se perdeu. Encontre-o e acompanhe-o até o próximo quarteirão.',thanks:'Com sua companhia, o visitante encontrou o caminho!',speaker:'bia',form:'base',object:'signal'},
 {key:'delivery',kind:'delivery',title:'Encomenda comunitária',request:'XLR8, recolha a caixa de livros e entregue-a na biblioteca mais adiante. Aguarde o recibo no destino!',thanks:'Livros entregues! A biblioteca já pode abrir.',speaker:'caio',form:'volt',object:'books'},
 {key:'race',kind:'race',title:'Circuito de reflexos',request:'XLR8, passe pelos três portais de treino em sequência. Mostre seu controle da velocidade!',thanks:'Circuito completo e sem atalhos. Muito bem!',speaker:'gwen',form:'volt',object:'stars'},
 {key:'repair',kind:'repair',title:'Apoio de cristal',request:'Diamante, duas estruturas de apoio estão danificadas. Crie cristais para reforçá-las junto ao painel.',thanks:'Estrutura estabilizada! A rua voltou a ficar segura.',speaker:'max',form:'rock',object:'crystal'},
 {key:'fire',kind:'fire',title:'Três focos na rua',request:'Aquático, há três pequenos focos de incêndio ao longo da calçada. Apague cada foco com cuidado!',thanks:'Todos os focos foram apagados. Ótimo trabalho!',speaker:'caio',form:'tide',object:'fire'},
 {key:'defense',kind:'defense',title:'Proteção da passagem',request:'Bola de Canhão, proteja a passagem com dois impactos controlados e fique por perto até a área ficar segura.',thanks:'Passagem protegida. Os moradores já podem atravessar!',speaker:'max',form:'cannon',object:'stones'},
 {key:'search',kind:'search',title:'Duas pistas no caminho',request:'Besta, precisamos encontrar o cachorro perdido. Fareje a primeira pista e siga até a segunda!',thanks:'Encontramos o rastro certo. O cachorro está seguro!',speaker:'lia',form:'beast',object:'trail'},
 {key:'garden',kind:'repair',title:'Jardim de novo vivo',request:'Cipó Selvagem, reforce as raízes e recupere duas partes deste pequeno jardim!',thanks:'O jardim voltou a florescer. Obrigada, Ben!',speaker:'lia',form:'wildvine',object:'garden'},
 {key:'thaw',kind:'repair',title:'Reservatório congelado',request:'Chama, voe até o reservatório e aqueça as duas válvulas congeladas sem danificar o encanamento!',thanks:'Água correndo de novo! Pode pousar tranquilo.',speaker:'gwen',form:'blaze',object:'ice',travelMode:'fly'}
];
export const MISSION_CATALOG=CITIES.flatMap(city=>MISSION_BLUEPRINTS.map(blueprint=>({...blueprint,key:city.id+':'+blueprint.key,city:city.id,title:blueprint.title+' · '+city.name,npc:MISSION_NPCS[blueprint.speaker]})));
export const offersForCity=city=>MISSION_CATALOG.filter(spec=>spec.city===city).map(({key,title,kind,form,npc,object,request,city})=>({key,title,kind,form,npc,object,request,city,instruction:MISSION_KINDS[kind].instruction}));
