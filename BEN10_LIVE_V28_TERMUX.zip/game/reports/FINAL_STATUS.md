# V28.0.0 — verificação da entrega

Atualização com estrada linear contínua, quatro temas de cidade,40 ofertas locais e oito mecânicas de missão, caminhada articulada, fila de presentes e painel para escolher cidade/missão.

- Sintaxe e build local passaram.
-95 testes automatizados passaram, sem falhas ou testes ignorados. Log: v28/test-results.txt.
- Integração no Chromium: Ben caminha em linha reta; entrega e incêndio concluídos por movimento/habilidades reais; dois presentes concluídos em sequência sem falhas; recarregamento retém a posição; treino não altera a missão; layout430×932 sem overflow e sem erros de página. Registro: v28/browser-integration.json.
- Viagem pelo painel: Bellwood→Baía do Farol, de124m a475m; missão de entrega concluída após a mudança de cidade; poder do Diamante permanece junto do herói após rebasing. Registro: v28/cross-city-integration.json.
- Streaming em amostras até9,6km: seis quarteirões residentes, materiais/texturas limitados e sem erros de página. Registro: v28/world-streaming.json. A amostragem longa verifica descarte e precisão; não equivale a9,6km filmados em tempo real.
- O vídeo mostra o canvas WebGL real de missões/presentes; screenshots incluem a interface móvel. É uma execução em Chromium de software na cloud, não uma medição de desempenho Android.

O usuário confirmou que a conexão real TikTok funcionou no celular. server/live.js e as versões das dependências de transporte foram preservados byte a byte em relação àV27.0.1. A integração LIVE da suíte usa transporte controlado; não foi feita outra LIVE real na cloud.

A sequência de cidade não tem um fim fixo, mas reutiliza quatro temas em quarteirões variados. Progresso de missão/distância é da sessão do servidor. Vozes, clipes oficiais e performance Android não foram validados por estes testes. Configurações/chaves e modelos personalizados são preservados pelo atualizador.

A transição da câmera usa um arco ao redor do personagem. A integração observou 465 amostras, com raio mínimo de6.0m; não atravessou o corpo ao voltar da missão.
