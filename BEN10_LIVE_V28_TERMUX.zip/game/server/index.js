import {BUILD_ID,BUILD_LABEL} from '../public/release.js';
import {identityQuestion,localPersonaReply} from './personas.js';
import {generateMission} from './missions.js';
import {SPEAKERS,speakerId} from '../public/characters.js';
import {elevenlabs,elevenVoices} from './voice.js';
import {Adventure} from './adventure.js';
import {GiftActionQueue} from './gift-actions.js';
import {normalizeGiftRules,normalizeCommandRules} from '../public/audience.js';
import http from 'node:http';
import {readFile,mkdir,writeFile,readdir,rename} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {EventHub,SpeechQueue,gemini,localReply,FORMS,DISTRICTS} from './core.js';
import {KeyStore} from './keys.js';
import {LiveAdapter} from './live.js';
const bundledModels=JSON.parse(await readFile(new URL('../public/bundled-models/manifest.json',import.meta.url),'utf8'));
const root=fileURLToPath(new URL('../',import.meta.url));const hub=new EventHub();const clients=new Set();
function broadcast(type,data){for(const c of clients)c.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`);}
const queue=new SpeechQueue({timeout:120000,onChange:s=>broadcast('queue',s)});const live=new LiveAdapter((e,s)=>hub.ingest(e,s),s=>broadcast('live',s));
let config={voiceProvider:'gemini',elevenVoiceId:'',speakerVoices:{},music:.15,voice:1,sfx:.3,quality:'balanced',giftRules:hub.giftRules,commandRules:hub.commandRules};
try{const saved=JSON.parse(await readFile(path.join(root,'data/config.json'),'utf8'));config={...config,...saved};}catch{}
try{config.giftRules=normalizeGiftRules(config.giftRules,{upgradeLegacy:config.rulesVersion!==28});}catch{config.giftRules=hub.giftRules;}
try{config.commandRules=normalizeCommandRules(config.commandRules);}catch{config.commandRules=hub.commandRules;}
config.rulesVersion=28;hub.giftRules=config.giftRules;hub.commandRules=config.commandRules;

let configWrites=Promise.resolve();
function changeConfig(data){const task=configWrites.then(async()=>{
   const next={...config};if(data.adventure)next.adventure=data.adventure;
   if(data.voiceProvider!==undefined){if(!['gemini','elevenlabs'].includes(data.voiceProvider))throw Error('Provedor de voz inválido');next.voiceProvider=data.voiceProvider;}
   if(data.elevenVoiceId!==undefined){if(typeof data.elevenVoiceId!=='string'||(data.elevenVoiceId&&!/^[a-zA-Z0-9_-]{5,100}$/.test(data.elevenVoiceId)))throw Error('ID de voz inválido');next.elevenVoiceId=data.elevenVoiceId;}
   if(data.speakerVoices!==undefined){if(!data.speakerVoices||typeof data.speakerVoices!=='object'||Array.isArray(data.speakerVoices)||Object.keys(data.speakerVoices).length>Object.keys(SPEAKERS).length)throw Error('Mapa de vozes inválido');for(const [id,value] of Object.entries(data.speakerVoices))if(!Object.hasOwn(SPEAKERS,id)||typeof value!=='string'||(value&&!/^[a-zA-Z0-9_-]{5,100}$/.test(value)))throw Error('Voz de personagem inválida');next.speakerVoices={...data.speakerVoices};}
   for(const k of ['music','voice','sfx'])if(data[k]!==undefined)next[k]=Math.max(0,Math.min(1,Number(data[k])||0));
   if(['economy','balanced','high'].includes(data.quality))next.quality=data.quality;
   if(data.giftRules!==undefined){next.giftRules=normalizeGiftRules(data.giftRules);}
   if(data.commandRules!==undefined){next.commandRules=normalizeCommandRules(data.commandRules);}
   await mkdir(path.join(root,'data'),{recursive:true});const configFile=path.join(root,'data/config.json'),configTemp=configFile+'.tmp';await writeFile(configTemp,JSON.stringify(next));await rename(configTemp,configFile);config=next;hub.giftRules=config.giftRules;hub.commandRules=config.commandRules;return config;
 });configWrites=task.catch(()=>{});return task;}
const keys=await new KeyStore(path.join(root,'data/private/gemini-keys.json')).load();
const voiceKeys=await new KeyStore(path.join(root,'data/private/elevenlabs-keys.json'),'ELEVENLABS_API_KEY').load();
const adventure=new Adventure({missionFactory:options=>keys.key()?generateMission({...options,key:keys.key()}):null,onChange:s=>broadcast('adventure',s)});
if(config.adventure)adventure.configure(config.adventure);
let trainingUntil=0;let localSpeechUntil=0;const adventureBusy=()=>!!queue.active||Date.now()<localSpeechUntil||Date.now()<trainingUntil;
const giftActions=new GiftActionQueue({adventure,onChange:s=>broadcast('giftActions',s),onNotice:notice=>broadcast('gameNotice',notice)});
const adventureTimer=setInterval(()=>{const now=Date.now(),busy=adventureBusy();giftActions.tick(now,busy);adventure.tick(now,busy);},250);adventureTimer.unref();
const recent=new Map();
hub.listeners.add(e=>{broadcast('event',e);broadcast('ranking',hub.leaders());if(e.type==='gift'){if(e.action||e.power||e.movement||e.mission)giftActions.enqueue(e);return;}if(e.action)adventure.requestTransform(e.action,e.source);
 if(e.mission)Promise.resolve(adventure.startMission(Date.now(),{kind:e.missionKind||undefined})).catch(error=>broadcast('gameNotice',{text:error.message}));
 if(e.movement){try{adventure.requestMovement(e.movement);}catch(error){broadcast('gameNotice',{text:error.message});}}
 if(e.power)adventure.requestPower(e.action||adventure.pending?.form||adventure.form);
 adventure.tick(Date.now(),adventureBusy());
 if(e.type==='comment'&&!e.action&&!e.power&&!e.mission&&!e.movement){
 const last=recent.get(e.user)||0;if(Date.now()-last<3000)return;recent.set(e.user,Date.now());if(recent.size>5000)recent.delete(recent.keys().next().value);
 queue.enqueue({speaker:e.speaker,user:e.user,prompt:e.text,source:e.source,priority:hub.ranking.get(e.user)?.giftCredit||0});const u=hub.ranking.get(e.user);if(u)u.giftCredit=Math.max(0,u.giftCredit-1);
 }});
async function body(req,limit=65536){let bytes=0;const parts=[];for await(const b of req){bytes+=b.length;if(bytes>limit)throw Error('Corpo excede o limite');parts.push(b);}return Buffer.concat(parts);}
function json(res,status,data){res.writeHead(status,{'x-game-build':BUILD_ID,'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));}
export const server=http.createServer(async(req,res)=>{try{
 if(!['127.0.0.1:'+port,'localhost:'+port].includes(req.headers.host))return json(res,403,{error:'Host não permitido'});
 const url=new URL(req.url,'http://127.0.0.1');const p=url.pathname;
 // A document opened from another app/site is a valid entry point. API requests remain origin-restricted.
 const entryNavigation=req.method==='GET'&&p==='/'&&req.headers['sec-fetch-mode']==='navigate'&&req.headers['sec-fetch-dest']==='document';
 if(!entryNavigation&&req.headers['sec-fetch-site']==='cross-site')return json(res,403,{error:'Origem não permitida'});
 if(!entryNavigation&&req.headers.origin && !['http://127.0.0.1:'+port,'http://localhost:'+port].includes(req.headers.origin))return json(res,403,{error:'Origem não permitida'});
 if(p==='/events'){
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive'});clients.add(res);res.write(`event: ready\ndata: ${JSON.stringify({build:BUILD_ID,queue:queue.snapshot(),ranking:hub.leaders(),live:live.state,adventure:adventure.snapshot(),giftActions:giftActions.snapshot()})}\n\n`);const heartbeat=setInterval(()=>res.write(': ping\n\n'),15000);req.on('close',()=>{clearInterval(heartbeat);clients.delete(res);});return;
 }
 if(p==='/api/health')return json(res,200,{ok:true,application:'LINEL_LIVE_CITY_V25',build:BUILD_ID,buildLabel:BUILD_LABEL,identity:'Ben Tennyson',runtime:{pid:process.pid,root:root.replace(/\/$/,''),port},training:Date.now()<trainingUntil,node:process.version,geminiConfigured:!!keys.key(),voiceProvider:config.voiceProvider,voiceConfigured:config.voiceProvider==='elevenlabs'?!!voiceKeys.key():!!keys.key(),live:live.state,forms:FORMS,districts:DISTRICTS,queue:queue.snapshot(),giftActions:giftActions.snapshot(),uptime:process.uptime()});
 if(p==='/api/models'&&req.method==='GET'){let files=[];try{files=await readdir(path.join(root,'data/models'));}catch{}return json(res,200,FORMS.flatMap(form=>files.includes(form+'.glb')?[{form,url:'/models/'+form+'.glb',custom:true}]:bundledModels.filter(entry=>entry.form===form)));}
 if(p==='/api/speakers'&&req.method==='GET')return json(res,200,SPEAKERS);
 if(p==='/api/voice-library'&&req.method==='GET')return json(res,200,await elevenVoices({key:voiceKeys.key()}));
 if(p==='/api/voice-keys'&&req.method==='GET')return json(res,200,voiceKeys.status());
 if(p==='/api/adventure'&&req.method==='GET')return json(res,200,adventure.snapshot());
 if(p==='/api/keys'&&req.method==='GET')return json(res,200,keys.status());
 if(p==='/api/config'&&req.method==='GET')return json(res,200,config);
 if(req.method==='POST'&&p.startsWith('/api/')){
  if(p==='/api/model'){
   const form=url.searchParams.get('form');if(form&&!FORMS.includes(form))throw Error('Forma inválida');const filename=(form||'avatar')+'.glb';
   const b=await body(req,20*1024*1024);if(b.length<20||b.toString('ascii',0,4)!=='glTF'||b.readUInt32LE(4)!==2||b.readUInt32LE(8)!==b.length)throw Error('GLB 2.0 inválido');
   const jsonLength=b.readUInt32LE(12);if(b.readUInt32LE(16)!==0x4e4f534a||jsonLength%4||jsonLength+20>b.length)throw Error('Chunk JSON GLB inválido');const document=JSON.parse(b.toString('utf8',20,20+jsonLength));if(document.asset?.version!=='2.0')throw Error('Asset GLB 2.0 ausente');if(document.buffers?.some(x=>x.uri)||document.images?.some(x=>x.uri))throw Error('GLB precisa incorporar buffers e texturas');
   await mkdir(path.join(root,'data/models'),{recursive:true});await writeFile(path.join(root,'data/models',filename),b);return json(res,201,{url:'/models/'+filename,bytes:b.length,note:'GLB armazenado; carregamento disponível no painel.'});
  }
  const data=JSON.parse((await body(req)).toString()||'{}');
  if(p==='/api/voice-keys'){if(!String(req.headers['content-type']).startsWith('application/json'))throw Error('JSON obrigatório');return json(res,200,await voiceKeys.change(data.action,data));}
  if(p==='/api/keys'){if(!String(req.headers['content-type']).startsWith('application/json'))throw Error('JSON obrigatório');return json(res,200,await keys.change(data.action,data));}
  if(p==='/api/adventure'){const now=Date.now();if(data.action==='transform')adventure.requestTransform(data.form,'operator');else if(data.action==='movement')adventure.requestMovement(data.mode,now);else if(data.action==='power')adventure.usePower(now,adventureBusy());else if(data.action==='mission')await adventure.startMission(now,{kind:data.kind,missionKey:data.missionKey});else if(data.action==='cancel')adventure.cancelMission(now);else if(data.action==='locate'){adventure.locate(data.position,now);if(data.speaking===true)localSpeechUntil=now+3500;else localSpeechUntil=0;}else if(data.action==='configure'){adventure.configure(data.options);await changeConfig({adventure:{...adventure.options}});}else throw Error('Ação de aventura inválida');adventure.tick(now,adventureBusy());return json(res,200,adventure.snapshot());}
  if(p==='/api/training'){if(typeof data.active!=='boolean')throw Error('Estado de treino inválido');const duration=data.duration??12000;if(!Number.isFinite(duration)||duration<1000||duration>60000)throw Error('Duração de treino inválida');trainingUntil=data.active?Date.now()+duration:0;adventure.tick(Date.now(),adventureBusy());return json(res,200,{active:Date.now()<trainingUntil,until:trainingUntil});}
  if(p==='/api/event')return json(res,200,{event:hub.ingest(data,'demo')});
  if(p==='/api/ack')return json(res,200,{accepted:queue.ack(data.id)});
  if(p==='/api/connect'){await live.connect(String(data.username||''),data.provider,{endpoint:data.endpoint||'auto'});return json(res,200,live.state);}
  if(p==='/api/disconnect'){await live.disconnect();return json(res,200,live.state);}
  if(p==='/api/answer'){
   if(!queue.active||queue.active.id!==data.id)return json(res,409,{error:'Fala não ativa'});
   const speaker=queue.active.speaker||adventure.form;const identity=identityQuestion(queue.active.prompt,speaker);if(identity)return json(res,200,{text:identity,speaker,mode:'identity'});
   try{return json(res,200,{...await gemini(queue.active.prompt,{key:keys.key(),context:{speaker,form:adventure.form,quest:adventure.quest}}),speaker,mode:'gemini'});}catch(e){return json(res,200,{text:localPersonaReply(queue.active.prompt,speaker,localReply(queue.active.prompt)),speaker,mode:'local',warning:e.message});}
  }
  if(p==='/api/tts'){if(typeof data.text!=='string'||data.text.length>1000)throw Error('Texto inválido');const speaker=speakerId(data.speaker||adventure.form),profile=SPEAKERS[speaker],voiceId=config.speakerVoices?.[speaker];if(config.voiceProvider==='elevenlabs'&&!voiceId&&speaker!=='base')throw Error('Escolha um ID ElevenLabs para '+profile.name+' no painel de vozes');return json(res,200,{...await (config.voiceProvider==='elevenlabs'?elevenlabs(data.text,{key:voiceKeys.key(),voiceId:voiceId||config.elevenVoiceId}):gemini(data.text,{tts:true,key:keys.key(),speaker})),speaker,name:profile.name});}
  if(p==='/api/config'){const {adventure:ignoredAdventure,...settings}=data;return json(res,200,await changeConfig(settings));}
  return json(res,404,{error:'Rota inexistente'});
 }
 if(req.method!=='GET')return json(res,405,{error:'Método não permitido'});
 const modelRoute=p.startsWith('/models/')&&['avatar',...FORMS].some(form=>p==='/models/'+form+'.glb');
 if(p.startsWith('/models/')&&!modelRoute)return json(res,404,{error:'Modelo não encontrado'});
 const base=modelRoute?path.join(root,'data/models'):path.join(root,'public');const relative=modelRoute?p.slice('/models'.length):p==='/'?'/index.html':p;const file=path.resolve(base,'.'+decodeURIComponent(relative));if(!file.startsWith(base+path.sep))return json(res,403,{error:'Caminho inválido'});
 const b=await readFile(file);res.writeHead(200,{'cache-control':'no-cache','x-game-build':BUILD_ID,'content-type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.glb':'model/gltf-binary'})[path.extname(file)]||'application/octet-stream','x-content-type-options':'nosniff'});res.end(b);
 }catch(e){json(res,e.code==='ENOENT'?404:400,{error:e.message});}});
const port=Number(process.env.PORT||3000);
if(!Number.isInteger(port)||port<1||port>65535){console.error('PORT inválida. Use um número entre 1 e 65535.');process.exit(1);}
server.once('error',async error=>{clearInterval(adventureTimer);queue.close();if(error.code==='EADDRINUSE'){
 let running=false;try{const r=await fetch('http://127.0.0.1:'+port+'/api/health',{signal:AbortSignal.timeout(1200)});const d=await r.json();running=d.application==='LINEL_LIVE_CITY_V25'||(Array.isArray(d.forms)&&d.forms.join(',')===FORMS.join(','));}catch{}
 console.error(running?'O jogo já está em execução nesta porta. Abra http://127.0.0.1:'+port+'/':'A porta '+port+' já está sendo usada por outro programa.');
 console.error('Para carregar uma atualização, pare o servidor anterior com Ctrl+C na sessão original e execute bash start.sh novamente.');
 console.error('Para usar outra porta: PORT='+Math.min(65535,port+1)+' bash start.sh');process.exit(running?0:1);
 }else{console.error('Não foi possível iniciar o servidor: '+error.code);process.exit(1);}});
server.listen(port,'127.0.0.1',()=>console.log(BUILD_LABEL+' iniciado. Abra http://127.0.0.1:'+port+'/'));

for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{clearInterval(adventureTimer);queue.close();live.disconnect();for(const c of clients)c.end();server.close(()=>process.exit(0));});
