# V28.0.0 — Estrada Infinita LIVE

A rota passa a seguir uma avenida em linha reta. Os quarteirões entram à frente e os antigos saem da cena conforme Ben avança; não há retorno ao início do percurso. O contador mostra a distância total. A cada400m muda a cidade: Bellwood, Baía do Farol, Serra dos Cristais e Distrito Industrial. Os quatro temas reaparecem em novos trechos com variação determinística dos prédios. São bairros procedurais, não mapas de cidades reais.

## Missões com mecânicas diferentes

O painel **Missões** tem10 ofertas por cidade,40 ofertas locais ao todo, distribuídas em oito tipos. Aceite uma oferta ou peça pelo chat. Use o seletor de cidade para aceitar um pedido em outra região: Ben viaja pela avenida até lá, sem voltar ao início do mapa. Uma missão ativa deve ser concluída ou encerrada antes de aceitar outra. O painel registra as últimas seis conclusões e o total por cidade durante a sessão do servidor.

| Tipo | O que acontece | Pedido no chat |
| --- | --- | --- |
| Resgate | Quatro Braços libera a passagem com um poder e acompanha o morador28m. | missão resgate |
| Escolta | Ben encontra o visitante e o acompanha35m. | missão escolta |
| Entrega | Recolhe a caixa, transporta42m e aguarda o recebimento. | missão entrega |
| Corrida | XLR8 atravessa três portais de25m em até30s. | missão corrida |
| Reparo | Duas habilidades recuperam cristais, jardim ou válvulas congeladas. | missão reparo |
| Incêndio | Aquático apaga três focos em pontos distintos. | missão incêndio |
| Defesa | Dois impactos protegem a passagem; é preciso permanecer5s junto dela. | missão defesa |
| Busca | Besta identifica duas pistas separadas por12m até encontrar o cachorro. | missão busca |

As opções de transformação e poderes automáticos continuam em Ajustes. O deslocamento para objetivos é automático quando Ben está na forma necessária. O botão✹ e os comandos do chat continuam disponíveis. A câmera acompanha a missão por trás e volta à frente após sua conclusão. Pedidos de fala pausam as ações automáticas; o prazo da corrida é pausado enquanto a fila de fala está ativa.

Com uma chave Gemini, o gerador pode criar novos textos de missão dentro dessas mecânicas. Se a resposta falhar ou não for executável, usa-se uma oferta local e o aviso aparece no painel. Uma resposta gerada não cria sistemas de jogo adicionais.

## Animações e cenário

Passos têm apoio e balanço alternados, joelhos, tornozelos, quadril e braços articulados; corrida usa outra amplitude. XLR8 mantém uma postura baixa de dash com rastros. Há gestos de NPCs, acompanhante caminhando e comemorando no destino, caixa transportada, incêndios separados, portais em sequência, pistas e cachorro animado, painel recuperado, plantas crescendo e gelo derretendo. As onze formas têm poses de habilidade distintas. O treino de poderes continua acessível sem API ou áudio.

Prédios têm fachadas, janelas, marquises, árvores, bancos, iluminação e detalhes diferentes por tema. A via permanece livre. O cenário conserva uma quantidade limitada de quarteirões próximos para jornadas longas. Em celulares mais lentos, escolha **Ajustes → Qualidade → Economia**. A performance precisa ser conferida no aparelho.

## Presentes e público

Em **Laboratório → Presentes**, configure nome exato, alien, pontos, uso do poder e movimento extra. A opção **Carregar sugestões V28** só é aplicada depois de salvar. Os nomes dos presentes dependem do catálogo da LIVE; não são preços de moedas.

Sugestões: Rose transforma em Chama e usa poder; Ice Cream usa Aquático e água; Finger Heart chama XLR8 e dá dash; Galaxy ativa Alien X e seu campo estelar. Alien X é uma forma extra fora da continuidade clássica. Regras personalizadas são preservadas. As duas regras antigas Rose/Chama e Galaxy/Alien X passam a usar poder se essa opção ainda não existia; um valor explícito falso é respeitado.

As ações entram numa fila de até oito presentes e respeitam fala, treino, recarga e duração da animação. A quantidade final de um streak soma todos os pontos e dispara uma sequência visual. Se a fila estiver cheia, os pontos são registrados e aparece um aviso de que a animação não entrou. O status mostra o participante e a ação em andamento.

Ben, Gwen e Max convidam o público a escolher aliens, sugerir tipos de missão e fazer perguntas. As falas de convite respeitam inatividade e intervalo e usam a mesma fila de áudio, sem interromper conversa ou treino. Desative dicas faladas em Ajustes se preferir apenas os banners.

## Atualização

Veja [ATUALIZAR_CELULAR.md](ATUALIZAR_CELULAR.md). Execute na instalação existente:

```sh
cd ~/linel-v25/game
bash update.sh --start
```

Os aliases de download V27 e V25 também contêm esta V28 para atender atualizadores antigos. O instalador continua reaproveitando Node/npm/Python já disponíveis, sem consultar repositórios Termux desnecessariamente. Chaves, configurações e modelos personalizados em data/ são preservados.

O transporte TikTok e suas dependências não mudaram nesta entrega: o usuário confirmou a conexão real no celular. Os testes da atualização usam eventos e WebSocket controlados; não equivalem a uma nova LIVE real testada na cloud. Vozes oficiais e clipes oficiais não estão incluídos. O progresso da jornada/missões reinicia ao reiniciar o servidor; recarregar apenas o navegador sincroniza com a jornada em execução.
