# Ben 10 · Estrada Infinita LIVE · V28

Jogo interativo para Node/Termux e Chrome, com avenida procedural contínua, quatro temas de cidade, oito tipos de missão, onze formas, NPCs e participação do chat/presentes. Assets Babylon são servidos localmente. Projeto de fã sem afiliação oficial.

```sh
bash install.sh
bash start.sh
```

Use o endereço exibido no terminal, no Chrome do mesmo aparelho. Para atualizar uma instalação existente, execute `bash update.sh --start` em sua pasta `game`. Confira **v28.0.0** no topo da tela. [Instruções para celular](docs/ATUALIZAR_CELULAR.md).

Abra **Missões** para escolher um dos10 pedidos da cidade; Ben continua avançando por novos quarteirões. O chat aceita nomes de aliens, “poder”, “dash”, “voar” e “missão resgate/entrega/corrida/busca”. Em **Laboratório**, configure presentes que transformam, usam poder e ativam movimento. A fila visual identifica o participante. [Novidades e mecânicas V28](docs/V28_NOVIDADES.md).

**IA e voz** permite cadastrar várias chaves Gemini e selecionar uma, além de ElevenLabs opcional e vozes por personagem. Chaves ficam no servidor, em data/private, fora dos ZIPs/backup; não são retornadas ao navegador. Sem chave, missões locais e respostas locais continuam disponíveis. Toque no botão de áudio para liberar a reprodução. As vozes e animações são interpretadas/procedurais; não são a dublagem ou clipes oficiais.

O usuário confirmou que a conexão TikTok pelo@ funcionou no celular. Esta versão preserva o transporte. Conectores não oficiais dependem da disponibilidade do TikTok e a cloud não substitui o teste no aparelho. Para transmitir o jogo no mesmo celular, veja [LIVE_CELULAR.md](docs/LIVE_CELULAR.md).

## Desenvolvimento

Node>=22.19 e Python para empacotamento/atualização. Use o checkout existente.

- `npm ci`: instalação pelo lockfile.
- `npm test`: domínio,40 missões, integração HTTP/SSE, fila de presentes, rigs/efeitos e conectores com transporte controlado.
- `npm run lint`: verificação de sintaxe JavaScript.
- `npm run build`: prepara Babylon e licenças locais, copia public/ para dist/public.
- `npm run package`: executa verificações e gera BEN10_LIVE_V28_TERMUX.zip e aliases V27/V25 sem data/, .env ou node_modules.
- `bash doctor.sh`: diagnóstico do servidor sem expor chaves.
- `bash backup.sh`: exporta configuração/modelos locais sem chaves.

O jogo contém nove GLBs de terceiros com licençaCCBY4 e duas formas procedurais. Veja [créditos](docs/MODEL_CREDITS.md), [animações](docs/ANIMACOES.md) e third_party/NOTICE.md. Código do jogo sob AGPL3; fontes correspondentes do conector incluídas em third_party. Personalizações GLB em data/models continuam prevalecendo; o treino usa as formas incluídas.

A jornada percorre distância sem limite fixo, com quatro temas reutilizados em trechos variados; não representa um mapa geográfico infinito. Progresso de missão é da sessão do servidor. Performance Android, vozes de serviços externos e cada condição de rede devem ser verificados no aparelho.
