import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Adventure} from '../server/adventure.js';
import {EventHub} from '../server/core.js';
import {GiftActionQueue} from '../server/gift-actions.js';

function setup(options={}){
 const powers=[],motions=[],states=[],notices=[];
 const adventure=new Adventure({now:0,onChange:state=>{if(state.power&&!powers.some(power=>power.id===state.power.id))powers.push(state.power);if(state.motion&&!motions.some(motion=>motion.id===state.motion.id))motions.push(state.motion);}});
 adventure.configure({autoTransform:false,autoMissions:false,autoPowers:false},0);
 const queue=new GiftActionQueue({adventure,onChange:state=>states.push(state),onNotice:notice=>notices.push(notice),...options});
 const tick=(now,busy=false)=>{queue.tick(now,busy);adventure.tick(now,busy);};
 return {adventure,queue,tick,powers,motions,states,notices};
}
const gift=(id,action,power=true,extra={})=>({id,type:'gift',gift:'Rose',user:'Público '+id,count:1,action,power,...extra});

test('dois presentes guardam suas formas e poderes sem sobrescrever a ação anterior',()=>{
 const {queue,tick,powers,adventure}=setup();
 assert(queue.enqueue(gift('one','blaze')));assert(queue.enqueue(gift('two','rock')));
 tick(0);assert.equal(adventure.form,'blaze');tick(100);assert.equal(powers.length,1);
 tick(500);assert.equal(adventure.form,'blaze');assert.equal(queue.snapshot().waiting.length,1);
 for(let now=600;now<=8000;now+=100)tick(now);
 assert.deepEqual(powers.map(power=>power.form),['blaze','rock']);assert.equal(queue.completed,2);assert.equal(queue.snapshot().length,0);
});

test('fala e treino impedem novos poderes e transformações, sem expirar o presente',()=>{
 const {queue,tick,powers,adventure}=setup();queue.enqueue(gift('one','blaze'));
 for(let now=0;now<=150000;now+=500)tick(now,true);
 assert.equal(adventure.form,'base');assert.equal(powers.length,0);assert.equal(queue.failed,0);
 tick(150500);tick(151000);assert.equal(adventure.form,'blaze');assert.equal(powers[0].form,'blaze');
});

test('presentes respeitam cooldown e só avançam após a animação completa',()=>{
 const {queue,tick,powers,adventure}=setup();adventure.usePower(0);queue.enqueue(gift('one','base'));
 tick(100);tick(1000);assert.equal(powers.length,1);assert.match(queue.snapshot().active.status,/recarregando/);
 tick(2500);assert.equal(powers.length,2);assert.equal(queue.completed,0);
 tick(4500);assert.equal(queue.completed,0);tick(4600);assert.equal(queue.completed,1);
});

test('dash por presente espera o movimento terminar antes do próximo presente',()=>{
 const {queue,tick,motions,powers,adventure}=setup();queue.enqueue(gift('dash','volt',false,{movement:'dash'}));queue.enqueue(gift('next','tide'));
 tick(0);tick(100);assert.equal(motions.length,1);assert.equal(motions[0].mode,'dash');tick(500);assert.equal(adventure.form,'volt');assert.equal(powers.length,0);
 for(let now=600;now<=5500;now+=100)tick(now);
 assert.deepEqual(powers.map(power=>power.form),['tide']);assert.equal(queue.completed,2);
});

test('fila limita oito ações, preserva pontuação e informa excesso sem fingir ativação',()=>{
 const {queue,notices}=setup();const hub=new EventHub();hub.listeners.add(event=>queue.enqueue(event));
 for(let i=0;i<9;i++)hub.ingest({id:'gift-'+i,type:'gift',gift:'Rose',user:'Pessoa',count:2});
 assert.equal(queue.snapshot().length,8);assert.equal(hub.leaders()[0].points,180);assert.equal(notices.length,1);assert.match(notices[0].text,/fila.*cheia/);assert.match(notices[0].text,/Pontos/);
 assert.equal(queue.enqueue(gift('gift-0','blaze')),false);assert.equal(queue.snapshot().length,8);
});

test('presente apenas transforma, missão respeita tipo e promessa resolve uma vez',async()=>{
 const {queue,tick,adventure}=setup();queue.enqueue(gift('form','rock',false));tick(0);tick(100);assert.equal(queue.completed,1);assert.equal(adventure.power,null);
 queue.enqueue(gift('mission',null,false,{mission:true,missionKind:'search'}));tick(200);assert.equal(adventure.quest.kind,'search');await Promise.resolve();tick(300);assert.equal(queue.completed,2);
});

test('a reserva do presente impede missão automática de trocar a forma durante o poder',()=>{
 const {queue,tick,adventure}=setup();adventure.startMission(0,{kind:'repair'});adventure.configure({autoTransform:true,autoMissions:false,autoPowers:true},0);
 queue.enqueue(gift('gift','tide'));tick(1000);tick(1500);assert.equal(adventure.form,'tide');tick(2500);tick(3000);assert.equal(adventure.form,'tide');assert.equal(adventure.power.form,'tide');
});

test('falha de uma ação é informada e não bloqueia os próximos presentes',async()=>{
 const {queue,tick,adventure,notices}=setup();
 adventure.startMission=()=>Promise.reject(Error('gerador indisponível'));
 queue.enqueue(gift('bad',null,false,{mission:true}));queue.enqueue(gift('good','rock',false));
 tick(0);await Promise.resolve();assert.equal(queue.failed,1);assert.match(notices[0].text,/gerador indisponível/);
 tick(100);tick(200);assert.equal(adventure.form,'rock');assert.equal(queue.completed,1);assert.equal(queue.snapshot().length,0);
});
