import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventHub} from '../server/core.js';
import {DEFAULT_GIFT_RULES,normalizeGiftRules,normalizeCommandRules,EngagementDirector,buildEngagementPrompt} from '../public/audience.js';

test('presentes usam regra configurada, preservam zero pontos e só disparam no fim do streak',()=>{
 const hub=new EventHub();hub.giftRules=normalizeGiftRules([{name:'Rosa',points:0,action:'blaze',power:true}]);
 assert.equal(hub.ingest({id:'streak',type:'gift',gift:'Rosa',repeatEnd:false}),null);
 const event=hub.ingest({id:'streak',type:'gift',gift:'Rosa',repeatEnd:true,count:4,user:'Ana'});
 assert.equal(event.power,true);assert.equal(event.action,'blaze');assert.equal(event.points,0);assert.match(event.reaction.text,/Ana/);
 assert.equal(hub.ingest({id:'streak',type:'gift',gift:'Rosa'}),null);
 const like=hub.ingest({type:'like',gift:'Rosa'});assert.equal(like.action,null);assert.equal(like.power,false);
});

test('migração só adiciona poder aos presentes antigos conhecidos e respeita opção explícita',()=>{
 const rules=normalizeGiftRules([{name:'Rose',action:'blaze',points:10},{name:'Galaxy',action:'nova',points:100,power:false},{name:'Meu presente',action:'rock',points:2}],{upgradeLegacy:true});
 assert.equal(rules[0].power,true);assert.equal(rules[1].power,false);assert.equal(rules[2].power,false);
 assert.equal(normalizeGiftRules(DEFAULT_GIFT_RULES).length,4);
 assert.throws(()=>normalizeGiftRules([{name:'Rósa',action:'rock',points:1},{name:'rosa',action:'volt',points:2}]),/duplicado/);
 assert.throws(()=>normalizeGiftRules([{name:'Teste',action:'rock',movement:'dash',points:1}]),/XLR8/);
});

test('comandos de poder e missão funcionam sem transformação e perguntas ficam na conversa',()=>{
 const hub=new EventHub();hub.commandRules=normalizeCommandRules([{command:'/poder',power:true},{command:'/busca',missionKind:'search'}]);
 assert.equal(hub.ingest({type:'comment',text:'/poder'}).power,true);
 assert.equal(hub.ingest({type:'comment',text:'/busca'}).missionKind,'search');
 const race=hub.ingest({type:'comment',text:'missão corrida'});assert.equal(race.missionKind,'race');assert.equal(race.movement,null);
 const question=hub.ingest({type:'comment',text:'Como o XLR8 usa o poder?'});assert.equal(question.action,null);assert.equal(question.power,false);
 const gwen=hub.ingest({type:'comment',text:'Gwen, me fala sobre a missão resgate'});assert.equal(gwen.speaker,'gwen');assert.equal(gwen.mission,false);
});

test('convites ao público respeitam silêncio, fala ativa, treino e intervalo mínimo',()=>{
 let now=0;const director=new EngagementDirector({now:()=>now});const opts={audioEnabled:true,giftRules:DEFAULT_GIFT_RULES};
 now=44000;assert.equal(director.next(opts),null);now=46000;assert.equal(director.next({...opts,busy:true}),null);assert.equal(director.next({...opts,previewActive:true}),null);
 assert(director.next(opts));now+=50000;assert.equal(director.next(opts),null);now+=80000;director.noteActivity();assert.equal(director.next(opts),null);now+=46000;assert(director.next(opts));
 assert.match(buildEngagementPrompt({cursor:5,giftRules:[{name:'Meu Presente',action:'rock',power:true}]}).text,/Meu Presente/);
});
