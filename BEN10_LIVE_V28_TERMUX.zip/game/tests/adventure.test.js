import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Adventure,MISSIONS} from '../server/adventure.js';
import {MISSION_KINDS,offersForCity} from '../public/mission-catalog.js';
import {namedTransformation,asksPower,FORM_IDS} from '../public/transformations.js';
import {EventHub} from '../server/core.js';
const manual=a=>a.configure({autoMissions:false,autoTransform:false,autoPowers:false},0);
function walkTo(a,target,clock,{fly=false}={}){const goal=[...target];while(Math.abs(a.position[2]-goal[2])>.01){clock+=500;const z=a.position[2]+Math.min(4,goal[2]-a.position[2]);a.locate([0,fly?2:0,z],clock);}return clock;}
function arrive(a,q,clock){a.requestTransform(q.form,'operator');a.tick(clock);return walkTo(a,q.position,clock,{fly:q.travel.mode==='fly'});}

test('nomes PT-BR e pedidos de poder chegam pelo EventHub DEMO/LIVE',()=>{const names=['Ben 10','Chama','XLR8','Diamante','Fantasmático','Aquático','Alien X','Besta','Quatro Braços','Bola de Canhão','Cipó Selvagem'];for(let i=0;i<names.length;i++){assert.equal(namedTransformation('vira '+names[i]+'!'),FORM_IDS[i]);assert.equal(new EventHub().ingest({type:'comment',text:'transforma em '+names[i]},'tiktok').action,FORM_IDS[i]);}assert.equal(namedTransformation('não vira Chama'),null);assert.equal(namedTransformation('Ben 10, transforma no Chama!'),'blaze');assert.equal(namedTransformation('o chamamento da praça'),null);assert(asksPower('Use seus poderes!'));assert(!asksPower('isso é poderoso'));});

test('automático, pausa de fala, cooldown e retorno ao humano',()=>{const a=new Adventure({now:0,random:()=>0});a.configure({autoMissions:false,transformSeconds:15},0);a.tick(15000,true);assert.equal(a.form,'base');a.tick(15000);a.tick(15500);assert.equal(a.form,'blaze');a.configure({autoTransform:false},15500);a.requestTransform('tide');a.tick(16000);assert.equal(a.form,'blaze');a.tick(23500);assert.equal(a.form,'tide');a.tick(83500);a.tick(84000);assert.equal(a.form,'base');});

test('40 ofertas em quatro cidades contêm os oito tipos e variantes de voo/jardim',()=>{assert.equal(MISSIONS.length,40);for(const city of ['bellwood','coast','canyon','industry']){const offers=offersForCity(city);assert.equal(offers.length,10);assert.deepEqual(new Set(offers.map(x=>x.kind)),new Set(Object.keys(MISSION_KINDS)));}assert(MISSIONS.some(x=>x.travelMode==='fly'));});

test('cada oferta pode ser concluída apenas pela mecânica de seu tipo',()=>{for(const spec of MISSIONS){const a=new Adventure({now:0,random:()=>0});manual(a);let clock=1000;const q=a.startMission(clock,{missionKey:spec.key});assert.equal(q.kind,spec.kind);clock=arrive(a,q,clock);assert.equal(q.stage,'objective',spec.key);assert(q.progress<=2);assert.equal(q.status,'active');
 const powers=['repair','fire','search','rescue','defense'].includes(q.kind);
 for(let step=0;step<180&&q.status==='active';step++){
  const target=[...q.position],dz=Math.max(0,Math.min(4,target[2]-a.position[2]));clock+=500;a.locate([0,0,a.position[2]+dz],clock);
  const movingPhase=['escort','delivery','race'].includes(q.goal.phase);
  if(powers&&!movingPhase&&clock>=a.nextPower&&Math.hypot(a.position[0]-q.position[0],a.position[2]-q.position[2])<=4.5)a.usePower(clock);
 }
 assert.equal(q.status,'complete',spec.key+' não concluiu');assert.equal(a.completed,1);assert.equal(a.completedByCity[q.city],1);assert.equal(a.snapshot().history[0].key,q.key);
 }});

test('poder não resolve escolta, entrega ou corrida sem deslocamento/presença',()=>{for(const kind of ['escort','delivery','race']){const a=new Adventure({now:0});manual(a);let clock=1000;const q=a.startMission(clock,{kind});clock=arrive(a,q,clock);const before=q.progress;a.usePower(clock+3000);assert.equal(q.progress,before);assert.equal(q.status,'active');}});

test('poder exige forma, proximidade, recarga e chegada ao objetivo',()=>{const a=new Adventure({now:0});manual(a);let clock=1000;const q=a.startMission(clock,{missionKey:'bellwood:repair'});assert.match(a.usePower(clock).result,/destino/);clock=arrive(a,q,clock);a.requestTransform('blaze','operator');a.tick(clock);assert.match(a.usePower(clock+3000).result,/outra forma/);assert.equal(q.progress,0);a.requestTransform(q.form,'operator');a.tick(clock+3000);a.position[0]=8;assert.match(a.usePower(clock+6000).result,/Aproxime/);a.position[0]=0;a.usePower(clock+9000);assert.equal(q.progress,1);assert.throws(()=>a.usePower(clock+9001),/recarregando/);assert.throws(()=>a.usePower(clock+13000,true),/fala/);});

test('corrida termina por prazo mesmo sem novas amostras e pausa durante fala',()=>{const a=new Adventure({now:0});manual(a);const q=a.startMission(1000,{kind:'race'});let clock=arrive(a,q,1000);const deadline=q.goal.deadline;a.tick(clock+1000,true);a.tick(clock+11000,true);a.tick(clock+12000,false);assert.equal(q.goal.deadline,deadline+11000);a.tick(q.goal.deadline+1);assert.equal(q.status,'failed');assert.equal(a.completed,0);});

test('pedido automático, missão selecionada e cancelamento preservam contagem correta',()=>{const a=new Adventure({now:0,random:()=>0});a.configure({missionSeconds:15},0);a.tick(15000);assert.equal(a.quest.status,'active');assert.equal(a.quest.kind,'rescue');a.tick(18000,true);assert.equal(a.pending,null);a.tick(18000);a.tick(18500);assert.equal(a.form,'fourarms');a.cancelMission(19000);assert.equal(a.quest.status,'abandoned');assert.equal(a.completed,0);assert.equal(a.nextMission,34000);const q=a.startMission(19500,{kind:'search'});assert.equal(q.kind,'search');assert.throws(()=>a.configure({missionSeconds:0}),/Intervalo/);});

test('cancelar geração impede resposta tardia de criar uma missão',async()=>{let resolve;const a=new Adventure({now:0,missionFactory:()=>new Promise(r=>resolve=r)});manual(a);const pending=a.startMission(1000);assert.equal(a.missionState.status,'generating');a.cancelMission(2000);resolve(MISSIONS[0]);assert.equal(await pending,null);assert.equal(a.quest,null);assert.equal(a.missionState.status,'idle');});

test('IA inválida usa oferta local do tipo solicitado e informa o fallback',async()=>{const a=new Adventure({now:0,missionFactory:async()=>({...MISSIONS[0],object:'unknown'})});manual(a);const q=await a.startMission(1000,{kind:'delivery'});assert.equal(q.kind,'delivery');assert.equal(q.generatedBy,'local');assert.match(a.missionState.warning,/IA indisponível/);});

test('poder pedido junto da transformação espera a forma e respeita fala',()=>{const a=new Adventure({now:0,random:()=>0});manual(a);a.requestTransform('rock');a.requestPower('rock',0);a.tick(0,true);assert.equal(a.power,null);a.tick(0);assert.equal(a.power.form,'rock');assert.equal(a.pendingPower,null);});

test('presente aplica forma após fala e bloqueia automação até terminar sua ação',()=>{const a=new Adventure({now:0});a.configure({autoMissions:false},0);const q=a.startMission(0,{kind:'rescue'});a.requestTransform(q.form,'operator');a.tick(2000);a.holdExternalAction(10000);a.requestTransform('blaze','gift');a.tick(2100,true);assert.equal(a.form,q.form);a.tick(2200);assert.equal(a.form,'blaze');assert.equal(a.pending,null);a.tick(5000);assert.equal(a.pending,null);a.tick(10000);assert.equal(a.pending.form,q.form);assert.equal(a.snapshot().externalActionUntil,10000);});
