import {test} from 'node:test';
import assert from 'node:assert/strict';
import B from 'babylonjs';
import {MissionVisuals} from '../public/mission-visuals.js';
import {LocomotionVisuals} from '../public/locomotion-visuals.js';
import {gaitStep,gaitCycle} from '../public/pedestrian-motion.js';
globalThis.BABYLON=B;
function fixture(){
 const engine=new B.NullEngine(),scene=new B.Scene(engine),materials=new Map();
 const world={scene,form:2,distance:0,originZ:0,locomotionState:'walk',avatar:{root:new B.TransformNode('hero',scene)},material(c){const key=c.join(',');if(!materials.has(key)){const m=new B.StandardMaterial(key,scene);m.diffuseColor=new B.Color3(...c);materials.set(key,m);}return materials.get(key);},mesh({p,s,c,kind},name){const m=kind==='cylinder'?B.MeshBuilder.CreateCylinder(name,{},scene):kind==='box'?B.MeshBuilder.CreateBox(name,{},scene):B.MeshBuilder.CreateSphere(name,{segments:6},scene);m.position.set(...p);m.scaling.set(...s);m.material=this.material(c);return m;},makeActor(id,name){return {root:new B.TransformNode(name,scene),parts:[]};},animateActor(){},toLocalPosition(p){return new B.Vector3(p[0],p[1],p[2]-this.originZ);}};
 world.avatar.root.rotation.y=Math.PI;return {world,scene,dispose(){scene.dispose();engine.dispose();}};
}
const quest=(kind,extra={})=>({id:1,kind,origin:[0,0,100],position:[0,0,100],status:'active',stage:'objective',goal:{phase:kind,targetIndex:0},total:kind==='search'?2:3,progress:0,...extra});
test('all forward race gates and fire/clue targets remain at absolute goals after rebasing',()=>{
 const f=fixture();try{for(const kind of ['race','fire','search']){const q=quest(kind),anchor=new B.TransformNode('anchor',f.scene);anchor.position.copyFrom(f.world.toLocalPosition(q.position));const v=new MissionVisuals(f.world,q,anchor);v.update(q,.016);const nodes=kind==='race'?v.gates.map(g=>g.node):kind==='fire'?v.spots.map(s=>s.node):v.clues;
 assert.equal(nodes.length,q.total);const expected=kind==='race'?[125,150,175]:kind==='fire'?[100,106,112]:[100,112];assert.deepEqual(nodes.map(n=>n.position.z+anchor.position.z),expected);
 f.world.originZ=80;anchor.position.copyFrom(f.world.toLocalPosition(q.position));v.update(q,.016);assert.deepEqual(nodes.map(n=>n.position.z+anchor.position.z+80),expected);
 q.progress=1;q.goal.targetIndex=1;if(kind==='fire'){q.position[2]=106;v.update(q,.016);assert.equal(v.spots[0].node.isEnabled(),false);assert.equal(v.spots[1].node.isEnabled(),true);}if(kind==='search'){v.update(q,.016);assert.equal(v.clues[0].isEnabled(),false);assert.equal(v.clues[1].isEnabled(),true);}v.dispose();anchor.dispose();f.world.originZ=0;}
 }finally{f.dispose();}
});
test('rescued companion follows to the safe point and remains there to celebrate',()=>{
 const f=fixture();try{const q=quest('rescue',{total:2,position:[0,0,128],goal:{phase:'escort'}}),anchor=new B.TransformNode('anchor',f.scene);const v=new MissionVisuals(f.world,q,anchor);f.world.avatar.root.position.set(0,0,115);v.update(q,.016);assert(v.person.root.position.z>110&&v.person.root.position.z<115);assert.equal(v.person.animationState,'walk');q.status='complete';v.update(q,.016);assert.equal(v.person.root.position.z,128);assert.equal(v.person.animationState,'wave');v.dispose();anchor.dispose();}finally{f.dispose();}
});
test('dash trails shift with floating origin instead of stretching across the city',()=>{
 const f=fixture();try{const trails=new LocomotionVisuals(f.world);trails.update(.016,'dash',new B.Vector3(0,0,260),Math.PI);trails.rebase(256);assert.equal(trails.samples[0].position.z,4);trails.update(.016,'dash',new B.Vector3(0,0,4.4),Math.PI);assert(trails.samples.every(s=>s.position.z<5));}finally{f.dispose();}
});
test('gait has grounded support, swing clearance, alternating feet and finite joints',()=>{
 for(const running of [false,true]){let support=0,swing=0;for(let i=0;i<200;i++){const p=i/200*Math.PI*2,s=gaitStep(p,{running}),g=gaitCycle(p,{running});assert([s.hip,s.knee,s.ankle,g.hipYaw,g.shoulderYaw].every(Number.isFinite));if(s.stance){support++;assert.equal(s.lift,0);}else{assert(s.lift>=0);swing++;}assert.equal(g.right.stance,gaitStep(p+Math.PI,{running}).stance);}assert(support>50&&swing>50);}
});
test('every mission prop variant can progress and dispose without accumulating meshes',()=>{
 const f=fixture();try{const baseline=f.scene.meshes.length;for(const [kind,object] of [['rescue','crates'],['escort','signal'],['delivery','books'],['race','stars'],['repair','crystal'],['repair','garden'],['repair','ice'],['fire','fire'],['defense','stones'],['search','trail']]){const q=quest(kind,{object}),anchor=new B.TransformNode('anchor',f.scene),v=new MissionVisuals(f.world,q,anchor);for(const phase of ['arrival','release','escort','pickup','delivery','repair','extinguish','race','scan','defend']){q.goal.phase=phase;q.progress=1;q.goal.targetIndex=1;v.update(q,.016);}q.status='complete';v.update(q,.016);assert(f.scene.meshes.every(m=>[m.position.x,m.position.y,m.position.z,...m.scaling.asArray()].every(Number.isFinite)));v.dispose();anchor.dispose();assert.equal(f.scene.meshes.length,baseline,kind+' left geometry behind');}}finally{f.dispose();}
});
