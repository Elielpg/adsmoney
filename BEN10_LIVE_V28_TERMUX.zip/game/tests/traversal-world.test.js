import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Adventure,MISSIONS} from '../server/adventure.js';
import {World} from '../public/world.js';
import {FORM_IDS} from '../public/transformations.js';
import {cityForDistance} from '../public/traversal.js';
function walker(){return {distance:0,laneX:0,time:0,form:0,altitude:0,heading:Math.PI,powerUntil:0,talking:false,helping:false,avatar:{root:{position:{y:0}}}};}
test('todos os 40 pedidos concluem com deslocamento linear e objetivos distintos, sem teleporte',()=>{
 const originalNow=Date.now;try{for(const spec of MISSIONS){let clock=0;Date.now=()=>clock;const a=new Adventure({now:0,random:()=>0});a.configure({autoMissions:false,autoTransform:true,autoPowers:true},0);const q=a.startMission(0,{missionKey:spec.key}),w=walker();let last=0,peak=0;
  for(clock=0;clock<300000;clock+=100){a.tick(clock);const state=a.snapshot();w.adventureState=state;w.form=FORM_IDS.indexOf(state.form);w.powerUntil=(state.power?.at||-10000)+(state.power?.duration||0);World.prototype.advanceLocomotion.call(w,.1,state.quest);assert(w.distance>=last-.001,spec.key+' voltou para trás');assert(w.distance-last<=2.5,spec.key+' teleportou');last=w.distance;peak=Math.max(peak,w.altitude);a.locate([w.laneX,w.altitude,w.distance],clock);if(q.status!=='active')break;}
  assert.equal(q.status,'complete',spec.key+' não concluiu: '+JSON.stringify(q.goal));assert.equal(a.completed,1);assert.equal(a.city,cityForDistance(w.distance).id);assert.equal(q.travel.arrived,true);if(spec.travelMode==='fly')assert(peak>=1);
 }}finally{Date.now=originalNow;}
});
test('caminhada livre progride em +Z e pausa quando Ben fala',()=>{const w=walker();for(let i=0;i<100;i++)World.prototype.advanceLocomotion.call(w,.1,null);assert(Math.abs(w.distance-16.5)<.001);assert.equal(w.laneX,0);assert.equal(w.heading,Math.PI);w.talking=true;for(let i=0;i<10;i++)World.prototype.advanceLocomotion.call(w,.1,null);assert(Math.abs(w.distance-16.5)<.001);});
test('dash linear usa de/fromZ e respeita pausa e conclusão',()=>{const originalNow=Date.now;try{let clock=1000;Date.now=()=>clock;const w=walker();w.form=2;w.adventureState={motion:{id:4,form:'volt',status:'active',mode:'dash',fromZ:100,toZ:120.4,fromX:0,toX:0,at:1000,duration:850}};World.prototype.advanceLocomotion.call(w,.1,null);assert.equal(w.distance,100);clock=1425;World.prototype.advanceLocomotion.call(w,.1,null);assert.equal(w.distance,110.2);w.adventureState.motion.paused=true;clock=1800;World.prototype.advanceLocomotion.call(w,.1,null);assert.equal(w.distance,110.2);w.adventureState.motion.status='complete';World.prototype.advanceLocomotion.call(w,0,null);assert.equal(w.distance,120.4);}finally{Date.now=originalNow;}});
