# LINEL.EXE Live City V25

Fan project experimental de passeio e conversa 3D. Executável localmente em Node e Chrome, com Babylon.js servido pelo próprio servidor. Não é afiliado ao TikTok nem aos titulares dos personagens de referência.

```sh
bash install.sh
bash start.sh
```

Abra no Chrome do mesmo aparelho o endereço de loopback do servidor, porta 3000 (ou PORT do `.env`). Toque no botão de música para liberar áudio. Use o painel para eventos DEMO, qualidade, regras e importação GLB.

- `npm test`: testes de domínio, integração HTTP/SSE e adaptador LIVE com transporte controlado.
- `npm run lint`: verificação de sintaxe JavaScript (não um linter semântico).
- `npm run build`: copia Babylon e licenças para assets locais, prepara `dist/public`.
- `bash doctor.sh`: diagnóstico com servidor iniciado, sem exibir chaves.
- `npm run package`: gera `../LINEL_LIVE_CITY_V25_TERMUX.zip`, sem `.env`, dados pessoais ou node_modules.
- `bash backup.sh`: exporta configuração/modelo locais sem chaves.

O jogo funciona em DEMO sem credenciais. Gemini real exige `GEMINI_API_KEY` exclusivamente no servidor. Modelos e permissões de API dependem do projeto Google. PirateTok é não oficial e a conexão real não foi validada nesta entrega. Não confunda testes de transporte com teste TikTok real.

Leia [status e limitações](reports/FINAL_STATUS.md), [Termux](docs/TERMUX.md), [integrações](docs/INTEGRACOES.md), [arquitetura](docs/ARQUITETURA.md) e [assets](docs/ASSETS_E_ANIMACOES.md).
