# LINEL.EXE Live City V25

Fan project experimental de passeio e conversa 3D. Executável localmente em Node e Chrome, com Babylon.js servido pelo próprio servidor. Não é afiliado ao TikTok nem aos titulares dos personagens de referência.

```sh
bash install.sh
bash start.sh
```

Abra no Chrome do mesmo aparelho o endereço de loopback do servidor, porta 3000 (ou PORT do `.env`). Toque no botão de música para liberar áudio. Use o painel para eventos DEMO, qualidade, regras e importação GLB.

- `npm test`: testes de domínio, integração HTTP/SSE e adaptador LIVE com transporte controlado.
- `npm run lint`: verificação de sintaxe JavaScript (não um linter semântico).
- `npm run build`: copia Babylon e licenças para assets locais, prepara `dist/public`.
- `bash doctor.sh`: diagnóstico com servidor iniciado, sem exibir chaves.
- `npm run package`: gera `../LINEL_LIVE_CITY_V25_TERMUX.zip`, sem `.env`, dados pessoais ou node_modules.
- `bash backup.sh`: exporta configuração/modelo locais sem chaves.

O jogo funciona em DEMO sem credenciais. Em **Painel → IA e voz → Chaves Gemini**, cadastre até 20 chaves com nomes e selecione uma. Elas são salvas somente no servidor local, com permissões restritas; não retornam ao navegador e ficam fora do ZIP/backup. Alternativamente use `GEMINI_API_KEY` no `.env`. Não há rodízio automático para contornar cotas. Modelos e permissões de API dependem do projeto Google. PirateTok é não oficial e a conexão real não foi validada nesta entrega. Não confunda testes de transporte com teste TikTok real.

Leia [status e limitações](reports/FINAL_STATUS.md), [Termux](docs/TERMUX.md), [integrações](docs/INTEGRACOES.md), [arquitetura](docs/ARQUITETURA.md) e [assets](docs/ASSETS_E_ANIMACOES.md).

## Aventura automática

Veja docs/AVENTURA.md. O chat reconhece nomes de aliens; pedidos dos NPCs criam objetivos reais; o botão ✹ usa poderes. Em Ajustes você pode ligar/desligar transformações, missões, poderes e narração automáticos. Também é possível importar um GLB por forma. A boca reage ao áudio quando o modelo tem geometria ou morph target compatível. A voz e os modelos oficiais não estão incluídos.

## Modelos incluídos e voz opcional

Agora o pacote inclui nove GLBs de terceiros com licença CC BY 4.0 e créditos em docs/MODEL_CREDITS.md. A lista real de rigs, clipes e limitações está em docs/ASSETS_E_ANIMACOES.md. Alien X e Cipó Selvagem continuam procedurais. Nem todos os modelos têm caminhada ou boca animada.

Para voz, Gemini continua disponível e ElevenLabs pode ser configurado em IA e voz com a chave e uma voz da sua conta. Nenhuma voz oficial do Ben 10 está incluída. Leia docs/INTEGRACOES.md. Se aparecer porta ocupada, encerre a sessão anterior com Ctrl+C ou use explicitamente PORT=3001 bash start.sh.

## Correção das animações

As onze formas agora usam articulação e skin em runtime, com caminhada, repouso, gestos de fala e movimentos de cauda/flutuação. Orientação, altura e câmera são calibradas por forma. Veja docs/ANIMACOES.md e as evidências em reports/motion/. São animações procedurais, não clipes oficiais do desenho.
