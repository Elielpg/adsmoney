import {test} from 'node:test';import assert from 'node:assert/strict';import {EventEmitter} from 'node:events';import {LiveAdapter} from '../server/live.js';
test('PirateTok só confirma socket depois da promessa; normaliza eventos e limpa listeners',async()=>{let release;let client;class Fake extends EventEmitter{constructor(){super();client=this;}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){this.emit('connected',{roomId:'123'});return new Promise(r=>release=r);}disconnect(){this.stopped=true;}}
const events=[],states=[];const adapter=new LiveAdapter((e,s)=>events.push({e,s}),s=>states.push({...s}),{load:async()=>({TikTokLiveClient:Fake})});const connecting=adapter.connect('@teste','piratetok');await new Promise(r=>setImmediate(r));assert.equal(adapter.state.status,'sala resolvida');assert(!states.some(s=>s.status==='websocket confirmado'));release('123');await connecting;assert.equal(adapter.state.status,'websocket confirmado');client.emit('chat',{common:{msgId:'abc'},user:{uniqueId:'ana'},content:'Olá'});assert.equal(events[0].e.text,'Olá');assert.equal(events[0].s,'tiktok');client.emit('gift',{user:{uniqueId:'ana'},gift:{name:'Rose'},repeatCount:3,isStreakOver:true});assert.equal(events[1].e.count,3);assert.equal(events[1].e.repeatEnd,true);await adapter.disconnect();assert(client.stopped);assert.equal(client.listenerCount('chat'),0);assert.equal(adapter.state.status,'desconectado');});
test('falha externa nunca vira conexão confirmada',async()=>{const adapter=new LiveAdapter(()=>{},()=>{},{maxAttempts:2,retryDelay:()=>0,load:async()=>{throw Error('Rede indisponível');}});await adapter.connect('@teste','piratetok');assert.equal(adapter.state.status,'erro');assert.equal(adapter.state.error,'Rede indisponível');await adapter.disconnect();});

test('normaliza @ e mantém diagnósticos e contadores da LIVE',async()=>{const {normalizeUsername,liveError}=await import('../server/live.js');assert.equal(normalizeUsername('  @usuario.teste  '),'usuario.teste');assert.throws(()=>normalizeUsername('https://tiktok.com/@teste'));assert.throws(()=>normalizeUsername('@a b'));assert.match(liveError(Error('User not live')),/não está ao vivo/);assert.match(liveError(Error('HTTP 403 forbidden')),/bloqueou/);let client;class Fake extends EventEmitter{constructor(){super();client=this;}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}async connect(){return '123';}disconnect(){}}const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>({TikTokLiveClient:Fake})});await adapter.connect(' @test.name ','piratetok');client.emit('like',{count:1});assert.equal(adapter.state.username,'test.name');assert.equal(adapter.state.events,1);assert(adapter.state.lastEventAt>0);await adapter.disconnect();assert.equal(adapter.state.roomId,null);});

test('causa real sanitizada aparece e bloqueio explícito não entra em loop de regiões',async()=>{
 const {liveDiagnostic}=await import('../server/live.js');let calls=0;
 const cause=Object.assign(Error('Proxy HTTP 403 sessionid=private-value https://user:secret@proxy.example/path?token=hidden'),{code:'ECONNRESET'});
 const error=Error('fetch failed',{cause});const detail=liveDiagnostic(error);assert.match(detail,/403/);assert.match(detail,/ECONNRESET/);assert(!detail.includes('private-value'));assert(!detail.includes('secret'));assert(!detail.includes('hidden'));
 const adapter=new LiveAdapter(()=>{},()=>{},{retryDelay:()=>0,load:async()=>{calls++;throw error;}});await adapter.connect('@teste','piratetok');assert.equal(calls,1);assert.equal(adapter.state.status,'erro');assert.match(adapter.state.error,/bloqueou/);assert.match(adapter.state.detail,/403/);await adapter.disconnect();
});

test('timeout de handshake troca CDN e só confirma a tentativa que abriu socket',async()=>{
 const clients=[];class Fake extends EventEmitter{constructor(){super();clients.push(this);}timeout(){return this;}maxRetries(n){assert.equal(n,0);return this;}proxy(){return this;}cdn(value){this.endpoint=value;return this;}connect(){this.emit('connected',{roomId:'456'});return clients.length===1?new Promise(()=>{}):Promise.resolve('456');}disconnect(){this.stopped=true;}}
 const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>({TikTokLiveClient:Fake}),connectTimeoutMs:10,retryDelay:()=>0});await adapter.connect('@teste','piratetok');assert.equal(clients.length,2);assert.equal(clients[0].stopped,true);assert.equal(clients[0].endpoint,'webcast-ws.tiktok.com');assert.equal(clients[1].endpoint,'webcast-ws.us.tiktok.com');assert.equal(adapter.state.status,'websocket confirmado');assert.equal(adapter.state.roomId,'456');assert.equal(clients[0].listenerCount('chat'),0);await adapter.disconnect();
});

test('perda do socket reconecta e confirma nova promessa sem precisar de comentário',async()=>{
 const clients=[];class Fake extends EventEmitter{constructor(){super();clients.push(this);}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){return Promise.resolve('789');}disconnect(){this.stopped=true;}}
 const states=[],adapter=new LiveAdapter(()=>{},s=>states.push(s),{load:async()=>({TikTokLiveClient:Fake}),retryDelay:()=>0});await adapter.connect('@teste','piratetok');clients[0].emit('disconnected');await new Promise(r=>setTimeout(r,10));assert.equal(clients.length,2);assert.equal(adapter.state.status,'websocket confirmado');assert(states.some(s=>s.status==='reconectando'));assert.equal(clients[0].listenerCount('chat'),0);await adapter.disconnect();
});

test('desconectar cancela tentativa pendente, evita cliente antigo e preserva próximo usuário',async()=>{
 const clients=[];let release;class Fake extends EventEmitter{constructor(username){super();this.username=username;clients.push(this);}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){return this.username==='primeiro'?new Promise(r=>release=r):Promise.resolve('999');}disconnect(){this.stopped=true;}}
 const events=[],adapter=new LiveAdapter(e=>events.push(e),()=>{},{load:async()=>({TikTokLiveClient:Fake}),connectTimeoutMs:1000,retryDelay:()=>0});const first=adapter.connect('@primeiro','piratetok');await new Promise(r=>setImmediate(r));await adapter.connect('@segundo','piratetok');release('111');await first;clients[0].emit('chat',{content:'antigo'});assert.equal(adapter.state.username,'segundo');assert.equal(adapter.state.roomId,'999');assert.equal(adapter.state.status,'websocket confirmado');assert.equal(events.length,0);assert.equal(clients[0].stopped,true);await adapter.disconnect();
});

test('desligar durante backoff não cria cliente depois e região manual é validada',async()=>{
 let calls=0;const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>{calls++;throw Error('Timeout de socket');},retryDelay:()=>1000});const pending=adapter.connect('@teste','piratetok');await new Promise(r=>setImmediate(r));assert.equal(adapter.state.status,'reconectando');await adapter.disconnect();await pending;assert.equal(calls,1);assert.equal(adapter.state.status,'desconectado');await assert.rejects(()=>adapter.connect('@teste','piratetok',{endpoint:'invalid'}),/Região/);
});

test('lookup termina depois de cancelar e seu socket não fica aberto em segundo plano',async()=>{
 let releaseLookup,old;class Fake extends EventEmitter{constructor(){super();old=this;this.aborted=false;}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){return new Promise(resolve=>releaseLookup=()=>{this.emit('connected',{roomId:'late'});if(!this.aborted)this.socketOpened=true;resolve('late');});}disconnect(){this.aborted=true;}}
 const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>({TikTokLiveClient:Fake})});const pending=adapter.connect('@teste','piratetok');await new Promise(r=>setImmediate(r));await adapter.disconnect();await pending;releaseLookup();await new Promise(r=>setImmediate(r));assert.notEqual(old.socketOpened,true);assert.equal(adapter.state.status,'desconectado');assert.equal(old.listenerCount('chat'),0);
});

test('socket instável não reinicia orçamento e para após quatro aberturas curtas',async()=>{
 const clients=[];class Fake extends EventEmitter{constructor(){super();clients.push(this);}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){return Promise.resolve('123');}disconnect(){}}
 const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>({TikTokLiveClient:Fake}),retryDelay:()=>0,now:()=>1000,maxAttempts:4});await adapter.connect('@teste','piratetok');
 for(let i=0;i<4;i++){clients.at(-1).emit('disconnected');await new Promise(r=>setTimeout(r,3));}
 assert.equal(clients.length,4);assert.equal(adapter.state.status,'erro');assert.equal(adapter.state.attempt,4);await adapter.disconnect();
});

test('sessão saudável restaura orçamento ao perder socket sem espera real no teste',async()=>{
 const clients=[];let now=0;class Fake extends EventEmitter{constructor(){super();clients.push(this);}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){return Promise.resolve('123');}disconnect(){}}
 const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>({TikTokLiveClient:Fake}),retryDelay:()=>0,now:()=>now,maxAttempts:2});await adapter.connect('@teste','piratetok');now=40000;clients[0].emit('disconnected');await new Promise(r=>setTimeout(r,5));assert.equal(clients.length,2);assert.equal(adapter.state.status,'websocket confirmado');assert.equal(adapter.state.attempt,1);await adapter.disconnect();
});

test('automático usa API moderna assinada após falha transitória e normaliza presentes finais',async()=>{
 const loaded=[],events=[],optionsSeen=[];class Pirate extends EventEmitter{timeout(){return this;}maxRetries(){return this;}proxy(){return this;}connect(){this.emit('connected',{roomId:'123'});return Promise.reject(Error('Socket encerrou antes da confirmação'));}disconnect(){}}
 let alternate;class Modern extends EventEmitter{constructor(username,options){super();alternate=this;optionsSeen.push(options);}async connect(roomId){assert.equal(roomId,'123');return {isConnected:true,roomId};}disconnect(){}}
 const adapter=new LiveAdapter(e=>events.push(e),()=>{},{retryDelay:()=>0,load:async name=>{loaded.push(name);return name==='piratetok-live-js'?{TikTokLiveClient:Pirate}:{TikTokLiveConnection:Modern};}});await adapter.connect('@teste','auto');assert.deepEqual(loaded,['piratetok-live-js','tiktok-live-connector']);assert.equal(adapter.state.provider,'alternative');assert.equal(adapter.state.requestedProvider,'auto');assert.equal(adapter.state.status,'websocket confirmado');assert.equal(optionsSeen[0].processInitialData,false);assert.equal(optionsSeen[0].authenticateWs,false);
 alternate.emit('chat',{content:'Chama',user:{displayId:'modern-user'}});assert.equal(events.at(-1).user,'modern-user');events.length=0;alternate.emit('gift',{gift:{type:1,name:'Rose'},repeatEnd:0,repeatCount:2,user:{uniqueId:'ana'}});alternate.emit('gift',{gift:{type:1,name:'Rose'},repeatEnd:1,repeatCount:3,user:{uniqueId:'ana'}});assert.equal(events[0].repeatEnd,false);assert.equal(events[1].repeatEnd,true);alternate.emit('streamEnd');assert.equal(adapter.state.status,'desconectado');assert.equal(adapter.state.error,'LIVE encerrada');await adapter.disconnect();
});

test('erro.exception do conector moderno mantém causa e erro impeditivo não aciona fallback',async()=>{
 let client;class Modern extends EventEmitter{constructor(){super();client=this;}async connect(){this.emit('error',{exception:Error('HTTP 429 rate limit'),info:'connect'});throw Error('HTTP 429 rate limit');}disconnect(){}}
 const adapter=new LiveAdapter(()=>{},()=>{},{load:async()=>({TikTokLiveConnection:Modern}),retryDelay:()=>0});await adapter.connect('@teste','alternative');assert.equal(adapter.state.status,'erro');assert.match(adapter.state.detail,/429/);assert.equal(adapter.state.attempt,1);await adapter.disconnect();
 let calls=0;const blocked=new LiveAdapter(()=>{},()=>{},{retryDelay:()=>0,load:async()=>{calls++;throw Error('Proxy HTTP 403 forbidden');}});await blocked.connect('@teste','auto');assert.equal(calls,1);assert.equal(blocked.state.status,'erro');await blocked.disconnect();
});

test('pacote real 2.5.0 abre WebSocket local e decodifica frame protobuf com comentário',async()=>{
 const {WebSocketServer}=await import('ws'),mod=await import('tiktok-live-connector'),{createAlternativeClient}=await import('../server/live-alternative.js');
 assert.equal(typeof mod.TikTokLiveConnection,'function');assert.equal(mod.WebcastPushConnection,undefined);const socket=new WebSocketServer({host:'127.0.0.1',port:0});await new Promise(r=>socket.once('listening',r));const saved=mod.RouteConfig.fetchSignedWebSocketFromProvider;let transport;
 try{
  const empty=()=>new Uint8Array();const room='123456',initial=mod.ProtoMessageFetchResult.decode(empty());initial.cursor='controlled-cursor';initial.pushServer='ws://127.0.0.1:'+socket.address().port+'/webcast/im/';
  mod.RouteConfig.fetchSignedWebSocketFromProvider=async()=>({fetchResult:initial,fetchResultCookieHeader:'ttwid=controlled-fixture',fetchResultRoomId:room});
  transport=await createAlternativeClient(mod,'teste',{proxy:''});const chatReceived=new Promise((resolve,reject)=>{transport.once('chat',resolve);transport.once('error',e=>reject(e.exception||e));});
  socket.once('connection',peer=>{setTimeout(()=>{const chat=mod.WebcastChatMessage.decode(empty());chat.content='Chama';chat.user=mod.User.decode(empty());chat.user.displayId='controlled-viewer';chat.common=mod.CommonMessageData.decode(empty());chat.common.msgId='999';const message=mod.BaseProtoMessage.decode(empty());message.method='WebcastChatMessage';message.payload=mod.WebcastChatMessage.encode(chat).finish();const response=mod.ProtoMessageFetchResult.decode(empty());response.messages=[message];response.cursor='next';const frame=mod.createBaseWebcastPushFrame({payload:mod.ProtoMessageFetchResult.encode(response).finish()});peer.send(frame.finish());},20);});
  const state=await transport.connect(room);assert.equal(state.isConnected,true);assert.equal(state.roomId,room);const data=await Promise.race([chatReceived,new Promise((_,reject)=>setTimeout(()=>reject(Error('Sem frame controlado')),1500).unref())]);assert.equal(data.content,'Chama');assert.equal(data.user.displayId,'controlled-viewer');
 }finally{mod.RouteConfig.fetchSignedWebSocketFromProvider=saved;await transport?.disconnect();for(const peer of socket.clients)peer.terminate();await new Promise(r=>socket.close(r));}
});

test('recusa de upgrade sem assinatura usa fallback; CAPTCHA, proxy e DEVICE_BLOCKED param',async()=>{
 const {unsignedUpgradeRejected}=await import('../server/live.js');assert(unsignedUpgradeRejected(Error('WSS handshake rejected: HTTP 403 handshake-msg= handshake-status=?')));for(const detail of ['Proxy response (403) !== 200 when HTTP Tunneling','WSS handshake rejected: HTTP 403 handshake-msg=DEVICE_BLOCKED','WSS handshake rejected: HTTP 403 CAPTCHA'])assert.equal(unsignedUpgradeRejected(Error(detail)),false);
 const names=[];class Pirate extends EventEmitter{timeout(){return this;}maxRetries(){return this;}proxy(){return this;}async connect(){throw Error('WSS handshake rejected: HTTP 403 handshake-msg= handshake-status=?');}disconnect(){}}
 class Signed extends EventEmitter{async connect(){return {isConnected:true,roomId:'123'};}disconnect(){}}
 const adapter=new LiveAdapter(()=>{},()=>{},{retryDelay:()=>0,load:async name=>{names.push(name);return name==='piratetok-live-js'?{TikTokLiveClient:Pirate}:{TikTokLiveConnection:Signed};}});await adapter.connect('@teste','auto');assert.equal(adapter.state.status,'websocket confirmado');assert.equal(adapter.state.provider,'alternative');assert.deepEqual(names,['piratetok-live-js','tiktok-live-connector']);await adapter.disconnect();
});
