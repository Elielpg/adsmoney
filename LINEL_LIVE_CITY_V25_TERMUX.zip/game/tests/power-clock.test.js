import {test} from 'node:test';
import assert from 'node:assert/strict';
import {advancePowerTime,powerFrame} from '../public/power-timeline.js';
test('power clock catches up after a throttled frame and reaches recovery before cooldown',()=>{
 const effect={time:.2,startedAt:1000};
 effect.time=advancePowerTime(effect,.12,3200);
 assert.equal(effect.time,2.2);
 assert.equal(powerFrame('blaze',effect.time).phase,'recovery');
 effect.time=advancePowerTime(effect,.12,3500);
 assert(powerFrame('blaze',effect.time).done);
});
test('power clock preserves deliberate simulation steps and cannot go backwards',()=>{
 const effect={time:1.5,startedAt:1000};
 effect.time=advancePowerTime(effect,.5,1100);
 assert.equal(effect.time,2);
 effect.time=advancePowerTime(effect,.1,500);
 assert.equal(effect.time,2.1);
});
