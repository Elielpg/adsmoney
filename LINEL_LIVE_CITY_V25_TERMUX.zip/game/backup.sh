#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYTHON'
from pathlib import Path
import zipfile,datetime
p=Path('data');out=Path('backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file():z.write(f)
print(str(out)+' (sem .env)')
PYTHON
