from pathlib import Path
import zipfile
root=Path(__file__).resolve().parent.parent
out=root.parent/'LINEL_LIVE_CITY_V25_TERMUX.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or any(x in ('node_modules','data','dist','.git') for x in rel.parts) or (p.name.startswith('.env') and p.name!='.env.example') or p.suffix=='.zip': continue
  z.write(p,Path('game')/rel)
print(out)
