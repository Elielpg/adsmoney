#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v pkg >/dev/null 2>&1; then pkg install -y nodejs-lts python; fi
node -e 'const [a,b]=process.versions.node.split(".").map(Number);if(a<22||(a===22&&b<19))throw Error("Node >=22.19 necessário")'
npm ci --omit=dev --no-audit --no-fund
mkdir -p data/models
node scripts/check.js
npm test
npm run build
printf 'Instalação concluída. Configure IA e voz no painel e execute bash start.sh\n'
