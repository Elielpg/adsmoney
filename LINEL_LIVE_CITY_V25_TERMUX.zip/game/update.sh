#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if node --env-file-if-exists=.env --input-type=module -e 'try{const r=await fetch("http://127.0.0.1:"+(process.env.PORT||3000)+"/api/health",{signal:AbortSignal.timeout(1000)});const d=await r.json();process.exit(d.application==="LINEL_LIVE_CITY_V25"?0:1)}catch{process.exit(1)}' >/dev/null 2>&1; then
 printf 'Pare o servidor com Ctrl+C na sessão onde ele está rodando e execute bash update.sh novamente.\n'
 exit 1
fi
command -v curl >/dev/null || { printf 'Instale curl: pkg install curl\n'; exit 1; }
command -v unzip >/dev/null || { printf 'Instale unzip: pkg install unzip\n'; exit 1; }
update_tmp=$(mktemp -d)
trap 'rm -rf "$update_tmp"' EXIT
curl --fail --location --retry 2 'https://github.com/Elielpg/adsmoney/raw/refs/heads/main/LINEL_LIVE_CITY_V25_TERMUX.zip' -o "$update_tmp/game.zip"
python - "$update_tmp/game.zip" <<'PY'
import sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
 if z.testzip():raise SystemExit('ZIP danificado')
 for n in z.namelist():
  if not n.startswith('game/') or '..' in n.split('/') or '/data/' in n or n.endswith('/.env'):raise SystemExit('Caminho inesperado no ZIP')
PY
unzip -oq "$update_tmp/game.zip" -d "$(dirname "$PWD")"
bash install.sh
printf 'Atualização instalada. Execute bash start.sh e confira a versão no topo da tela.\n'
