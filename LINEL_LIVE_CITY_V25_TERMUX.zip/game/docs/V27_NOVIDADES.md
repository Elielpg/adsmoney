# V27 — treino visível e conexão por @

A tela inicial desta entrega tem **Ver novos poderes**, **Conectar meu TikTok** e **Explorar a cidade**. O topo mostra v27.0.0. Não é preciso configurar Gemini, liberar áudio ou esperar uma missão para ver o treino. Uma conversa pendente sem áudio também não bloqueia essa demonstração.

No treino há quatro atalhos: Chama, Diamante, Quatro Braços e XLR8. São animações do motor 3D em tempo real: bola de fogo e explosão com volume, parede de cristais e fragmentos, braços levantando e golpeando com ondas no chão, dash e rastros de velocidade. A câmera fica atrás e ao lado para mostrar herói e alvo; os controles se recolhem durante o golpe. O treino pausa a automação temporariamente e não soma pontos, consome conversa ou conclui missão. Ao voltar, a forma e a missão reais são restauradas.

A gravação em reports/v27/novos-poderes.webm e as imagens na mesma pasta foram produzidas pelo canvas WebGL. A gravação inclui pausas curtas para salvar os quadros de cada fase; não representa medição de FPS de Android. reports/showcase-browser.json registra as fases visíveis, geometria e erros do navegador. reports/training-browser.json verifica o treino sem Gemini/áudio com uma pergunta já aguardando na fila.

## TikTok

Esta versão inclui os dois conectores no npm ci. O modo Automático tenta PirateTok e depois TikTok-Live-Connector2.5.0 para falhas de transporte compatíveis. O segundo usa a API moderna TikTokLiveConnection e o serviço público de assinatura Euler, sujeito à disponibilidade e limites dele. Não há assinatura paga, chave ou sessão de conta embutida. Consulte LIVE_CELULAR.md para os códigos e os modos manuais. Não são reapresentados eventos de histórico como presentes novos.

O receptor foi testado também com a biblioteca real abrindo um WebSocket local e decodificando um frame de comentário protobuf. Isso comprova o código de transporte/decodificação, não o acesso à infraestrutura de produção do TikTok. O teste de @linel.exe nesta cloud permanece bloqueado pelo proxy antes do serviço, sem handshake ou evento real. O contador na interface só registra eventos que o conector recebeu; nenhuma sala resolvida é apresentada como recepção validada.

## Atualização correta no celular

Leia ATUALIZAR_CELULAR.md. O pacote novo chama-se BEN10_LIVE_V27_TERMUX.zip. O arquivo antigo é mantido somente como alias de compatibilidade; ambos têm o mesmo conteúdo. O atualizador verifica arquivos/versão e preserva data/, .env e modelos próprios. Ele só encerra processo Node quando consegue confirmar usuário, pasta real e comando exatos desta instalação. Se o Android negar essa verificação, pede Ctrl+C e não encerra outros programas.

A distribuição agora contém código-fonte e licença AGPL3 do jogo e do segundo conector, preservando as licenças dos modelos e demais componentes. Consulte LICENSE, third_party/NOTICE.md e docs/MODEL_CREDITS.md. Os personagens e as animações continuam sendo um fan project estilizado, sem clipes ou vozes oficiais do desenho.
