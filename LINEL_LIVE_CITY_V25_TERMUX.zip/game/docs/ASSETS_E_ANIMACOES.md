# Assets e animações

Não foram recebidos legacy_v24, sprites, AIR/CNS/CMD ou modelos do kit original. O usuário autorizou prosseguir sem o personagem descartável do ZIP inacessível. Não há auditoria fictícia desses materiais.

Os onze modelos são geometrias procedurais originais simplificadas: humano base; chama com pontas; velocista fino com cauda; cristais; fantasma afilado; aquático com barbatanas; figura estrelada; besta baixa; quatro braços; esfera; cipó com ramificações. Não são modelos fiéis aos personagens licenciados. São articulados por transformação de partes, NÃO possuem esqueletos autorais nem skinning. Isso é uma limitação visual desta versão.

Upload de GLB 2.0 real pelo painel carrega meshes, texturas embutidas e esqueletos que existirem no arquivo. Modelo é normalizado para altura de 2,6 unidades e pés no solo. Grupos cujo nome inclui walk, talk ou idle são usados. Outros grupos são preservados no import, mas ainda não há mapeamento manual nem correção geral de root motion; crossfade básico usa pesos de animation groups nem garantia contra deformação de assets arbitrários. Importação foi testada com um GLB original de integração: triângulo com um osso, skin e três animações idle/walk/talk. A reprodução de um personagem complexo de terceiros ainda precisa de um asset redistribuível e validação visual.

Música original: sequência procedural de oito notas, sintetizada localmente. Efeitos: dois tons de transformação/presente. Canais têm controles separados; música baixa durante fala. Não há trilha comercial, modelo de terceiros ou sprite sem licença redistribuído.

Babylon.js e loaders 9.32.1: Apache-2.0, licenças incluídas em public/vendor após build. PirateTok: 0BSD; undici: MIT; playwright-core: Apache-2.0, somente desenvolvimento. Veja manifests e lockfile para dependências transitivas.

## Revisão visual posterior

O humano principal foi reconstruído com roupa clássica de 2005, cabelo em mechas, rosto com olhos/íris/pupilas/sobrancelhas/nariz/boca/orelhas, calça cargo, tênis com cadarços e Omnitrix no pulso esquerdo. Pivôs hierárquicos de ombros, cotovelos, quadris, joelhos e cabeça animam as partes. Continua sendo uma interpretação estilizada autoral, não modelo oficial nem escultura validada contra turnarounds. Os dez aliens continuam na geometria procedural anterior.

Foi tentado consultar https://www.cartoonnetwork.com/show/ben-10; o proxy retornou CONNECT 403. Nenhuma imagem oficial foi baixada ou inspecionada. Não se deve afirmar que foram usadas referências oficiais verificadas. Para correspondência visual rigorosa, faltam imagens do clássico disponibilizadas pelo usuário ou acesso a uma fonte visual autorizada.

Cidade revisada com vitrines/divisórias, marquises listradas, janelas com molduras e floreiras, seis letreiros locais, postes, mesas de café, pérgola, fonte em camadas, plantadores e textura de pavimento criada por código. Meshes estáticos são fundidos por material/colisão para reduzir chamadas de desenho. Capturas reais: mobile-city.png e city-overview.png.

## Modelos reais incluídos após pesquisa no GitHub

Foram encontrados modelos no repositório naviniitk/ben10_3d. Os próprios GLBs possuem `asset.extras` com autoria, origem Sketchfab e licença CC BY 4.0. Nove arquivos foram preservados byte a byte, com hashes e créditos em MODEL_CREDITS.md e public/bundled-models/manifest.json. O ZIP inclui esses arquivos e o servidor os usa por padrão; importações locais do usuário têm precedência por forma.

Cobertura: Ben clássico, Chama (variante Omniverse), XLR8, Diamante, Fantasmático, Aquático, Besta, Quatro Braços e Bola de Canhão. Alien X e Cipó Selvagem continuam nas formas procedurais originais. Não se afirma correspondência perfeita com uma única série. Os modelos variam em topologia, proporções e origem; são trabalhos publicados por modeladores, não uma certificação dos titulares do desenho.

Ben clássico tem esqueleto, mas não clipes. Foi adicionada articulação procedural em ombros/cotovelos/quadris/joelhos. Não é uma animação profissional já fornecida pelo autor. XLR8 tem animação de máscara; Besta tem esqueleto sem clipes. Os outros seis arquivos são estáticos. Nenhum desses nove GLBs tem morph de boca compatível reconhecido. A animação de boca existente continua disponível em GLBs com morph facial e no humano procedural, mas o rosto do Ben incluído ainda precisa de rig facial. Não se deve descrever esses nove modelos como “completamente animados”.

O Chromium importou e renderizou todos os nove, com texturas, sem erros JavaScript. Capturas em reports/models/ e dados em reports/bundled-models.json. A orientação frontal foi corrigida em runtime. Essas verificações não substituem medição de FPS/temperatura no Android.
