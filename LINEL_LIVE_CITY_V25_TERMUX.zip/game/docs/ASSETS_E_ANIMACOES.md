# Assets e animações

Não foram recebidos legacy_v24, sprites, AIR/CNS/CMD ou modelos do kit original. O usuário autorizou prosseguir sem o personagem descartável do ZIP inacessível. Não há auditoria fictícia desses materiais.

Os onze modelos são geometrias procedurais originais simplificadas: humano base; chama com pontas; velocista fino com cauda; cristais; fantasma afilado; aquático com barbatanas; figura estrelada; besta baixa; quatro braços; esfera; cipó com ramificações. Não são modelos fiéis aos personagens licenciados. São articulados por transformação de partes, NÃO possuem esqueletos autorais nem skinning. Isso é uma limitação visual desta versão.

Upload de GLB 2.0 real pelo painel carrega meshes, texturas embutidas e esqueletos que existirem no arquivo. Modelo é normalizado para altura de 2,6 unidades e pés no solo. Grupos cujo nome inclui walk, talk ou idle são usados. Outros grupos são preservados no import, mas ainda não há mapeamento manual nem correção geral de root motion; crossfade básico usa pesos de animation groups nem garantia contra deformação de assets arbitrários. Importação foi testada com um GLB original de integração: triângulo com um osso, skin e três animações idle/walk/talk. A reprodução de um personagem complexo de terceiros ainda precisa de um asset redistribuível e validação visual.

Música original: sequência procedural de oito notas, sintetizada localmente. Efeitos: dois tons de transformação/presente. Canais têm controles separados; música baixa durante fala. Não há trilha comercial, modelo de terceiros ou sprite sem licença redistribuído.

Babylon.js e loaders 9.32.1: Apache-2.0, licenças incluídas em public/vendor após build. PirateTok: 0BSD; undici: MIT; playwright-core: Apache-2.0, somente desenvolvimento. Veja manifests e lockfile para dependências transitivas.

## Revisão visual posterior

O humano principal foi reconstruído com roupa clássica de 2005, cabelo em mechas, rosto com olhos/íris/pupilas/sobrancelhas/nariz/boca/orelhas, calça cargo, tênis com cadarços e Omnitrix no pulso esquerdo. Pivôs hierárquicos de ombros, cotovelos, quadris, joelhos e cabeça animam as partes. Continua sendo uma interpretação estilizada autoral, não modelo oficial nem escultura validada contra turnarounds. Os dez aliens continuam na geometria procedural anterior.

Foi tentado consultar https://www.cartoonnetwork.com/show/ben-10; o proxy retornou CONNECT 403. Nenhuma imagem oficial foi baixada ou inspecionada. Não se deve afirmar que foram usadas referências oficiais verificadas. Para correspondência visual rigorosa, faltam imagens do clássico disponibilizadas pelo usuário ou acesso a uma fonte visual autorizada.

Cidade revisada com vitrines/divisórias, marquises listradas, janelas com molduras e floreiras, seis letreiros locais, postes, mesas de café, pérgola, fonte em camadas, plantadores e textura de pavimento criada por código. Meshes estáticos são fundidos por material/colisão para reduzir chamadas de desenho. Capturas reais: mobile-city.png e city-overview.png.
