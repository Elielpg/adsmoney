# Transformações, missões e poderes

No painel Ajustes, configure transformações automáticas, pedidos dos NPCs, poderes automáticos e narração dos pedidos. Os intervalos vão de 15 a 600 segundos e são salvos localmente. Por padrão há transformações a cada 90 segundos e pedidos a cada 45 segundos. Uma missão ativa recebe prioridade sobre a rotação automática.

O chat DEMO e TikTok usam o mesmo reconhecimento de nomes: Ben 10, Chama, XLR8, Diamante, Fantasmático, Aquático, Alien X, Besta, Quatro Braços, Bola de Canhão e Cipó Selvagem. Exemplo: “Ben 10, vira Chama!” e “Chama, use seu poder”. Também há aliases em inglês. As mensagens são dados, não código. Pedidos de transformação aguardam o fim da fala e um intervalo mínimo de oito segundos entre pedidos do chat. A seleção manual no painel é imediata quando não há fala. A forma retorna ao humano após 60 segundos, salvo quando uma missão ativa pede outra forma.

O botão ✹ usa o poder da forma atual. O chat pode dizer “poder” ou “usar habilidade”. O poder tem recarga de 2,5 segundos. Se uma mensagem pede uma forma e seu poder, o poder aguarda essa forma. Efeitos são procedurais (calor, água, cristais, cipós, velocidade e outros), não animações oficiais.

NPCs pedem ajuda para dez problemas: jardim murcho, caixas bloqueando passagem, cristal partido, reservatório congelado, pequeno foco de fogo, transmissor atrás da grade, livros espalhados, rastro de um cachorro, pedras na trilha e luzes apagadas. Cada missão cria um objeto concreto e pede uma forma. É necessário chegar a 4,5 unidades do objetivo e usar três poderes corretos. Plantas crescem, caixas saem do caminho, gelo/fogo encolhe, cristais se recompõem, livros se organizam e objetos mudam de estado. O contador só aumenta após cumprir essas condições.

Com automação ligada, o avatar para perto do objetivo e executa a ajuda, respeitando as falas. A narração usa a mesma fila local exclusiva do áudio do operador; pedidos não interrompem uma resposta de espectador. Há um único navegador operador suportado. A posição é reportada pelo cliente local, portanto isto não é um protocolo competitivo resistente a trapaça. Progresso de missão é de sessão; opções persistem.

## Modelos e boca

Em Ajustes, selecione a forma e envie um GLB autorizado. Cada forma pode ter seu próprio arquivo persistido. O carregador reconhece idle/walk/talk e morph targets mouthOpen, jawOpen, viseme_aa ou viseme_a. Os modelos são normalizados em altura e a importação obsoleta é descartada quando ocorre outra transformação.

A boca é guiada pela amplitude do áudio reproduzido via Web Audio. No TTS do navegador, a abertura é aproximada por eventos/tempo, pois speechSynthesis não fornece PCM. Não há alinhamento de fonemas nem clonagem de voz. GLBs sem morph target compatível continuam sem animação facial; não é possível criar um rig facial correto automaticamente para qualquer modelo.

Os onze modelos atuais NÃO são cópias perfeitas do desenho. Foi tentado consultar modelos baixáveis no endpoint público do Sketchfab, mas o proxy retornou CONNECT 403. Nenhum modelo de terceiros, licença ou dublagem oficial foi verificado/baixado nesta atualização. Para incorporar personagens exatos, ainda faltam assets rigados com licença de uso/redistribuição, morphs faciais e animações. Uma reprodução autorizada da voz do dublador também exige autorização e um provedor compatível; Gemini continua com uma voz original PT-BR.
