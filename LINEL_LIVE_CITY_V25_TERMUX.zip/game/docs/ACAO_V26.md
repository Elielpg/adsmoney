# Versão 26.2.0 — ação, personagens e LIVE no celular

Confirme **v26.2.0** no topo da tela. A API de saúde também informa build e identidade. Páginas/scripts são revalidados; se o servidor e a tela forem de versões diferentes aparece aviso. A captura enviada mostrava textos da versão antiga. Extrair novos arquivos e apenas recarregar o Chrome não substitui módulos já carregados pelo processo Node: encerre a sessão antiga com Ctrl+C e reinicie.

## Ações do público

- “XLR8” ou “XRL8”: seleciona a forma; “dash” faz a transformação necessária e uma arrancada de cerca de 20m no trajeto seguro.
- “correr”: corrida com postura, passada e velocidade diferentes do passeio.
- “voar”: escolhe uma forma capaz (Chama por propulsão, Fantasmático ou Alien X extra) e sobe com câmera acompanhando a altitude. XLR8 não ganha voo.
- “poder”: habilidade da forma atual, com preparação, emissão, impacto e recuperação. Cooldown cobre a animação inteira.
- “missão”: objetivo local variado ou criado pelo Gemini, quando houver chave. Há 14 pedidos locais, quatro deles com viagem.
- “Gwen, quem é você?” / “Vô Max, …” / “Lia, …” / “Caio, …” / “Bia, …”: conversa com a identidade e o perfil de voz desse NPC. Mensagens dirigidas aos NPCs não acionam transformação do Ben por acidente.

Perguntas de apresentação têm resposta própria do personagem sem depender da IA. O nome do canal @linel.exe não vira o nome do herói; respostas da IA que se apresentem como Linel são substituídas pela apresentação correta. Perguntas gerais continuam usando Gemini quando disponível, com fallback explícito offline.

## Animações e cenários

Onze conjuntos de poderes têm fases e efeitos próprios. Chama usa núcleo/feixe e faíscas; Aquático, fluxo e respingos; Diamante, cristais surgindo; Cipó, segmentos vegetais; Quatro Braços, golpe e onda de choque; Fantasmático, efeito espectral; Besta, rastreamento; XLR8, rastros e avanço/retorno ao usar poder; Bola de Canhão, esfera de rolamento e impacto. O comando dash faz o deslocamento completo; o poder usa um avanço com retorno para continuar perto do objetivo.

Os NPCs receberam proporções, roupas, mãos, olhos e piscadas revisados. As malhas incluídas de terceiros continuam com suas variantes de origem e créditos. Não são réplicas oficiais; a animação é procedural. O rig facial dos nove GLBs ainda não foi produzido; modelos próprios com morph targets continuam suportados.

Bellwood, Baía do Farol e Serra dos Cristais são cenários com cores e fundos próprios, compartilhando a mesma cidade compacta e rota circular. Não são três mapas independentes de mundo aberto. Missões de viagem incluem deslocamento e depois objetivo. O servidor acompanha amostras de posição/tempo, distância e altitude no voo; esperar o tempo passar ou informar uma posição distante não conclui a viagem. Só após chegar à região a missão libera três usos de habilidade. A câmera passa para trás durante deslocamentos/ações e volta à apresentação frontal.

## Um único celular

Leia [LIVE_CELULAR.md](LIVE_CELULAR.md). Termux recebe os eventos e mantém o servidor; Chrome deve ficar visível para desenhar o jogo; TikTok fornece a transmissão/captura de tela, conforme a conta e o Android permitirem. Não precisa de computador. Evite que a economia de bateria encerre o Termux. Ativar “Manter tela ligada” tenta o Screen Wake Lock do navegador, quando suportado.

A conexão inclui região automática ou manual, confirmação separada de sala/socket/evento, causa real sanitizada, cancelamento e reconexões limitadas. Não é uma promessa de autorização pelo TikTok: o conector é comunitário. O teste nesta nuvem ao @ informado foi bloqueado pelo proxy antes de chegar ao serviço. Para testar no aparelho, com a LIVE iniciada:

```sh
cd ~/linel-v25/game
node scripts/live-probe.js @linel.exe --seconds 45
```

Esse teste não publica comentários/presentes. Mostra estados e contagens; grava apenas diagnóstico em data/, fora do ZIP. Uma sala resolvida ou um socket sem eventos não comprovam interação real com espectadores.

## Instalar a atualização

Pare o servidor antigo com Ctrl+C na sessão original. Extraia o novo ZIP sobre ~/linel-v25. O nome LINEL_LIVE_CITY_V25_TERMUX.zip foi mantido para compatibilidade com a instalação, mas seu conteúdo é v26.2.0. As chaves e configurações existentes ficam em data/ e .env e não são substituídas pelo pacote.

```sh
cd ~/linel-v25/game
bash install.sh
bash start.sh
```

Abra http://127.0.0.1:3000, recarregue e confira v26.2.0. Para próximas atualizações, depois de parar o servidor, pode usar bash update.sh. O script baixa somente o ZIP deste repositório, valida o arquivo, preserva data/.env e reinstala dependências. Se um GLB próprio estiver em data/models, ele continua substituindo o modelo incluído daquela forma.
