# Integrações externas

## TikTok

Dependência fixada: piratetok-live-js 0.3.0 (0BSD, Node >=22.19), instalada e API inspecionada no README e declarações TypeScript distribuídos. `TikTokLiveClient(username).timeout(15000).maxRetries(6)`; handlers registrados antes de `connect()`. O evento `connected` do pacote indica sala resolvida. Somente a resolução de `connect()`, que segundo o pacote exige handshake WSS, indica socket confirmado. Um evento de conteúdo muda para recebendo eventos. Reconnect do pacote fornece backoff e limite; desligar invalida handlers antigos.

Domínios usados: www.tiktok.com, webcast.tiktok.com, webcast-ws.tiktok.com (rotas regionais opcionais webcast-ws.eu.tiktok.com e webcast-ws.us.tiktok.com). Na cloud o proxy herdado é passado ao conector. Android usa conexão local normal. Restrição de protocolo, conta offline, quota e bloqueios da plataforma aparecem como erro; não há promessa de conectividade.

Alternativa: tiktok-live-connector 2.5.0, AGPL-3.0-only, NÃO incluída por padrão. Para habilitar, instale explicitamente uma versão compatível e avalie as obrigações AGPL antes de redistribuir. O adaptador fornece o contrato WebcastPushConnection. Essa alternativa NÃO FOI VALIDADA.

Teste real: abra uma LIVE pública sua, informe @ no painel e conecte PirateTok. Exija estado websocket confirmado, envie um comentário e presente, confirme IDs, contagem, evento e ranking. Interrompa a rede e verifique reconexão sem duplicações. Nenhum @ de teste foi inventado ou usado nesta entrega.

## Gemini

Endpoint REST `https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`, chave no header `x-goog-api-key`. Texto usa systemInstruction/contents; TTS usa responseModalities AUDIO e speechConfig com voz por personagem definida em public/characters.js. Defaults: gemini-2.5-flash e gemini-2.5-flash-preview-tts, alteráveis via .env. Disponibilidade atual desses modelos e quota da conta precisam ser confirmadas com API real; não houve chave fornecida. Referência oficial: https://ai.google.dev/gemini-api/docs/speech-generation .

Áudio PCM/L16 de 24 kHz é encapsulado em WAV; outros tipos são entregues com MIME da resposta. Testes verificam contrato com respostas artificiais controladas. HTTP, ausência de chave, timeout e falta de áudio produzem diagnóstico. Fallback: resposta local explícita e speechSynthesis com voz estável selecionada. Não há clone de dublador.

No Android use **Painel → IA e voz → Chaves Gemini** para adicionar, selecionar e excluir várias chaves, ou configure `.env`. O servidor usa somente a chave selecionada, sem trocar automaticamente por erro de quota. As chaves locais ficam em `data/private/gemini-keys.json` (modo 0600), excluídas de backup e distribuição. O diretório privado não tem rota HTTP. Na cloud use a variável/segredo seguro nas configurações; nunca forneça a chave em chat. O cliente HTTP respeita o proxy herdado com undici EnvHttpProxyAgent. Teste resposta e TTS no painel, verifique quota, modelo, latência e término antes de transmitir.

## ElevenLabs opcional

Em IA e voz, escolha ElevenLabs, cadastre a chave no campo privado e clique em **Carregar vozes da minha conta**. Selecione uma voz retornada pelo serviço (ou informe o ID), salve o provedor e teste a voz selecionada. A conversa continua Gemini; somente a síntese muda. Não há ID de voz oficial do Ben 10 embutido nem confirmação de que sua conta ofereça essa voz.

API REST: GET `https://api.elevenlabs.io/v1/voices` para nomes/IDs e POST `https://api.elevenlabs.io/v1/text-to-speech/{voice_id}`, modelo `eleven_multilingual_v2`, header `xi-api-key`. A chave fica em `data/private/elevenlabs-keys.json`, com as mesmas restrições e exclusões de backup/ZIP usadas para Gemini. Opcionalmente use ELEVENLABS_API_KEY no servidor. O catálogo retornado ao browser contém apenas nomes/IDs. A chave não é devolvida.

Referência oficial do endpoint: https://elevenlabs.io/docs/api-reference/text-to-speech/convert . Os contratos foram testados com respostas controladas; não houve chave/conta real para validar quota, disponibilidade ou áudio real. Há custos e limites conforme o plano da conta; o jogo não fornece assinatura ou voz licenciada. Na cloud, api.elevenlabs.io precisa estar permitido na rede; no Termux, a chamada usa a conexão do aparelho.

## Perfis e missões desta revisão

Leia BEN_CLASSICO.md para associação de vozes por alien/NPC, geração de objetivos JSON validados e diagnóstico do @ com contadores. Nenhuma credencial real ou voz da dublagem foi usada nesta revisão.
