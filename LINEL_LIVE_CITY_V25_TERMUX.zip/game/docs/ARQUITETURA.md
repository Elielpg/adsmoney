# Arquitetura

`server/index.js`: servidor HTTP de loopback, SSE, configuração JSON local, upload GLB, endpoints de fala. `server/core.js`: EventHub normalizado, deduplicação limitada em memória, ranking, regras, fila serial com ACK e prioridade moderada (a cada terceira seleção respeita idade), adaptador Gemini e WAV PCM. `server/live.js`: PirateTok principal, alternativa opcional, geração de conexão para invalidar callbacks obsoletos e estados explícitos.

`public/world.js`: Babylon Engine, cena, câmera frontal com amortecimento e raycast contra edifícios, circuito circular de waypoints livre de construções, bairros, NPCs, visitantes e modelos geométricos articulados. `public/app.js`: SSE, formulários, reprodução de áudio, fila visual, configurações e importação GLB. `public/style.css`: HUD mobile e painel em diálogo.

O servidor é a autoridade da fila. O navegador pede resposta para a fala ativa e confirma fim/erro de reprodução. Timeout de 120 segundos evita bloqueio indefinido. Fala de ambiente só começa sem fala pendente. Prioridade de presentes não interrompe a fala atual. Projetado para UM navegador operador; sincronização/eleição de um dispositivo de áudio entre várias abas ainda não implementada.

Dados pessoais e chaves não entram no ZIP. `.env` só é lido no servidor. Upload limitado a 20 MiB, GLB 2.0 com JSON válido e buffers/imagens incorporados. Origens de escrita verificadas. Não exponha o servidor na Internet. Não há autenticação remota porque o host é exclusivamente loopback.

A cidade usa geometria compartilhada conceitualmente, mas meshes separados; instancing/LOD completos e resolução adaptativa por FPS ainda pendentes. Os perfis reduzem trabalho e resolução de forma fixa. Navegação usa um circuito conhecido livre, não navmesh geral.
