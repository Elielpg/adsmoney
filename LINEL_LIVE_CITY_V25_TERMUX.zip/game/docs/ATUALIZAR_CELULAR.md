# Atualizar e executar no mesmo celular

A extração de um ZIP não reinicia o Node. Mesmo com os arquivos novos no armazenamento, um processo antigo pode continuar respondendo com a interface/identidade antiga. O navegador também pode estar aberto em outra porta ou em uma instalação diferente. A versão exibida no topo é a confirmação do que você está usando.

O pacote desta entrega chama-se **BEN10_LIVE_V27_TERMUX.zip**. A pasta de instalação pode continuar `~/linel-v25/game`, preservando chaves e configurações antigas. O nome da pasta não muda a identidade do Ben.

## Arquivos novos já extraídos

No Termux, dentro da pasta atualizada:

```sh
cd ~/linel-v25/game
bash update.sh --start
```

Esse comando baixa o ZIP da versão27 ou posterior deste repositório, valida antes de instalar, encerra apenas processos confirmados desta instalação, preserva `.env` e `data/`, instala e inicia o jogo. Abra a URL exata que aparecer no terminal e confira a versão no topo da tela. As APIs e scripts da versão27 evitam reutilizar a página antiga.

Se você já baixou o ZIP com um nome conhecido, evite baixá-lo novamente:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V27_TERMUX.zip --start
```

O arquivo em Downloads pode ter outro nome se o Android acrescentou `(1)`. Use o nome real e coloque o caminho entre aspas quando houver espaços/parênteses.

`bash update.sh` instala e deixa o comando de início no terminal. A opção `--start` também inicia o servidor após a instalação. Um arquivo diferente ou antigo, um ZIP danificado, caminhos inválidos, links simbólicos e arquivos privados embutidos são recusados.

## Quando a versão27 ainda não foi extraída

Baixe o novo pacote e extraia sobre `~/linel-v25`. Depois execute o comando com `--archive` acima. Em uma instalação antiga, `update.sh` também é antigo: primeiro é preciso extrair os arquivos desta entrega para ter o atualizador novo.

Se preferir um nome de arquivo previsível no Termux:

```sh
cd ~
curl -fL https://github.com/Elielpg/adsmoney/raw/refs/heads/main/BEN10_LIVE_V27_TERMUX.zip -o BEN10_LIVE_V27_TERMUX.zip
mkdir -p ~/linel-v25
unzip -o ~/BEN10_LIVE_V27_TERMUX.zip -d ~/linel-v25
cd ~/linel-v25/game
bash update.sh --archive ~/BEN10_LIVE_V27_TERMUX.zip --start
```

A extração manual acima utiliza o ZIP do próprio repositório; o atualizador verifica o pacote novamente antes da instalação final. Para próximos upgrades, basta `bash update.sh --start` na pasta correta.

## Como ele identifica o processo antigo

O encerramento automático exige usuário do processo igual ao atual, pasta real `/proc/PID/cwd` igual à instalação e executável Node com entrada exata `server/index.js` dessa pasta. Comandos `node -e`, testes, outros aplicativos ou instalações de outra pasta não são encerrados. O servidor novo também informa PID/pasta/porta no diagnóstico local para auxiliar a verificação. Nenhum cookie ou chave é usado para isso.

Não há `pkill node`, encerramento por nome genérico ou SIGKILL. O atualizador envia SIGTERM e aguarda até20segundos. Se o Android impedir a verificação do processo, se houver outro jogo na porta sem pasta confirmada ou se o processo não encerrar, ele interrompe antes de substituir os arquivos e orienta parar a sessão original com Ctrl+C. Depois repita o comando.

`start.sh` imprime a pasta real e a versão dos arquivos antes de iniciar. Isso permite perceber quando você abriu outra cópia do projeto. Uma porta ocupada por outro programa é mantida intacta; não é apresentada como uma atualização bem-sucedida.

## Dados e falhas de instalação

O ZIP não deve conter `.env`, `data/` ou `node_modules/`. Os arquivos locais desses diretórios são preservados durante a atualização; a instalação de dependências continua sendo feita pelo `npm ci` do projeto. Modelos GLB personalizados em `data/models` continuam prevalecendo sobre os incluídos.

A cópia dos arquivos do aplicativo mantém um backup temporário e restaura os arquivos anteriores se a cópia falhar. Se falhar o download, o pacote não é instalado. Se falhar a instalação de pacotes por falta de Internet ou outro erro, as configurações/chaves continuam preservadas: estabilize a conexão e execute `bash install.sh`, depois `bash start.sh`. Não foi implementado rollback de uma instalação parcial de dependências npm.

O atualizador foi testado em Linux com ZIPs controlados, incluindo preservação de dados, rollback de cópia, rejeição de traversal/symlinks e identificação/encerramento de um processo Node de teste. A verificação de processos no Android ainda depende das permissões de `/proc` do aparelho e deve ser confirmada no Termux.
