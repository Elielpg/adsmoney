# LINEL.EXE Live City V25 — estado da entrega

Data: 28/10/2026. **Versão funcional inicial, com visual procedural simplificado; não equivale ao produto final de alta fidelidade solicitado.** Código executável e empacotamento disponíveis. Não há legado nem personagem descartável incorporados.

## Funciona e foi verificado nesta máquina

- Node 24.19.0 / npm 11.9.0. `bash install.sh` executado com instalação pelo lockfile, sem alteração dos arquivos originais do repositório.
- Babylon.js e loaders 9.32.1 servidos localmente; cena real WebGL em Chromium headless com renderização por software. Captura real: `mobile-city.png`.
- Onze formas geométricas distintas; passeio por seis zonas coloridas, arquitetura básica, árvores, bancos, fonte, NPCs e visitantes. Câmera frontal com amortecimento e seleção de edifícios para raycast. Não há carros.
- Eventos DEMO identificados, mesmo EventHub usado pelo adaptador LIVE; deduplicação, streak final, ranking, pontos, regras de presentes e comandos como `/chama`.
- Servidor de loopback, HTTP/SSE, configuração local persistente, validação de origem de escrita, upload GLB limitado e validação básica do contêiner.
- Import GLB real com normalização de escala, meshes, skin e animation groups. Testado com fixture original contendo um triângulo, um esqueleto e idle/walk/talk. Isso valida o pipeline, não qualidade de um personagem complexo.
- Fila serial com ACK idempotente, prioridade moderada sem interromper resposta ativa, timeout e apresentação da fila.
- No Chromium, dez áudios WAV controlados foram reproduzidos e confirmados, **máximo de um áudio ativo**. O áudio era um fixture de teste; não era Gemini real.
- Síntese local de música/efeitos, controles separados, ducking e liberação de áudio por toque implementados. Resposta local e fallback de voz do navegador identificados.
- Cliente REST Gemini texto/TTS, parsing de áudio PCM e encapsulamento WAV testados com respostas controladas. PirateTok 0.3.0 instalado; contrato do adaptador e estados antes/depois do handshake testados com transporte controlado.

## Verificações

| Verificação | Resultado |
|---|---|
| `npm run lint` | Passou; verifica sintaxe, não lint semântico |
| `npm test` | 10 testes passaram, 0 falhas, 0 ignorados |
| `npm run build` | Passou; Babylon e licenças locais |
| `bash install.sh` | Passou nesta máquina Linux; não executado no Termux |
| `bash start.sh` + `bash doctor.sh` | Servidor funcional, health HTTP válido |
| `node scripts/browser-check.js` | WebGL, 11 formas, 6 zonas, GLB rigado de teste, câmera frontal e 10 áudios seriais; consulte browser.json |
| `npm audit --omit=dev` | 0 vulnerabilidades conhecidas após atualização do undici para 8.12.3 |

## NÃO VALIDADO e limitações

- TikTok real: sem @ de LIVE pública de teste. Não houve handshake real nem eventos reais. A alternativa TikTok-Live-Connector não está instalada/validada por padrão. Conectores não oficiais podem falhar por mudanças de protocolo ou restrições da plataforma.
- Gemini e Gemini TTS reais: nenhuma chave presente. Disponibilidade dos modelos, quota, voz e latência reais não verificadas. O modo local é explicitamente identificado.
- Android/Realme GT3, autoplay, voz PT-BR instalada, estabilidade térmica e alvo 30 FPS: não testados. FPS de software na cloud não mede desempenho do aparelho.
- Modelos autorais são geométricos simplificados e articulados por partes, não personagens fiéis com rigging esquelético completo. Ainda precisam de produção artística e animações expressivas próprias. A importação aceita rigs reais de GLB, mas necessita validação com personagens completos licenciados.
- As seis zonas compartilham uma cidade compacta, com variação básica de cores/altura; não são seis bairros com acabamento artístico de produção. NPCs têm rotinas básicas de caminhar/saudar, sem sistema avançado de histórias ou conversas individuais persistentes.
- Rota circular segura, não navmesh genérica nem solução de navegação livre. Colisões de câmera possuem raycast, mas falta teste exaustivo de situações arbitrárias. Crossfade GLB básico disponível; retargeting, mapeamento manual, limitação geral de root motion e prevenção universal de deformações ainda pendentes.
- Perfis gráficos com resolução e quantidade de NPCs; LOD, instancing completo e resolução dinâmica por FPS ainda pendentes.
- Um navegador operador é o fluxo suportado. Várias abas não elegem um único dispositivo de reprodução. Ranking é de sessão; regras e configuração persistem em disco. Sem autenticação para acesso remoto: servidor deliberadamente restrito a loopback.

## Ambiente na nuvem e distribuição

Rascunho salvo com `install_script`, `start_skill`, domínios Gemini/TikTok e requisito seguro `GEMINI_API_KEY`. Nenhum valor de chave foi salvo pelo agente. O rascunho não foi publicado e sua restauração em nova tarefa não foi testada. Para preservar o ambiente, revise e salve nas configurações e publique pelo produto. Gemini exige fornecer a chave no campo seguro; o modo DEMO não exige chave.

`npm run package` produz `../LINEL_LIVE_CITY_V25_TERMUX.zip` com código, scripts, documentação, testes e Babylon local. Exclui `.env`, dados de visitantes/modelos locais e node_modules. Primeira instalação no Android ainda precisa de Internet para pacotes Node e Termux. Após instalar, a cena e DEMO usam recursos locais; integrações online continuam exigindo Internet.

Siga docs/TERMUX.md e docs/INTEGRACOES.md para os testes manuais restantes. Não foi feito deploy, conexão real a espectadores, envio de mensagens externas ou publicação do ambiente.

## Atualização: personagem, cidade e múltiplas chaves

Implementados e testados o cadastro de várias chaves, seleção manual, exclusão, persistência no reinício e ausência dos valores nas respostas HTTP. Novo teste de arquivos verifica que ZIP e backup não incluem .env nem o arquivo privado. Nenhuma chave Gemini real foi recebida ou usada.

Visual principal e cidade foram ampliados conforme docs/ASSETS_E_ANIMACOES.md. Capturas reais atualizadas e painel em gemini-panel.png. O pipeline GLB, os seis bairros, onze formas e as dez reproduções sem sobreposição passaram novamente no Chromium. Sem erros JavaScript. A melhoria do personagem não é uma réplica oficial validada: a fonte oficial foi bloqueada pela rede e faltam referências visuais verificáveis, especialmente para fidelidade exata e refinamento dos aliens. Testes de GPU, qualidade e temperatura no Android continuam pendentes.

## Correção de abertura a partir de outros aplicativos

A validação de Sec-Fetch-Site bloqueava também a navegação inicial para a página raiz quando aberta a partir de outro site/aplicativo. Agora GET / com modo navigate e destino document pode carregar a página pública. As APIs, chaves, POSTs e iframes continuam sujeitos à validação de origem. Regressão HTTP cobre entrada válida e rejeição de APIs/iframe cross-site. Não foi removida a proteção das chaves.

## Atualização de aventura, poderes e boca

Quinze testes automatizados passam. Reconhecimento dos onze nomes no EventHub; automação com pausa de fala; cooldown e retorno; dez missões com proximidade/forma/progresso; pedido combinado de transformação e poder; configuração persistente e modelos por forma.

Regressão WebGL/SSE, chaves e dez áudios seriais passou novamente. Em reports/adventure-browser.json, Chromium comprovou transformação por nome, missão concluída com três usos e crescimento real das plantas, além de abertura/fechamento da boca guiada por um tom WAV controlado. O GLB de teste tem um osso, três animações e um morph mouthOpen; não é um personagem oficial. Nenhum erro JavaScript nessa execução. O TTS real, a dublagem oficial e o Android continuam não validados.

O carregamento por forma e o controle de morph targets estão implementados, mas não há assets oficiais idênticos ao desenho. A consulta de modelos prontos foi bloqueada pelo proxy. Nenhuma licença de modelo externo foi verificada e nenhum download de terceiros foi incorporado. Limitações e operação em docs/AVENTURA.md.
