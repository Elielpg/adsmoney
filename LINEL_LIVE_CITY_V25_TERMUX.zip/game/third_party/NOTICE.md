# Licensing and corresponding source

The original game source in this distribution is licensed under GNU AGPL version 3 (see ../LICENSE). The complete game source, installation/build scripts and pinned npm dependency declarations are included in the same ZIP as the application. Preserve this source availability and the license when distributing modified versions or serving the application over a network.

` tiktok-live-connector 2.5.0 ` is distributed by upstream under AGPL-3.0-only. Its complete corresponding source tree is included in `tiktok-live-connector-2.5.0/`, taken without modification from upstream tag `v2.5.0`, commit `87fb46b0a71a87b6b4fa9638313524f7c49c7dee`:
https://github.com/zerodytrash/TikTok-Live-Connector/tree/v2.5.0

Its own LICENSE, package manifests, source, tests and build configuration are preserved. Runtime installation uses the exact npm package version rather than executing a downloaded script. The built package is tested against a controlled local WebSocket and protobuf frame; this does not certify connectivity to TikTok's production service.

Other third-party components retain their respective licenses, including PirateTok (0BSD), Babylon.js/loaders (Apache-2.0), the Euler API SDK (MIT), protocol schemas and networking libraries. npm installs their included notices. Existing bundled 3D models remain under their individual CC BY 4.0 terms and authorship in docs/MODEL_CREDITS.md; the AGPL notice does not relicense those assets or grant rights to TV recordings/voices.

The signed connection path uses the public Euler Stream community signing service (api.eulerstream.com), subject to that service's availability and rate limits. No premium account, signing key, authenticated TikTok session or payment is bundled or fabricated. No TikTok session cookies are sent by this game to the signing service.
