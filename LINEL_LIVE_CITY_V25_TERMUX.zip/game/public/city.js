export function cityObjects(){
 const objects=[];const add=(p,s,c,kind='box',rotation)=>objects.push({p,s,c,kind,rotation});const stone=[.63,.64,.58],trim=[.89,.85,.72],wood=[.35,.20,.11],metal=[.12,.21,.22],glass=[.21,.45,.48];
 add([0,-.26,0],[140,.45,140],[.19,.34,.22]);add([0,-.02,0],[59,.12,59],[.62,.59,.51],'cylinder');add([0,.055,0],[53,.08,53],[.51,.49,.43],'cylinder');add([0,.10,0],[31,.14,31],[.25,.42,.23],'cylinder');add([0,.19,0],[16,.1,16],stone,'cylinder');
 for(const radius of [17,19,21,23])for(let k=0;k<120;k++){const a=k/120*Math.PI*2;add([Math.sin(a)*radius,.105,Math.cos(a)*radius],[.75,.025,.035],[.67,.64,.56],'box',[0,a,0]);}
 // Radial pedestrian streets and a central stone fountain.
 for(let d=0;d<6;d++){const a=d*Math.PI/3;add([Math.sin(a)*22,.08,Math.cos(a)*22],[3,.04,22],[.73,.70,.62],'box',[0,a,0]);}
 for(const [y,diameter,h,c] of [[.30,5.6,.3,stone],[.5,5,.12,[.12,.51,.63]],[.65,1.2,1,stone],[1.2,2.6,.17,trim],[1.32,2.2,.08,[.13,.61,.72]],[1.65,.35,.65,stone],[2,.7,.2,trim]])add([0,y,0],[diameter,h,diameter],c,'cylinder');
 const palette=[[.72,.49,.32],[.49,.65,.58],[.83,.64,.37],[.56,.58,.71],[.60,.66,.39],[.74,.48,.43]];
 for(let d=0;d<6;d++){const angle=d*Math.PI/3;for(let b=-1;b<=1;b++){const cx=Math.sin(angle)*35+Math.cos(angle)*b*6.7,cz=Math.cos(angle)*35-Math.sin(angle)*b*6.7,h=5+(d+b+6)%3*1.3;const local=(x,y,z,s,c,kind='box',rot=0)=>add([cx+x*Math.cos(angle)+z*Math.sin(angle),y,cz-x*Math.sin(angle)+z*Math.cos(angle)],s,c,kind,[0,angle,rot]);
 local(0,h/2,0,[5.8,h,5],palette[d]);local(0,.28,0,[5.9,.45,5.1],stone);local(0,h+.12,0,[6.1,.3,5.3],trim);local(0,h+.38,0,[5.7,.22,4.9],metal);
 for(const x of [-2.7,2.7])local(x,h/2,-2.55,[.18,h,.16],trim);local(0,2.65,-2.61,[5.8,.14,.2],trim);
 local(-1.45,1.36,-2.55,[2.2,1.95,.08],glass);local(1.15,1.25,-2.55,[1.5,2.35,.09],metal);local(1.15,1.53,-2.62,[1.2,1.55,.04],glass);local(1.62,1.15,-2.68,[.04,.25,.05],trim);
 for(let x=-2.25;x<0;x+=.7)local(x,1.36,-2.64,[.06,2,.06],trim);local(-1.45,1.7,-2.64,[2.2,.065,.06],trim);
 // Distinct striped canvas awnings over stores.
 for(let k=0;k<8;k++)local(-2.45+k*.7,2.48,-3.05,[.7,.12,1.1],k%2?trim:[palette[d][0]*.65,palette[d][1]*.65,palette[d][2]*.65],'box',-.12);
 for(let row=0;row<Math.floor((h-2.8)/1.6);row++)for(const x of [-1.6,0,1.6]){const y=3.6+row*1.6;local(x,y,-2.56,[1.16,1.12,.08],trim);local(x,y,-2.62,[.93,.91,.05],glass);local(x,y,-2.67,[.045,.94,.04],trim);local(x,y-.14,-2.67,[.94,.045,.04],trim);local(x,y-.61,-2.75,[1.3,.1,.4],stone);if(d%2===0){local(x,y-.5,-2.86,[1,.16,.22],wood);for(const dx of [-.3,0,.3])local(x+dx,y-.36,-2.86,[.22,.25,.22],[.21,.4,.15],'sphere');}}
 if(d===3)for(const x of [-2.2,2.2])local(x,1.2,-3.2,[.28,2.4,.28],trim,'cylinder');
 }}
 for(let i=0;i<30;i++){const a=i/30*Math.PI*2,r=i%2?29:12.3,x=Math.sin(a)*r,z=Math.cos(a)*r;add([x,1.25,z],[.24,2.5,.24],wood,'cylinder');for(let j=0;j<3;j++)add([x+(j-1)*.6,2.8+(j%2)*.6,z],[1.75,2.05,1.7],[.16,.35+(i%3)*.025,.16],'sphere');
 if(i%3===0){const bx=Math.sin(a)*25,zx=Math.cos(a)*25;add([bx,.5,zx],[1.8,.16,.58],wood,'box',[0,a,0]);add([bx,.86,zx+.22],[1.8,.6,.1],wood,'box',[0,a,0]);for(const side of [-1,1])add([bx+side*.64,.23,zx],[.09,.5,.5],metal,'box');}
 if(i%2===0){const lx=Math.sin(a)*26,lz=Math.cos(a)*26;add([lx,1.65,lz],[.1,3.3,.1],metal,'cylinder');add([lx,3.4,lz],[.5,.65,.5],[.94,.85,.52]);add([lx,3.8,lz],[.65,.12,.65],metal);add([lx,.15,lz],[.36,.3,.36],stone,'cylinder');}
 }
 // Planters with flowers, café tables, bollards, pergola and park details.
 for(let i=0;i<24;i++){const a=i/24*Math.PI*2,x=Math.sin(a)*13.8,z=Math.cos(a)*13.8;add([x,.27,z],[.8,.4,.8],[.47,.28,.18],'cylinder');add([x,.53,z],[.7,.4,.7],[.18,.36,.16],'sphere');for(let k=0;k<3;k++)add([x+(k-1)*.18,.76,z],[.19,.17,.19],i%2?[.87,.63,.21]:[.75,.34,.45],'sphere');}
 for(let i=0;i<6;i++){const a=i*Math.PI/3+.3,x=Math.sin(a)*29,z=Math.cos(a)*29;add([x,.85,z],[1.5,.12,1.5],wood,'cylinder');add([x,.42,z],[.12,.84,.12],metal,'cylinder');for(const side of [-1,1]){add([x+side*1.1,.45,z],[.6,.12,.6],wood);add([x+side*1.1,.85,z+.26],[.6,.7,.09],wood);}}
 for(const x of [-4,4])for(const z of [-4,4])add([x,1.55,z],[.17,3.1,.17],wood);for(let x=-4.5;x<=4.5;x+=.9)add([x,3.15,0],[.16,.2,9.2],wood);for(let k=0;k<7;k++)add([-4.2+k*1.4,3.3,3],[1.9,.3,2.2],[.2,.36,.15],'sphere');
 return objects;
}
export function decorateCity(scene){
 const B=BABYLON;const names=['CAFÉ AURORA','JARDIM BOTÂNICO','MERCADO SOLAR','GALERIA CRISTAL','BIBLIOTECA DO PARQUE','CENTRO CULTURAL'];
 for(let d=0;d<6;d++){const a=d*Math.PI/3;const canvas=new B.DynamicTexture('shop-sign-'+d,{width:512,height:128},scene,false);canvas.drawText(names[d],null,80,'bold 36px sans-serif','#f5ead0','#203c38',true);const material=new B.StandardMaterial('sign-'+d,scene);material.diffuseTexture=canvas;material.emissiveColor=new B.Color3(.22,.22,.18);const sign=B.MeshBuilder.CreatePlane('sign-'+d,{width:4.8,height:1.2,sideOrientation:B.Mesh.DOUBLESIDE},scene);sign.position.set(Math.sin(a)*32.42,3.25,Math.cos(a)*32.42);sign.rotation.y=a;sign.material=material;sign.isPickable=false;}
 // A locally generated paving texture; no downloaded or AI concept image.
 const paving=new B.DynamicTexture('paving',{width:256,height:256},scene,false),ctx=paving.getContext();ctx.fillStyle='#a59f8e';ctx.fillRect(0,0,256,256);for(let y=0;y<8;y++)for(let x=0;x<8;x++){ctx.fillStyle=['#b5ad9b','#aca48f','#bab29f'][(x+y)%3];ctx.fillRect(x*32+(y%2)*16,y*32,30,30);}paving.update();paving.uScale=18;paving.vScale=18;
 const pavement=scene.getMeshByName('city-2');if(pavement){pavement.material=pavement.material.clone('pavement-unique');pavement.material.diffuseColor=new B.Color3(.95,.95,.95);pavement.material.diffuseTexture=paving;}
}
