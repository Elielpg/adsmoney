// Large readable action geometry. Particles are accents, not the action itself.
import {ease,clamp01} from './power-timeline.js';
export function buildAbilitySculpture(world,e){
 const B=BABYLON,root=new B.TransformNode('hero-ability-'+e.form,world.scene);root.parent=e.root;const meshes=[],materials=[];
 const mat=(name,color,emissive=.5,alpha=1)=>{const m=new B.StandardMaterial(name,world.scene);m.diffuseColor=new B.Color3(...color);m.emissiveColor=new B.Color3(...color).scale(emissive);m.specularColor=new B.Color3(.7,.7,.7);m.alpha=alpha;materials.push(m);return m;};
 const primary=mat('ability-primary',e.form==='rock'?[.12,.83,.98]:e.form==='fourarms'?[1,.61,.13]:[1,.20,.015],1,e.form==='rock'?.9:1),hot=mat('ability-hot',[1,.91,.22],1.1),debris=mat('ability-debris',[.25,.20,.15],.1),pale=mat('ability-bright',[.73,1,1],.8,.92);
 const add=(kind,name,material=primary)=>{const mesh=kind==='torus'?B.MeshBuilder.CreateTorus(name,{diameter:1,thickness:.09,tessellation:40},world.scene):world.mesh({p:[0,0,0],s:[1,1,1],c:[1,1,1],kind},name);mesh.parent=root;mesh.material=material;mesh.isPickable=false;mesh.scaling.setAll(.001);meshes.push(mesh);return mesh;};
 const object={root,meshes,materials};
 if(e.form==='blaze'){object.shell=add('sphere','fireball-shell');object.flameCore=add('sphere','fireball-heart',hot);object.explosion=add('sphere','fire-impact-flash',hot);object.flames=Array.from({length:10},(_,i)=>add('crystal','fire-tongue-'+i,i%3?primary:hot));object.blastRings=Array.from({length:3},(_,i)=>add('torus','blast-ring-'+i,i%2?primary:hot));if(world.previewActive){const steel=mat('practice-target',[.23,.29,.32],.12);object.target=add('box','practice-target',steel);object.targetBadge=add('sphere','target-core',hot);object.targetBits=Array.from({length:8},(_,i)=>add('box','target-fragment-'+i,steel));}}
 else if(e.form==='rock'){object.wall=Array.from({length:7},(_,i)=>add('crystal','crystal-wall-'+i,i%2?primary:pale));object.shards=Array.from({length:16},(_,i)=>add('crystal','crystal-fragment-'+i,i%3?primary:pale));}
 else if(e.form==='fourarms'){object.waves=Array.from({length:4},(_,i)=>add('torus','ground-slam-wave-'+i,i%2?primary:hot));object.rubble=Array.from({length:14},(_,i)=>add('crystal','slam-rubble-'+i,debris));object.cracks=Array.from({length:10},(_,i)=>add('box','impact-fissure-'+i,primary));}
 else if(e.form==='tide'){object.jet=add('cylinder','water-cannon',pale);object.splash=Array.from({length:10},(_,i)=>add('sphere','water-splash-'+i,pale));}
 else if(e.form==='wildvine'){object.vines=Array.from({length:6},(_,i)=>add('cylinder','living-tendril-'+i,mat('vine-'+i,[.20,.70,.07],.2)));}
 else if(e.form==='shade'||e.form==='nova'){object.aura=add('sphere','spectral-aura',mat('spectral',[.48,.32,1],.9,.30));object.orbits=Array.from({length:3},(_,i)=>add('torus','spectral-orbit-'+i,pale));}
 return object;
}
export function updateAbilitySculpture(world,e,f){
 const B=BABYLON,s=e.sculpture;if(!s)return;const source=e.start,target=e.end,release=f.release,hit=f.contact,fade=f.fade,form=e.form,front=target.subtract(source).normalize(),right=new B.Vector3(front.z,0,-front.x);const unit=(m,scale)=>m.scaling.setAll(Math.max(.001,scale));
 if(form==='blaze'){
  const travel=ease(release),p=B.Vector3.Lerp(source,target,travel),size=(f.phase==='anticipation'?.12+f.charge*.55:hit>0?.001:1.15+Math.sin(e.time*12)*.06)*fade;
  s.shell.position.copyFrom(p);unit(s.shell,size);s.flameCore.position.copyFrom(p);unit(s.flameCore,size*.66);
  s.flames.forEach((mesh,i)=>{const a=i/10*Math.PI*2;mesh.position.copyFrom(p).addInPlace(new B.Vector3(Math.cos(a)*size*.4,Math.sin(a)*size*.4,0)).subtractInPlace(front.scale(.2+i%3*.16));mesh.scaling.set(size*.25,size*(.7+i%3*.18),size*.25);mesh.rotation.set(Math.cos(a)*.6,e.time*2,Math.sin(a)*.5);});
  s.explosion.position.copyFrom(target);unit(s.explosion,hit>0?Math.sin(Math.min(1,hit*1.7)*Math.PI)*3.0*fade:.001);
  s.blastRings.forEach((ring,i)=>{ring.position.copyFrom(target);ring.rotation.set(Math.PI/2,i*.6,e.time*.3);unit(ring,hit>0?Math.min(3.7,.7+hit*(2.5+i*.25))*fade:.001);});if(s.target){s.target.position.copyFrom(target);s.target.scaling.set(hit>0?.001:1.0,hit>0?.001:1.2,hit>0?.001:.8);s.targetBadge.position.copyFrom(target).subtractInPlace(front.scale(.43));unit(s.targetBadge,hit>0?.001:.27);s.targetBits.forEach((mesh,i)=>{const a=i/8*Math.PI*2;mesh.position.copyFrom(target).addInPlace(new B.Vector3(Math.cos(a)*hit*2,Math.sin(hit*Math.PI)*(1+i%3*.3),Math.sin(a)*hit*2));mesh.scaling.setAll(.24*hit*fade);mesh.rotation.set(e.time*3,a,e.time*2);});}
 }
 else if(form==='rock'){
  s.wall.forEach((mesh,i)=>{const offset=(i-3)*.48,height=1.7+(1-Math.abs(i-3)/4)*1.2,grow=ease(clamp01(release*1.8-i*.075)),shatter=clamp01((hit-.65)/.35);mesh.position.copyFrom(target).addInPlace(right.scale(offset)).addInPlace(new B.Vector3(0,-target.y+height*grow*.5,0));mesh.position.addInPlace(front.scale(Math.abs(i-3)*.08));mesh.scaling.set(.52*(1-shatter)*fade,Math.max(.001,height*grow*(1-shatter)*fade),.56*(1-shatter)*fade);mesh.rotation.set(shatter*.6*(i%2?1:-1),i*.2,offset*.12);});
  s.shards.forEach((mesh,i)=>{const a=i/16*Math.PI*2,burst=clamp01((hit-.55)/.45);mesh.position.copyFrom(target).addInPlace(new B.Vector3(Math.cos(a)*burst*2.1,Math.sin(burst*Math.PI)*(1+i%3*.25),Math.sin(a)*burst*2.1));mesh.scaling.set(.16*burst*fade,(.4+i%3*.15)*burst*fade,.16*burst*fade);mesh.rotation.set(e.time+i,a,e.time*.6);});
 }
 else if(form==='fourarms'){
  const slam=release>.35?clamp01((release-.35)/.65):0,burst=Math.max(slam,hit),origin=source.add(front.scale(.6));origin.y=.045;
  s.waves.forEach((mesh,i)=>{mesh.position.copyFrom(origin);mesh.position.y+=i*.012;unit(mesh,Math.max(0,burst-i*.07)*(4.4+i*.5)*fade);});
  s.rubble.forEach((mesh,i)=>{const a=i/14*Math.PI*2;mesh.position.copyFrom(origin).addInPlace(new B.Vector3(Math.cos(a)*burst*(1.5+i%3*.5),Math.sin(burst*Math.PI)*(.6+i%4*.25),Math.sin(a)*burst*(1.5+i%3*.5)));unit(mesh,(.12+i%3*.07)*burst*fade);mesh.rotation.set(e.time*3,i,e.time*4);});
  s.cracks.forEach((mesh,i)=>{const a=i/10*Math.PI*2;mesh.position.copyFrom(origin).addInPlace(new B.Vector3(Math.cos(a)*burst*1.1,.018,Math.sin(a)*burst*1.1));mesh.scaling.set(.035*fade,.018,Math.max(.001,burst*2.1*fade));mesh.rotation.y=Math.PI/2-a;});
 }
 else if(form==='tide'){
  const delta=target.subtract(source),length=delta.length(),p=B.Vector3.Lerp(source,target,release*.5);s.jet.position.copyFrom(p);s.jet.scaling.set(.46*fade,Math.max(.001,length*release),.46*fade);s.jet.rotationQuaternion=B.Quaternion.FromUnitVectorsToRef(B.Axis.Y,front,new B.Quaternion());s.splash.forEach((mesh,i)=>{const a=i/10*Math.PI*2;mesh.position.copyFrom(target).addInPlace(new B.Vector3(Math.cos(a)*hit*1.5,Math.sin(hit*Math.PI)*(.6+i%3*.3),Math.sin(a)*hit*1.5));mesh.scaling.set(.24*hit*fade,.5*hit*fade,.24*hit*fade);});
 }
 else if(form==='wildvine'){s.vines.forEach((mesh,i)=>{const a=i/6*Math.PI*2;mesh.position.copyFrom(target).addInPlace(new B.Vector3(Math.cos(a)*.6,-target.y+release*.95,Math.sin(a)*.6));mesh.scaling.set(.16*fade,Math.max(.001,release*2.3*fade),.16*fade);mesh.rotation.z=Math.cos(a)*.25;});}
 else if(s.aura){s.aura.position.copyFrom(source).addInPlace(new B.Vector3(0,.1,0));s.aura.scaling.set(1.8*release*fade,2.8*release*fade,1.8*release*fade);s.orbits.forEach((mesh,i)=>{mesh.position.copyFrom(source);mesh.rotation.set(i*Math.PI/3,e.time,i*.6);unit(mesh,(1.5+release)*fade);});}
}
