export function interactionTips(config={}){const tips=[
 'Escreva o nome de um alien: Chama, XLR8, Diamante, Quatro Braços…',
 'Comente “poder” para usar a habilidade da forma atual.',
 'Comente “missão” para Gwen, Vô Max ou um morador pedir ajuda.',
 'Pergunte sobre Ben 10 clássico ou puxe qualquer outro assunto!',
 'Curtidas, compartilhamentos e follows somam pontos no ranking.'
 ];for(const rule of config.giftRules||[])tips.push(`Presente ${rule.name} → ${config.names?.[rule.action]||rule.action} · ${rule.points} pontos por unidade`);for(const rule of config.commandRules||[])tips.push(`Comente ${rule.command} → ${config.names?.[rule.action]||rule.action}`);return tips;}
