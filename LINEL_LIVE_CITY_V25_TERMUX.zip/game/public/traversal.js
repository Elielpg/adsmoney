// Shared, bounded movement contracts. All paths stay on the pedestrian ring.
export const ROUTE_RADIUS=19;
export const CITIES=[
 {id:'bellwood',name:'Bellwood',palette:{sky:[.65,.80,.85],fog:[.65,.80,.85],accent:[.31,.52,.38],ground:[.62,.63,.51]}},
 {id:'coast',name:'Baía do Farol',palette:{sky:[.48,.78,.94],fog:[.52,.80,.89],accent:[.27,.62,.72],ground:[.73,.69,.51]}},
 {id:'canyon',name:'Serra dos Cristais',palette:{sky:[.79,.69,.54],fog:[.75,.62,.49],accent:[.65,.39,.26],ground:[.65,.48,.34]}}
];
export const CITIES_BY_ID=Object.fromEntries(CITIES.map(city=>[city.id,city]));
export const MOVEMENT_PRESETS={run:{speed:5.6,duration:2600,distance:14.56,cooldown:4000},dash:{speed:24,duration:850,distance:20.4,cooldown:4500},fly:{speed:8,duration:3200,distance:25.6,cooldown:6500}};
export const canMove=(form,mode)=>mode==='run'||mode==='dash'&&form==='volt'||mode==='fly'&&['blaze','shade','nova'].includes(form);
export const routePosition=(angle,height=0)=>[Math.sin(angle)*ROUTE_RADIUS,height,Math.cos(angle)*ROUTE_RADIUS];
export function forwardArc(from,to){return ((to-from)%(Math.PI*2)+Math.PI*2)%(Math.PI*2);}
export function signedArc(from,to){return Math.atan2(Math.sin(to-from),Math.cos(to-from));}
