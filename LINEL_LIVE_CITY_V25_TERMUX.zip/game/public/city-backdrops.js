import {CITIES_BY_ID} from './traversal.js';
export class CityBackdrops{
 constructor(world){this.world=world;this.roots={};const B=BABYLON;for(const id of ['coast','canyon']){const root=new B.TransformNode('landscape-'+id,world.scene);this.roots[id]=root;for(let i=0;i<18;i++){const angle=i/18*Math.PI*2,radius=id==='coast'?48:46;const mesh=world.mesh({p:[Math.sin(angle)*radius,id==='coast'?.04:2+Math.sin(i)*.4,Math.cos(angle)*radius],s:id==='coast'?[11,.08,11]:[3.5,5+i%4,3.5],c:id==='coast'?[.1,.48,.67]:[.56+i%3*.04,.39,.26],kind:id==='coast'?'box':'crystal'},'landscape-'+id+'-'+i);mesh.parent=root;mesh.isPickable=false;}root.setEnabled(false);}this.id=null;}
 set(id){if(this.id===id)return;this.id=id;const city=CITIES_BY_ID[id]||CITIES_BY_ID.bellwood;for(const [key,root] of Object.entries(this.roots))root.setEnabled(key===id);this.world.scene.fogColor=new BABYLON.Color3(...city.palette.fog);this.world.flash=Math.max(this.world.flash,.35);}
}
