import {createPowerEffect,updatePowerEffect,disposePowerEffect} from './power-effects.js';
import {POWERS} from './transformations.js';
export class QuestVisuals{
 constructor(world){this.world=world;this.state=null;this.id=null;this.root=null;this.effect=null;this.objects=[];this.lastPower=null;}
 sync(state){this.state=state;const q=state.quest;if(q&&q.id!==this.id){this.id=q.id;this.root?.dispose();this.helper?.label?.remove();this.helper?.root.dispose();this.root=new BABYLON.TransformNode('mission-'+q.id,this.world.scene);const [x,,z]=q.position,r=Math.hypot(x,z);this.root.position.set(x+x/r*2,0,z+z/r*2);this.helper=this.world.makeActor(-1,q.npc);this.helper.root.position.copyFrom(this.root.position).addInPlace(new BABYLON.Vector3(1.8,0,0));this.helper.root.scaling.setAll(q.speaker==='max'?1:.85);const label=document.createElement('span');label.className='visitor-label npc-label';label.textContent=q.npc;this.world.labels.append(label);this.helper.label=label;this.objects=[];const add=(p,s,c,kind='box')=>{const mesh=this.world.mesh({p,s,c,kind},'objective-'+q.object);mesh.parent=this.root;mesh.isPickable=false;this.objects.push({mesh,position:mesh.position.clone(),scale:mesh.scaling.clone()});};
  const colors={garden:[.35,.4,.12],crates:[.5,.3,.15],crystal:[.2,.85,.75],ice:[.6,.85,1],fire:[1,.35,.03],signal:[.45,.6,.8],books:[.65,.25,.2],trail:[.85,.6,.2],stones:[.45,.45,.4],stars:[.85,.8,1]};const color=colors[q.object];
  for(let i=0;i<5;i++){const x=(i%3-1)*.6,z=Math.floor(i/3)*.5;add([x,.35+(i%2)*.35,z],[.45,.65,.45],color,['ice','crystal','stars'].includes(q.object)?'crystal':['fire','garden','trail'].includes(q.object)?'sphere':'box');}
  add([0,.05,0],[2.5,.08,2],[.18,.3,.22]);
 }
 if(q&&this.root){const amount=q.progress/q.total;for(const [i,o] of this.objects.entries()){if(i===5)continue;const kind=q.object;if(['ice','fire','stones'].includes(kind))o.mesh.scaling.copyFrom(o.scale.scale(Math.max(.01,1-amount)));else if(kind==='garden'||kind==='crystal'){o.mesh.scaling.y=o.scale.y*(.4+amount*1.3);o.mesh.material=this.world.material(kind==='garden'?[.18,.65,.15]:[.2,.85,.75]);}else if(kind==='crates'){o.mesh.position.x=o.position.x+amount*3;}else if(kind==='books'){o.mesh.position.set(amount>0?0:o.position.x,.2+i*.15,o.position.z*(1-amount));}else if(kind==='stars'){o.mesh.material=this.world.material([.4+amount*.5,.4+amount*.5,.2+amount*.7]);}else o.mesh.scaling.copyFrom(o.scale.scale(1-amount*.8));}}
 if(state.power&&state.power.id!==this.lastPower){this.lastPower=state.power.id;if(Date.now()-state.power.at<3000)this.spawnPower(state.power,q);}}
 spawnPower(power,quest){this.disposeEffect();this.effect=createPowerEffect(this.world,power,quest&&this.root?this.root.position:null);}
 disposeEffect(){disposePowerEffect(this.effect);this.effect=null;}
 update(dt){
  if(this.helper){const t=performance.now()/1000;this.world.animateActor(this.helper,dt,t,true);const delta=this.world.avatar.root.position.subtract(this.helper.root.position);this.helper.root.rotation.y=Math.atan2(delta.x,delta.z)+Math.PI;this.world.projectLabel(this.helper,true);}
  if(this.effect&&updatePowerEffect(this.world,this.effect,dt))this.disposeEffect();
 }
}
