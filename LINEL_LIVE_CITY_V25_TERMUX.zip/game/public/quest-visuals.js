import {POWERS} from './transformations.js';
export class QuestVisuals{
 constructor(world){this.world=world;this.state=null;this.id=null;this.root=null;this.effect=null;this.objects=[];this.lastPower=null;}
 sync(state){this.state=state;const q=state.quest;if(q&&q.id!==this.id){this.id=q.id;this.root?.dispose();this.helper?.label?.remove();this.helper?.root.dispose();this.root=new BABYLON.TransformNode('mission-'+q.id,this.world.scene);const [x,,z]=q.position,r=Math.hypot(x,z);this.root.position.set(x+x/r*2,0,z+z/r*2);this.helper=this.world.makeActor(-1,q.npc);this.helper.root.position.copyFrom(this.root.position).addInPlace(new BABYLON.Vector3(1.8,0,0));this.helper.root.scaling.setAll(q.speaker==='max'?1:.85);const label=document.createElement('span');label.className='visitor-label npc-label';label.textContent=q.npc;this.world.labels.append(label);this.helper.label=label;this.objects=[];const add=(p,s,c,kind='box')=>{const mesh=this.world.mesh({p,s,c,kind},'objective-'+q.object);mesh.parent=this.root;mesh.isPickable=false;this.objects.push({mesh,position:mesh.position.clone(),scale:mesh.scaling.clone()});};
  const colors={garden:[.35,.4,.12],crates:[.5,.3,.15],crystal:[.2,.85,.75],ice:[.6,.85,1],fire:[1,.35,.03],signal:[.45,.6,.8],books:[.65,.25,.2],trail:[.85,.6,.2],stones:[.45,.45,.4],stars:[.85,.8,1]};const color=colors[q.object];
  for(let i=0;i<5;i++){const x=(i%3-1)*.6,z=Math.floor(i/3)*.5;add([x,.35+(i%2)*.35,z],[.45,.65,.45],color,['ice','crystal','stars'].includes(q.object)?'crystal':['fire','garden','trail'].includes(q.object)?'sphere':'box');}
  add([0,.05,0],[2.5,.08,2],[.18,.3,.22]);
 }
 if(q&&this.root){const amount=q.progress/q.total;for(const [i,o] of this.objects.entries()){if(i===5)continue;const kind=q.object;if(['ice','fire','stones'].includes(kind))o.mesh.scaling.copyFrom(o.scale.scale(Math.max(.01,1-amount)));else if(kind==='garden'||kind==='crystal'){o.mesh.scaling.y=o.scale.y*(.4+amount*1.3);o.mesh.material=this.world.material(kind==='garden'?[.18,.65,.15]:[.2,.85,.75]);}else if(kind==='crates'){o.mesh.position.x=o.position.x+amount*3;}else if(kind==='books'){o.mesh.position.set(amount>0?0:o.position.x,.2+i*.15,o.position.z*(1-amount));}else if(kind==='stars'){o.mesh.material=this.world.material([.4+amount*.5,.4+amount*.5,.2+amount*.7]);}else o.mesh.scaling.copyFrom(o.scale.scale(1-amount*.8));}}
 if(state.power&&state.power.id!==this.lastPower){this.lastPower=state.power.id;if(Date.now()-state.power.at<3000)this.spawnPower(state.power,q);}}
 spawnPower(power,quest){
  this.world.powerUntil=Date.now()+1800;this.disposeEffect();const B=BABYLON,root=new B.TransformNode('power-'+power.id,this.world.scene),start=new B.Vector3(...power.position);start.y=1.25;
  const hero=this.world.avatar.root,forward=new B.Vector3(-Math.sin(hero.rotation.y),0,-Math.cos(hero.rotation.y));const end=quest&&quest.status&&this.root?this.root.position.add(new B.Vector3(0,.6,0)):start.add(forward.scale(4));
  const color=POWERS[power.form].color,material=this.world.material(color).clone('power-glow');material.emissiveColor=new B.Color3(...color).scale(.8);material.specularColor=new B.Color3(.5,.5,.5);material.alpha=power.form==='shade'?.5:.92;
  const parts=[],add=(kind='sphere',index=0)=>{const m=this.world.mesh({p:[0,0,0],s:[.2,.2,.2],c:color,kind},'power-'+power.form+'-'+index);m.parent=root;m.material=material;m.isPickable=false;parts.push(m);return m;};
  for(let i=0;i<(this.world.quality==='economy'?12:24);i++)add(['rock','blaze'].includes(power.form)?'crystal':power.form==='wildvine'?'cylinder':'sphere',i);
  const rings=[];for(let i=0;i<3;i++){const m=B.MeshBuilder.CreateTorus('power-ring',{diameter:1,thickness:.055,tessellation:32},this.world.scene);m.parent=root;m.material=material;m.isPickable=false;rings.push(m);}
  let beam=null;if(['blaze','tide','wildvine','base'].includes(power.form)){beam=B.MeshBuilder.CreateCylinder('power-stream',{height:1,diameter:1,tessellation:12},this.world.scene);beam.parent=root;beam.material=material;beam.isPickable=false;}
  this.effect={root,start,end,parts,rings,beam,material,time:0,form:power.form};
 }
 disposeEffect(){if(!this.effect)return;this.effect.root.dispose();this.effect.material.dispose();this.effect=null;}
 update(dt){
  if(this.helper){const t=performance.now()/1000;this.world.animateActor(this.helper,dt,t,true);const delta=this.world.avatar.root.position.subtract(this.helper.root.position);this.helper.root.rotation.y=Math.atan2(delta.x,delta.z)+Math.PI;this.world.projectLabel(this.helper,true);}
  const e=this.effect;if(!e)return;e.time+=dt;const B=BABYLON,t=Math.min(1,e.time/1.8),travel=Math.min(1,t*2),center=B.Vector3.Lerp(e.start,e.end,travel),impact=Math.max(0,(t-.4)/.6),delta=e.end.subtract(e.start);
  for(const [i,m] of e.parts.entries()){const k=i/e.parts.length,a=k*Math.PI*2+t*9,spread=.2+impact*1.2; m.position.copyFrom(center).addInPlace(new B.Vector3(Math.cos(a)*spread,Math.sin(a)*spread*.6,Math.sin(a*2)*spread));m.scaling.setAll(.12*(1-t));
   if(e.form==='blaze'){m.position=B.Vector3.Lerp(e.start,e.end,Math.max(0,travel-k*.5));m.position.addInPlace(new B.Vector3(Math.sin(a)*.25,Math.sin(a*3)*.18+t*.3,Math.cos(a)*.25));m.scaling.set(.15,.4*(1-t)+.05,.15);m.rotation.z=Math.sin(a)*.6;}
   else if(e.form==='tide'){const f=Math.max(0,Math.min(1,travel-k*.4));m.position=B.Vector3.Lerp(e.start,e.end,f);m.position.y+=Math.sin(f*Math.PI)*.55+Math.sin(a)*.12-impact*.4;m.scaling.set(.10,.18,.10);}
   else if(e.form==='rock'){m.position.copyFrom(e.end).addInPlace(new B.Vector3(Math.cos(a)*(.5+k),-.5+impact*.7,Math.sin(a)*(.5+k)));m.scaling.set(.16,Math.max(.01,impact*(.8+k)),.16);m.rotation.z=Math.cos(a)*.25;}
   else if(e.form==='wildvine'){const f=k,dir=delta.clone().normalize();m.position=B.Vector3.Lerp(e.start,e.end,f);m.position.y+=Math.sin(f*Math.PI)*.5;m.position.addInPlace(new B.Vector3(Math.cos(a)*.12,Math.sin(a)*.12,0));m.scaling.set(.09,.25+travel*.1,.09);m.rotationQuaternion=B.Quaternion.FromUnitVectorsToRef(B.Axis.Y,dir,new B.Quaternion());}
   else if(e.form==='volt'){m.position=B.Vector3.Lerp(e.start,e.end,(k+t*2)%1);m.position.y=.15+Math.sin(a)*.07;m.scaling.set(.10,.12,.6);m.rotation.y=Math.atan2(delta.x,delta.z);}
   else if(e.form==='fourarms'){m.position.copyFrom(e.end).addInPlace(new B.Vector3(Math.cos(a)*impact*2,Math.sin(impact*Math.PI)*(.5+k)+.1,Math.sin(a)*impact*2));m.scaling.setAll(.1+k*.15);m.rotation.set(a,a/2,a);}
   else if(e.form==='cannon'){m.position.copyFrom(center);m.position.y=.5;m.scaling.setAll(i===0?.9:.025);m.rotation.x=t*24;}
   else if(e.form==='shade'){m.position.copyFrom(center).addInPlace(new B.Vector3(Math.cos(a)*.65,.2+k*1.5,Math.sin(a)*.65));m.scaling.set(.12,.4,.12);}
   else if(e.form==='beast'){m.position=B.Vector3.Lerp(e.start,e.end,k);m.position.y=.15+Math.sin(a)*.05;m.scaling.setAll(.05+Math.max(0,Math.sin(a))*.06);}
   else if(e.form==='nova'){m.position.copyFrom(e.end).addInPlace(new B.Vector3(Math.cos(a)*2,Math.sin(a*2)*1.5+1,Math.sin(a)*2));m.scaling.setAll(.06+Math.sin(a)**2*.1);}
  }
  for(const [i,m] of e.rings.entries()){const ground=['fourarms','cannon','beast','volt'].includes(e.form);m.position.copyFrom(ground?e.end:center);m.position.y=ground?.08+i*.03:m.position.y+i*.3;m.scaling.setAll(Math.max(.01,(t+i*.12)*3));m.rotation.x=ground?0:Math.PI/2;m.rotation.z=e.form==='nova'?t*2:0;}
  if(e.beam){const length=delta.length(),direction=delta.clone().normalize();e.beam.position.copyFrom(e.start.add(delta.scale(.5)));e.beam.rotationQuaternion=B.Quaternion.FromUnitVectorsToRef(B.Axis.Y,direction,new B.Quaternion());const diameter=(e.form==='blaze'?.19:e.form==='tide'?.13:.045)*(1-t);e.beam.scaling.set(diameter,length*travel,diameter);}
  e.material.alpha=Math.max(0,(1-t)*(e.form==='shade'?.5:.9));if(t>=1)this.disposeEffect();
 }
}
