export const FORM_IDS=['base','blaze','volt','rock','shade','tide','nova','beast','fourarms','cannon','wildvine'];
export const clean=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
const aliases={base:['ben 10','ben dez','humano','ben','base'],blaze:['chama','heatblast'],volt:['xlr8','xrl8','acelerado','x l r 8'],rock:['diamante','diamondhead'],shade:['fantasmatico','ghostfreak'],tide:['aquatico','ripjaws'],nova:['alien x','alienx'],beast:['besta','wildmutt'],fourarms:['quatro bracos','four arms','fourarms'],cannon:['bola de canhao','cannonbolt'],wildvine:['cipo selvagem','wildvine']};
export function namedTransformation(text){
 const normalized=clean(text),input=' '+normalized+' ';if(/\b(nao|evite)\b/.test(input))return null;
 const explicit=/\b(transform\w*|vir[ae]|mude?|troque?|ativ[ae]|escolh[ao]|quero ser)\b/.test(normalized),matches=[];
 if(!explicit&&(/\?|\b(quem|qual|quais|como|por que|porque|onde|quando|quanto|me conte|me fala|conhece|o que)\b/.test(String(text).toLowerCase())||/\b(quem|qual|quais|como|por que|porque|onde|quando|quanto|me conte|me fala|conhece|o que)\b/.test(normalized)))return null;
 for(const [form,names] of Object.entries(aliases))for(const name of names)if(input.includes(' '+name+' ')&&(explicit||normalized===name||/\b(usa|use|solta|solte|poder|habilidade|dash|corre|correr|voa|voar)\b/.test(normalized)))matches.push({form,length:name.length,index:input.lastIndexOf(' '+name+' ')});
 return matches.sort((a,b)=>b.index-a.index||b.length-a.length)[0]?.form||null;
}
export const asksPower=text=>!(/\b(quem|qual|quais|como|por que|onde|quando|o que)\b/.test(clean(text)))&&/\b(poder|poderes|habilidade|habilidades)\b/.test(clean(text));
export const POWERS={base:{name:'Scanner do relógio',color:[.5,1,.2]},blaze:{name:'Pulso de calor',color:[1,.35,.05]},volt:{name:'Arrancada veloz',color:[.1,.75,1]},rock:{name:'Cristais de sustentação',color:[.2,1,.85]},shade:{name:'Fase espectral',color:[.7,.65,1]},tide:{name:'Jato de água',color:[.1,.45,1]},nova:{name:'Campo estelar',color:[.7,.6,1]},beast:{name:'Rastreamento',color:[1,.65,.2]},fourarms:{name:'Superforça',color:[1,.2,.1]},cannon:{name:'Rolamento de impacto',color:[.85,.85,.5]},wildvine:{name:'Crescimento de cipós',color:[.3,1,.2]}};

// Questions about a movement stay in the conversation lane.
export function asksMovement(text){const value=clean(text);if(/\b(nao|evite|quem|qual|quais|como|porque|onde|quando|o que)\b/.test(value)||String(text).includes('?'))return null;if(/\b(dash|arrancada|super velocidade)\b/.test(value))return 'dash';if(/\b(voa|voe|voar|voando|voo|decolar|decola)\b/.test(value))return 'fly';if(/\b(corre|corra|correr|corrida)\b/.test(value))return 'run';return null;}
