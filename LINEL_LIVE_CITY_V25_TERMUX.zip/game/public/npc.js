// Original stylized, articulated fan geometry. No official meshes or textures.
export function npcParts(id='lia'){
 const out=[],skin=id==='caio'?[.58,.35,.21]:[.91,.70,.53],hair=id==='gwen'?[.83,.25,.055]:id==='max'?[.88,.89,.82]:id==='bia'?[.16,.085,.04]:[.24,.13,.06],shirt=id==='gwen'?[.22,.47,.77]:id==='max'?[.78,.13,.12]:id==='caio'?[.87,.57,.17]:id==='bia'?[.52,.32,.68]:[.31,.65,.48],pants=id==='max'?[.56,.48,.30]:[.25,.28,.34],white=[.95,.95,.88],dark=[.08,.09,.10],wide=id==='max'?1.3:1;
 const add=(p,s,c,kind='sphere',joint='torso',rotation)=>out.push({p,s,c,kind,joint,rotation});
 add([0,1.50,0],[.68*wide,.83,.40*wide],shirt);add([0,1.94,0],[.23,.19,.23],skin);add([0,1.14,0],[.60*wide,.17,.38],pants);
 add([0,2.23,0],[.60,.67,.52],skin,'sphere','head');add([0,2.08,-.04],[.45,.25,.42],skin,'sphere','head');out.at(-1).role='jaw';
 for(const side of [-1,1]){add([side*.3,2.23,0],[.12,.2,.13],skin,'sphere','head');add([side*.12,2.27,-.244],[.19,.12,.045],white,'sphere','head');add([side*.12,2.27,-.27],[.074,.09,.025],id==='gwen'?[.16,.47,.25]:[.24,.29,.22],'sphere','head');add([side*.12,2.27,-.287],[.032,.055,.012],dark,'sphere','head');add([side*.12,2.36,-.24],[.19,.04,.035],hair,'sphere','head',[0,0,side*.12]);}
 add([0,2.19,-.28],[.08,.12,.09],skin,'sphere','head');add([0,2.08,-.25],[.15,.022,.025],[.35,.12,.1],'sphere','head');out.at(-1).role='mouth';
 add([0,2.47,.03],[.64,.25,.55],hair,'sphere','head');
 if(id==='gwen'){add([0,2.27,.23],[.65,.53,.19],hair,'sphere','head');for(const side of [-1,1])add([side*.27,2.18,.01],[.12,.48,.29],hair,'sphere','head');add([.04,2.43,-.23],[.52,.15,.12],hair,'sphere','head',[0,0,.18]);
 // white cat emblem on classic blue shirt
 add([0,1.57,-.211],[.26,.24,.022],white,'sphere');for(const side of [-1,1]){add([side*.086,1.71,-.21],[.09,.12,.025],white,'crystal');add([side*.055,1.58,-.228],[.025,.035,.012],dark);}add([0,1.51,-.232],[.035,.022,.012],dark);
 }else if(id==='max'){add([0,2.18,-.25],[.24,.11,.08],skin,'sphere','head');for(const side of [-1,1])add([side*.25,2.39,0],[.11,.25,.35],hair,'sphere','head');
 for(let i=0;i<8;i++){const x=(i%3-1)*.23,y=1.30+Math.floor(i/3)*.23;for(let k=0;k<5;k++)add([x+Math.cos(k*1.257)*.038,y+Math.sin(k*1.257)*.038,-.262],[.047,.047,.013],[.96,.80,.54]);}add([0,1.51,-.275],[.035,.7,.018],[.96,.72,.6],'box');
 }else{add([0,2.37,.21],[.57,.34,.19],hair,'sphere','head');if(id!=='caio')add([0,2.18,.25],[.35,.42,.16],hair,'sphere','head');}
 for(const side of [-1,1]){const suffix=side<0?'L':'R',arm='arm'+suffix,fore='forearm'+suffix,leg='leg'+suffix,shin='shin'+suffix;add([side*.42,1.69,0],[.28,.37,.36],shirt,'sphere',arm);add([side*.45,1.45,0],[.18,.35,.19],skin,'cylinder',arm);add([side*.46,1.28,0],[.20,.19,.20],skin,'sphere',fore);add([side*.47,1.1,0],[.16,.30,.18],skin,'cylinder',fore);add([side*.47,.91,-.01],[.18,.22,.16],skin,'sphere',fore);add([side*.18,.89,0],[.27,.48,.32],pants,'cylinder',leg);add([side*.18,.56,0],[.26,.22,.30],pants,'sphere',shin);add([side*.18,.35,0],[.24,.36,.28],id==='max'?skin:pants,'cylinder',shin);add([side*.18,.12,-.07],[.30,.22,.44],dark,'sphere',shin);add([side*.18,.05,-.08],[.31,.06,.45],white,'box',shin);}
 return out;
}
