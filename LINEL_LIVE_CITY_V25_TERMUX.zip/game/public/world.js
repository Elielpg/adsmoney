import {cityObjects,decorateCity} from './city.js';
import {heroParts,heroJoints} from './hero.js';
export const forms=['base','blaze','volt','rock','shade','tide','nova','beast','fourarms','cannon','wildvine'];
export const names=['Ben · clássico','Chama','XLR8','Diamante','Fantasmático','Aquático','Alien X','Besta','Quatro Braços','Bola de Canhão','Cipó Selvagem'];
export const districts=['Praça Aurora','Jardim das Águas','Mercado Solar','Vila Cristal','Parque das Estrelas','Centro Cultural'];
export function waypoint(t){const a=t/16;return [Math.sin(a)*19,0,Math.cos(a)*19];}
export function blocked(x,z){return Math.abs(x)>44||Math.abs(z)>44||(Math.hypot(x,z)<11);}
const colors=[[.15,.9,.44],[1,.28,.05],[.1,.7,1],[.3,1,.9],[.8,.8,1],[.15,.4,.85],[.09,.1,.2],[.6,.3,.12],[.85,.12,.14],[.6,.6,.65],[.3,.65,.1]];
export function character(form=0){
 if(form===0)return heroParts();
 const c=colors[form]||colors[0];const out=[];const box=(p,s,col=c,kind='box')=>out.push({p,s,c:col,kind});
 if(form===9){box([0,.9,0],[1.6,1.6,1.6],c,'sphere');box([0,.9,-.77],[1,.1,.1],[.1,.9,.3]);return out;}
 const height=form===7?1.1:form===8?1.9:1.5;const width=form===8?1.1:form===2?.38:.65;
 box([0,height,0],[width,.95,.45]);box([0,height+.75,0],[.56,.6,.52],form===0?[.91,.71,.5]:c,form===3?'crystal':'sphere');
 for(const side of [-1,1]){
  box([side*.23,.46,form===7?.25:0],[.23,.92,.28],form===0?[.16,.2,.25]:c);
  box([side*(width/2+.18),height-.1,0],[.22,.9,.25]);
  if(form===8)box([side*.85,height-.48,0],[.24,.7,.28]);
  if(form===7)box([side*.35,height+.8,-.12],[.25,.4,.25],c,'crystal');
  if(form===5)box([side*.46,height+.1,0],[.55,.6,.12],c,'crystal');
  if(form===10)for(let k=0;k<3;k++)box([side*(.5+k*.13),height+.2-k*.33,0],[.13,.6,.13]);
  box([side*.13,height+.8,-.26],[.1,.07,.05],[.1,1,.55]);
 }
 if(form===0)box([0,height+1.02,.05],[.59,.16,.48],[.2,.11,.06]);
 if(form===1)for(let k=0;k<5;k++)box([(k-2)*.14,height+1.15+(k%2)*.2,0],[.18,.6,.2],[1,.7,.05],'crystal');
 if(form===2)box([0,.7,.65],[.15,.15,1.3],c,'crystal');
 if(form===3)for(let k=0;k<5;k++)box([(k-2)*.18,height+.7,0],[.22,1,.25],c,'crystal');
 if(form===4)box([0,.45,0],[.55,.8,.45],c,'crystal');
 if(form===6)for(let k=0;k<12;k++)box([Math.sin(k*7)*.25,height-.35+(k%4)*.3,-.24],[.035,.035,.035],[1,1,1]);
 box([0,height,-.25],[.23,.23,.07],[.07,.1,.1]);box([0,height,-.3],[.13,.13,.03],[.4,1,.2]);return out;
}
export class World {
 constructor(canvas,onStatus){
  if(!globalThis.BABYLON)throw Error('Babylon.js local não instalado; execute npm run build');const B=BABYLON;this.canvas=canvas;this.onStatus=onStatus;this.time=0;this.form=0;this.talking=false;this.quality='balanced';this.visitors=[];this.imported=null;this.flash=0;this.materials=new Map();this.actors=[];this.visitorActors=[];
  this.engine=new B.Engine(canvas,true,{preserveDrawingBuffer:true,stencil:true});this.scene=new B.Scene(this.engine);this.scene.clearColor=new B.Color4(.65,.8,.85,1);this.scene.fogMode=B.Scene.FOGMODE_LINEAR;this.scene.fogStart=40;this.scene.fogEnd=115;this.scene.fogColor=new B.Color3(.65,.8,.85);this.scene.collisionsEnabled=true;
  this.camera=new B.FreeCamera('front',new B.Vector3(0,3.4,12),this.scene);this.camera.minZ=.2;this.camera.maxZ=150;this.camera.fov=.95;this.scene.activeCamera=this.camera;
  this.sun=new B.DirectionalLight('sun',new B.Vector3(-.5,-1,.4),this.scene);this.sun.position=new B.Vector3(20,40,-20);this.sun.intensity=.85;const sky=new B.HemisphericLight('sky',new B.Vector3(0,1,0),this.scene);sky.intensity=.7;sky.groundColor=new B.Color3(.45,.43,.37);
  this.shadow=new B.ShadowGenerator(512,this.sun);this.shadow.useBlurExponentialShadowMap=true;this.shadow.blurKernel=8;
  this.buildCity();for(const [i,o] of this.objects.entries()){const mesh=this.mesh(o,'city-'+i);mesh.receiveShadows=true;if(o.p[1]>2)this.shadow.addShadowCaster(mesh);mesh.checkCollisions=o.p[1]>1&&Math.hypot(o.p[0],o.p[2])>29;mesh.isPickable=mesh.checkCollisions;mesh.metadata={staticCity:true};mesh.freezeWorldMatrix();}
  decorateCity(this.scene);this.mergeCity();
  this.avatar=this.makeActor(0,'Linel');for(let i=0;i<12;i++){const a=this.makeActor(0,['Lia · florista','Caio · músico','Bia · guia','Max · leitor'][i%4]);a.root.scaling.setAll(.8);a.phase=i/12*Math.PI*2;a.state='walk';a.timer=4+i;this.actors.push(a);}
  this.labels=document.createElement('div');this.labels.id='world-labels';document.body.append(this.labels);this.last=performance.now();this.engine.runRenderLoop(()=>this.frame());addEventListener('resize',()=>this.engine.resize());
 }
 buildCity(){this.objects=cityObjects();}

 mergeCity(){const groups=new Map();for(const m of this.scene.meshes.filter(m=>m.metadata?.staticCity)){const key=m.material.uniqueId+':'+m.checkCollisions;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(m);}this.shadow.getShadowMap().renderList=[];for(const meshes of groups.values()){const collides=meshes[0].checkCollisions;const mesh=meshes.length>1?BABYLON.Mesh.MergeMeshes(meshes,true,true):meshes[0];if(!mesh)continue;mesh.checkCollisions=collides;mesh.isPickable=collides;mesh.receiveShadows=true;mesh.freezeWorldMatrix();if(collides)this.shadow.addShadowCaster(mesh);}}
 material(c){const key=c.join(',');if(this.materials.has(key))return this.materials.get(key);const m=new BABYLON.StandardMaterial('mat-'+key,this.scene);m.diffuseColor=new BABYLON.Color3(...c);m.specularColor=new BABYLON.Color3(.08,.08,.08);if(c[1]>.9&&c[0]<.5)m.emissiveColor=new BABYLON.Color3(...c.map(v=>v*.2));this.materials.set(key,m);return m;}
 mesh(o,name){const B=BABYLON;let m;if(o.kind==='cylinder')m=B.MeshBuilder.CreateCylinder(name,{height:1,diameter:1,tessellation:16},this.scene);else if(o.kind==='sphere')m=B.MeshBuilder.CreateSphere(name,{diameter:1,segments:12},this.scene);else if(o.kind==='crystal')m=B.MeshBuilder.CreatePolyhedron(name,{type:1,size:.5},this.scene);else m=B.MeshBuilder.CreateBox(name,{size:1},this.scene);m.position.set(...o.p);m.scaling.set(...o.s);m.material=this.material(o.c);if(o.rotation)m.rotation.set(...o.rotation);return m;}
 makeActor(form,name){const B=BABYLON,root=new B.TransformNode(name,this.scene),parts=[],rig={};const detailed=form===0&&name==='Linel';if(detailed)for(const [id,spec] of Object.entries(heroJoints)){const node=new B.TransformNode(name+'-'+id,this.scene),parent=spec.parent;node.parent=parent?rig[parent]:root;const origin=parent?heroJoints[parent].origin:[0,0,0];node.position.set(...spec.origin.map((v,i)=>v-origin[i]));rig[id]=node;}
 const geometry=character(detailed?0:form===0?-1:form);for(const [i,o] of geometry.entries()){const m=this.mesh(o,name+i);m.parent=detailed?rig[o.joint]:root;if(detailed)m.position.subtractInPlace(new B.Vector3(...heroJoints[o.joint].origin));m.isPickable=false;if(Math.max(...o.s)>.25)this.shadow.addShadowCaster(m);parts.push({m,p:[...o.p]});}return {root,parts,name,rig:detailed?rig:null};}

 transform(id){const n=forms.indexOf(id);if(n<0)return;const old=this.avatar.root;const a=this.makeActor(n,'Linel');a.root.position.copyFrom(old.position);a.root.rotation.copyFrom(old.rotation);old.dispose();this.avatar=a;this.form=n;if(this.imported)this.imported.root.setEnabled(false);this.flash=1;}
 async importGLB(url){const B=BABYLON;const result=await B.SceneLoader.ImportMeshAsync(null,'',url,this.scene);const root=new B.TransformNode('imported',this.scene);for(const m of result.meshes)if(!m.parent)m.parent=root;root.computeWorldMatrix(true);const bounds=root.getHierarchyBoundingVectors();const height=bounds.max.y-bounds.min.y;if(!(height>0)){root.dispose();throw Error('GLB sem geometria visível');}root.scaling.setAll(2.6/height);root.position.y=-bounds.min.y*2.6/height;const offset=root.position.y;const wrapper=new B.TransformNode('GLB actor',this.scene);root.parent=wrapper;for(const m of result.meshes){this.shadow.addShadowCaster(m);m.isPickable=false;}if(this.imported)this.imported.root.dispose();this.imported={root:wrapper,groups:result.animationGroups,offset,last:null,weights:new Map(),target:null};for(const g of result.animationGroups){g.stop();this.imported.weights.set(g,0);}this.avatar.root.setEnabled(false);this.animateImported();return {meshes:result.meshes.length,skeletons:result.skeletons.length,animations:result.animationGroups.map(g=>g.name)};}
 animateImported(dt=.016){if(!this.imported)return;const imported=this.imported,desired=this.talking?'talk':'walk';if(imported.last!==desired){imported.last=desired;const match=imported.groups.find(g=>g.name.toLowerCase().includes(desired))||imported.groups.find(g=>g.name.toLowerCase().includes('idle'));imported.target=match;if(match&&!match.isPlaying){match.start(true,1);match.setWeightForAllAnimatables(0);}}
  for(const g of imported.groups){const target=g===imported.target?1:0,old=imported.weights.get(g)||0,weight=old+(target-old)*Math.min(1,dt*8);imported.weights.set(g,weight);if(g.isPlaying)g.setWeightForAllAnimatables(weight);if(!target&&weight<.005&&g.isPlaying)g.stop();}
 }

 animateActor(actor,dt,phase,talking=false){if(actor.rig){const r=actor.rig,swing=talking?0:Math.sin(phase)*.38;for(const side of ['L','R']){const sign=side==='L'?1:-1;r['leg'+side].rotation.x=swing*sign;r['shin'+side].rotation.x=talking?0:Math.max(0,-Math.sin(phase+(sign<0?Math.PI:0)))*.35;r['arm'+side].rotation.x=-swing*sign*.65;r['arm'+side].rotation.z=talking?sign*(.12+Math.sin(phase*1.5)*.08):sign*.04;r['forearm'+side].rotation.x=talking?-.45+Math.sin(phase)*.1:-.08;}r.head.rotation.y=talking?Math.sin(phase*.5)*.06:0;r.head.rotation.x=talking?Math.sin(phase)*.025:0;actor.root.position.y=talking?0:Math.abs(Math.sin(phase))*.018;return;}for(const {m,p} of actor.parts){if(p[1]<.8&&p[0]!==0)m.rotation.x=talking?0:Math.sin(phase+(p[0]<0?Math.PI:0))*.32;else if(p[1]>1&&Math.abs(p[0])>.35)m.rotation.x=talking?Math.sin(phase*1.8)*.16:Math.sin(phase+(p[0]<0?0:Math.PI))*.2;}actor.root.position.y=talking?0:Math.abs(Math.sin(phase))*.025;}
 frame(){const B=BABYLON,now=performance.now(),dt=Math.min(.05,(now-this.last)/1000);this.last=now;if(!this.talking)this.time+=dt;const pos=waypoint(this.time),next=waypoint(this.time+.1),heading=Math.atan2(next[0]-pos[0],next[2]-pos[2])+Math.PI;
  this.avatar.root.position.x=pos[0];this.avatar.root.position.z=pos[2];this.avatar.root.rotation.y=heading;this.animateActor(this.avatar,dt,this.time*5,this.talking);
  if(this.imported&&this.imported.root.isEnabled()){this.imported.root.position.set(pos[0],0,pos[2]);this.imported.root.rotation.y=heading;this.animateImported(dt);}
  const center=new B.Vector3(pos[0],1.4,pos[2]);let wanted=new B.Vector3(pos[0]-Math.sin(heading)*6,3.5,pos[2]-Math.cos(heading)*6);const direction=wanted.subtract(center),distance=direction.length(),hit=this.scene.pickWithRay(new B.Ray(center,direction.normalize(),distance),m=>m.checkCollisions);if(hit?.hit&&hit.distance<5.5)wanted=center.add(direction.scale(Math.max(1.6,hit.distance-.6)));this.camera.position=B.Vector3.Lerp(this.camera.position,wanted,Math.min(1,dt*4));this.camera.setTarget(center);
  for(const [i,a] of this.actors.entries()){a.root.setEnabled(i<(this.quality==='high'?12:this.quality==='economy'?4:6));a.timer-=dt;if(a.timer<=0){a.state=a.state==='walk'?'greet':'walk';a.timer=a.state==='walk'?10+i:3;}if(a.state==='walk')a.phase+=dt*.025;const x=Math.sin(a.phase)*23,z=Math.cos(a.phase)*23;a.root.position.x=x;a.root.position.z=z;a.root.rotation.y=-a.phase;this.animateActor(a,dt,this.time*3+i,a.state!=='walk');}
  while(this.visitorActors.length<this.visitors.length){const actor=this.makeActor(0,'visitante');actor.root.scaling.setAll(.78);const label=document.createElement('span');label.className='visitor-label';this.labels.append(label);actor.label=label;this.visitorActors.push(actor);}
  this.visitorActors.forEach((a,i)=>{a.root.setEnabled(i<this.visitors.length);if(i>=this.visitors.length){a.label.hidden=true;return;}const angle=this.time/16+.18+i*.08;a.root.position.set(Math.sin(angle)*21,0,Math.cos(angle)*21);a.root.rotation.y=-angle;this.animateActor(a,dt,this.time*4,false);const screen=B.Vector3.Project(a.root.position.add(new B.Vector3(0,2.6,0)),B.Matrix.Identity(),this.scene.getTransformMatrix(),this.camera.viewport.toGlobal(this.engine.getRenderWidth(),this.engine.getRenderHeight()));a.label.textContent='@'+this.visitors[i];a.label.hidden=screen.z<0||screen.z>1;a.label.style.left=screen.x/this.engine.getRenderWidth()*100+'%';a.label.style.top=screen.y/this.engine.getRenderHeight()*100+'%';});
  const daylight=.65+Math.sin(now/180000)*.35;this.sun.intensity=daylight*.88;this.scene.clearColor=new B.Color4(.2+daylight*.45,.25+daylight*.55,.36+daylight*.49,1);this.scene.fogColor=new B.Color3(this.scene.clearColor.r,this.scene.clearColor.g,this.scene.clearColor.b);
  if(this.quality!==this.appliedQuality){this.appliedQuality=this.quality;this.engine.setHardwareScalingLevel(this.quality==='economy'?1.7:this.quality==='high'?1:1.25);this.shadow.getShadowMap().refreshRate=this.quality==='economy'?0:this.quality==='high'?1:2;this.engine.resize();}
  if(this.flash>0){this.flash-=dt*2;document.documentElement.style.setProperty('--flash',Math.max(0,this.flash)*.5);}
  this.scene.render();if(Math.floor(now/500)!==this.reported){this.reported=Math.floor(now/500);this.onStatus({fps:Math.round(this.engine.getFps()),district:districts[Math.floor((this.time/16%(Math.PI*2))/(Math.PI/3))],pos});}
 }
}
