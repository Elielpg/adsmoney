export const BUILD_ID='27.0.0';
export const BUILD_LABEL='Ben 10 · Arena LIVE · 27.0.0';
