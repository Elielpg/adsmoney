export const BUILD_ID='26.2.0';
export const BUILD_LABEL='Ben 10 · Ação e viagens · 26.2.0';
