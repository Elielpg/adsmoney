export class LiveAdapter {
 constructor(onEvent,onStatus,{load=name=>import(name)}={}){this.onEvent=onEvent;this.onStatus=onStatus;this.load=load;this.client=null;this.generation=0;this.timer=null;this.attempt=0;this.state={status:'desconectado',provider:null,error:null};}
 status(status,extra={}){this.state={...this.state,status,...extra};this.onStatus(this.state);}
 async connect(username,provider='piratetok'){
  await this.disconnect();const generation=this.generation;this.username=username.replace(/^@/,'');this.provider=provider;
  if(!/^[\w.]{2,32}$/.test(this.username))throw Error('@ inválido');this.status('conectando',{provider,error:null,roomId:null});
  try{
   if(!['piratetok','alternative'].includes(provider))throw Error('Adaptador inválido');
   const mod=await this.load(provider==='piratetok'?'piratetok-live-js':'tiktok-live-connector');if(generation!==this.generation)return;
   const pirate=provider==='piratetok';const client=pirate?new mod.TikTokLiveClient(this.username).timeout(15000).maxRetries(6):new mod.WebcastPushConnection(this.username);this.client=client;
   if(pirate&&process.env.HTTPS_PROXY)client.proxy(process.env.HTTPS_PROXY);
   const current=()=>generation===this.generation;
   for(const [raw,type] of Object.entries({chat:'comment',gift:'gift',like:'like',follow:'follow',share:'share',join:'join',...(!pirate?{member:'join'}:{})}))client.on(raw,e=>{if(!current())return;this.status('recebendo eventos');try{this.onEvent({id:e.common?.msgId||e.msgId,type,user:e.user?.uniqueId||e.user?.nickname||e.uniqueId,text:e.content||e.comment,gift:e.gift?.name||e.giftName,count:e.repeatCount||e.count||e.likeCount,repeatEnd:pirate?(e.isStreakOver??mod.isStreakOver?.(e)??(Number(e.gift?.type)!==1||Number(e.repeatEnd)===1)):(e.giftType===1?Number(e.repeatEnd)===1:true)},'tiktok');}catch{this.status('erro',{error:'Evento recebido com formato inválido'});}});
   client.on('connected',e=>{if(current())this.status('sala resolvida',{roomId:String(e?.roomId||'')});});
   client.on('reconnecting',()=>{if(current())this.status('reconectando');});
   client.on('disconnected',()=>{if(current()){this.status('desconectado');if(!pirate)this.schedule();}});
   client.on('liveEnded',()=>{if(current()){this.disconnect();this.status('desconectado',{error:'LIVE encerrada'});}});
   client.on('error',()=>{if(current())this.status('erro',{error:'Falha de rede/protocolo do conector. Verifique se a conta está ao vivo e os domínios estão liberados.'});});
   const result=await client.connect();if(!current()){client.disconnect();return;}
   this.attempt=0;if(pirate||result?.isConnected)this.status('websocket confirmado',{roomId:String(pirate?result:result?.roomId||'')});else this.status('sala resolvida',{roomId:String(result?.roomId||'')});
  }catch(e){if(generation!==this.generation)return;this.status('erro',{error:e.code==='ERR_MODULE_NOT_FOUND'?'Conector alternativo não instalado. Consulte docs/INTEGRACOES.md.':String(e.message).replace(/https?:\/\/[^\s]+/g,'[destino de rede]').slice(0,300)});}
 }
 schedule(){clearTimeout(this.timer);if(this.attempt>=6){this.status('erro',{error:'Limite de reconexão atingido'});return;}this.timer=setTimeout(()=>this.connect(this.username,this.provider),Math.min(60000,1000*2**this.attempt++));this.timer.unref?.();}
 async disconnect(){this.generation++;clearTimeout(this.timer);this.client?.removeAllListeners?.();this.client?.disconnect?.();this.client=null;this.status('desconectado');}
}
