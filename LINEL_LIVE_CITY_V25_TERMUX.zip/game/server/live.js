export function normalizeUsername(value){const raw=String(value).trim();const username=raw.replace(/^@/,'');if(!/^[\w.]{2,24}$/.test(username))throw Error('Digite apenas o @ do TikTok, sem link ou espaços (2 a 24 caracteres).');return username;}
export function liveError(error){const message=String(error?.message||error||'Erro desconhecido').replace(/https?:\/\/[^\s]+/g,'[destino de rede]').slice(0,200);if(/not.?live|offline|not.?found|not streaming|no active|no live/i.test(message))return 'A conta não está ao vivo ou o @ não foi encontrado. Abra uma LIVE pública nessa conta e tente novamente.';if(/403|blocked|forbidden|captcha/i.test(message))return 'O TikTok ou a rede bloqueou a conexão. Confirme que a LIVE é pública e tente outra rede. Detalhe: '+message;if(/timeout|timed out|handshake|socket/i.test(message))return 'Não foi possível confirmar o WebSocket da LIVE. Confira a rede e se a transmissão continua ativa. Detalhe: '+message;return message;}
export class LiveAdapter {
 constructor(onEvent,onStatus,{load=name=>import(name)}={}){this.onEvent=onEvent;this.onStatus=onStatus;this.load=load;this.client=null;this.generation=0;this.timer=null;this.attempt=0;this.state={status:'desconectado',provider:null,error:null};}
 status(status,extra={}){this.state={...this.state,status,...extra};this.onStatus(this.state);}
 async connect(username,provider='piratetok'){
  const normalized=normalizeUsername(username);await this.disconnect();const generation=this.generation;this.username=normalized;this.provider=provider;
  this.status('conectando',{provider,username:this.username,error:null,roomId:null,events:0,lastEventAt:null});
  try{
   if(!['piratetok','alternative'].includes(provider))throw Error('Adaptador inválido');
   const mod=await this.load(provider==='piratetok'?'piratetok-live-js':'tiktok-live-connector');if(generation!==this.generation)return;
   const pirate=provider==='piratetok';const client=pirate?new mod.TikTokLiveClient(this.username).timeout(15000).maxRetries(6):new mod.WebcastPushConnection(this.username);this.client=client;
   if(pirate&&process.env.HTTPS_PROXY)client.proxy(process.env.HTTPS_PROXY);
   const current=()=>generation===this.generation;
   for(const [raw,type] of Object.entries({chat:'comment',gift:'gift',like:'like',follow:'follow',share:'share',join:'join',...(!pirate?{member:'join'}:{})}))client.on(raw,e=>{if(!current())return;this.status('recebendo eventos',{events:(this.state.events||0)+1,lastEventAt:Date.now(),error:null});try{this.onEvent({id:e.common?.msgId||e.msgId,type,user:e.user?.uniqueId||e.user?.nickname||e.uniqueId,text:e.content||e.comment,gift:e.gift?.name||e.giftName,count:e.repeatCount||e.count||e.likeCount,repeatEnd:pirate?(e.isStreakOver??mod.isStreakOver?.(e)??(Number(e.gift?.type)!==1||Number(e.repeatEnd)===1)):(e.giftType===1?Number(e.repeatEnd)===1:true)},'tiktok');}catch{this.status('erro',{error:'Evento recebido com formato inválido'});}});
   client.on('connected',e=>{if(current())this.status('sala resolvida',{roomId:String(e?.roomId||'')});});
   client.on('reconnecting',()=>{if(current())this.status('reconectando');});
   client.on('disconnected',()=>{if(current()){this.status('desconectado');if(!pirate)this.schedule();}});
   client.on('liveEnded',()=>{if(current()){this.disconnect();this.status('desconectado',{error:'LIVE encerrada'});}});
   client.on('error',()=>{if(current())this.status('erro',{error:'Falha de rede/protocolo do conector. Verifique se a conta está ao vivo e os domínios estão liberados.'});});
   const result=await client.connect();if(!current()){client.disconnect();return;}
   this.attempt=0;if(pirate||result?.isConnected)this.status('websocket confirmado',{roomId:String(pirate?result:result?.roomId||'')});else this.status('sala resolvida',{roomId:String(result?.roomId||'')});
  }catch(e){if(generation!==this.generation)return;this.client?.removeAllListeners?.();this.client?.disconnect?.();this.client=null;this.status('erro',{error:e.code==='ERR_MODULE_NOT_FOUND'?'Conector alternativo não instalado. Consulte docs/INTEGRACOES.md.':liveError(e)});}
 }
 schedule(){clearTimeout(this.timer);if(this.attempt>=6){this.status('erro',{error:'Limite de reconexão atingido'});return;}this.timer=setTimeout(()=>this.connect(this.username,this.provider),Math.min(60000,1000*2**this.attempt++));this.timer.unref?.();}
 async disconnect(){this.generation++;clearTimeout(this.timer);this.client?.removeAllListeners?.();this.client?.disconnect?.();this.client=null;this.status('desconectado',{roomId:null,events:0,lastEventAt:null,error:null});}
}
