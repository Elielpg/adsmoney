import {POWER_TIMINGS} from '../public/power-timeline.js';
import {FORM_IDS,POWERS} from '../public/transformations.js';
import {CITIES_BY_ID,MOVEMENT_PRESETS,ROUTE_RADIUS,canMove,routePosition,signedArc} from '../public/traversal.js';
export const MISSIONS=[
 {npc:'Lia · florista',title:'Jardim sem vida',request:'As plantas da praça estão murchas! Pode usar Cipó Selvagem para recuperá-las?',form:'wildvine',object:'garden'},
 {npc:'Caio · comerciante',title:'Entrega bloqueada',request:'Essas caixas bloquearam a passagem. Quatro Braços pode abrir o caminho?',form:'fourarms',object:'crates'},
 {npc:'Bia · guia',title:'Cristal partido',request:'A escultura do bairro quebrou! Diamante, precisamos de novos cristais de apoio.',form:'rock',object:'crystal'},
 {npc:'Lia · florista',title:'Estufa congelada',request:'O reservatório da estufa congelou. Chama, pode aquecê-lo com cuidado?',form:'blaze',object:'ice'},
 {npc:'Caio · músico',title:'Fumaça na praça',request:'Um pequeno foco de fogo perto da fonte! Aquático pode apagar com seu jato?',form:'tide',object:'fire'},
 {npc:'Gwen Tennyson',speaker:'gwen',title:'Sinal perdido',request:'Meu transmissor caiu atrás da grade. Fantasmático pode atravessar e recuperar?',form:'shade',object:'signal'},
 {npc:'Vô Max',speaker:'max',title:'Livros espalhados',request:'O vento espalhou meus livros. XLR8, pode recolher tudo num instante?',form:'volt',object:'books'},
 {npc:'Lia · florista',title:'Rastro no parque',request:'Meu cachorro se escondeu. Besta, consegue seguir o cheiro e encontrá-lo?',form:'beast',object:'trail'},
 {npc:'Caio · comerciante',title:'Pedras no caminho',request:'As pedras caíram na trilha. Bola de Canhão pode remover o bloqueio?',form:'cannon',object:'stones'},
 {npc:'Gwen Tennyson',speaker:'gwen',title:'Raízes na praça',request:'Ben, as trepadeiras precisam de apoio. Cipó Selvagem pode criar uma passagem verde?',form:'wildvine',object:'garden'},
 {npc:'Vô Max',speaker:'max',title:'Entrega expressa na baía',request:'Ben, a Baía do Farol precisa destes livros. Corra como XLR8 até o cais e reúna as páginas espalhadas!',thanks:'Entrega recebida! Sua velocidade salvou a biblioteca.',form:'volt',object:'books',travel:{mode:'dash',city:'coast'}},
 {npc:'Gwen Tennyson',speaker:'gwen',title:'Voo de reconhecimento',request:'Chama, voe até a Serra dos Cristais e aqueça o reservatório congelado. Cuide para não atingir ninguém!',thanks:'O reservatório voltou a funcionar. Bom pouso, Ben!',form:'blaze',object:'ice',travel:{mode:'fly',city:'canyon'}},
 {npc:'Bia · guia',speaker:'bia',title:'Sinal entre as montanhas',request:'Fantasmático, sobrevoe a trilha da serra e recupere nosso transmissor preso na grade.',thanks:'Sinal recuperado! Agora consigo orientar os visitantes.',form:'shade',object:'signal',travel:{mode:'fly',city:'canyon'}},
 {npc:'Caio · comerciante',speaker:'caio',title:'Socorro em Bellwood',request:'Quatro Braços, corra até Bellwood! Uma entrega caiu e as caixas bloquearam a passagem.',thanks:'A rua está livre outra vez. Obrigado, Ben!',form:'fourarms',object:'crates',travel:{mode:'run',city:'bellwood'}}
];
export class Adventure{
 constructor({now=Date.now(),onChange=()=>{},missionFactory=null,random=Math.random}={}){this.missionFactory=missionFactory;this.random=random;this.missionPromise=null;this.missionState={status:'idle',mode:'local',warning:null};this.history=[];this.revision=0;this.onChange=onChange;this.options={autoTransform:true,autoMissions:true,autoPowers:true,npcSpeech:true,transformSeconds:90,missionSeconds:45};this.city='bellwood';this.motion=null;this.pendingMovement=null;this.nextMovement=0;this.travelTrace=null;this.form='base';this.pending=null;this.pendingPower=null;this.lastTransform=-Infinity;this.nextTransform=now+90000;this.expires=Infinity;this.nextMission=now+45000;this.quest=null;this.questIndex=0;this.completed=0;this.power=null;this.nextPower=0;this.position=[0,0,19];this.sequence=0;}
 snapshot(){return {city:this.city,motion:this.motion?{...this.motion}:null,pendingMovement:this.pendingMovement?{...this.pendingMovement}:null,missionState:{...this.missionState},revision:this.revision,options:{...this.options},form:this.form,pending:this.pending,quest:this.quest?{...this.quest,travel:this.quest.travel?{...this.quest.travel}:null,position:[...this.quest.position]}:null,completed:this.completed,power:this.power?{...this.power,position:[...this.power.position]}:null,position:[...this.position]};}
 emit(){this.revision++;this.onChange(this.snapshot());}
 configure(data,now=Date.now()){for(const key of ['autoTransform','autoMissions','autoPowers','npcSpeech'])if(typeof data[key]==='boolean')this.options[key]=data[key];for(const key of ['transformSeconds','missionSeconds'])if(data[key]!==undefined){if(!Number.isFinite(data[key])||data[key]<15||data[key]>600)throw Error('Intervalo precisa estar entre 15 e 600 segundos');this.options[key]=data[key];}this.nextTransform=now+this.options.transformSeconds*1000;this.nextMission=now+this.options.missionSeconds*1000;this.emit();}
 locate(position,now=Date.now()){
  if(!Array.isArray(position)||position.length!==3||!position.every(Number.isFinite)||Math.hypot(position[0],position[2])<14||Math.hypot(position[0],position[2])>26||position[1]<-.3||position[1]>8)throw Error('Posição fora do passeio');
  const q=this.quest,angle=Math.atan2(position[0],position[2]);this.position=[position[0],Math.max(0,position[1]),position[2]];
  if(q?.status!=='active'||q.stage!=='travel')return;
  const beforeDistance=q.travel.distance,trace=this.travelTrace||{angle,time:now},dt=(now-trace.time)/1000,delta=signedArc(trace.angle,angle)*ROUTE_RADIUS,preset=MOVEMENT_PRESETS[q.travel.mode],maxSpeed=preset.speed*1.8;
  // Only plausible forward samples on the safe route count. No teleport or altitude-only completion.
  const plausible=dt>0&&dt<=8&&delta>=0&&delta<=maxSpeed*dt+1.2&&Math.abs(Math.hypot(position[0],position[2])-ROUTE_RADIUS)<2.5;
  if(plausible&&this.form===q.form){q.travel.distance=Math.min(q.travel.requiredDistance,q.travel.distance+delta);if(q.travel.mode==='fly'&&canMove(this.form,'fly'))q.travel.peakY=Math.max(q.travel.peakY,position[1]);}
  this.travelTrace={angle,time:now};
  const near=Math.hypot(position[0]-q.position[0],position[2]-q.position[2])<=2.5,airborne=q.travel.mode!=='fly'||q.travel.peakY>=1;
  if(near&&q.travel.distance>=q.travel.requiredDistance*.78&&airborne){q.stage='objective';q.travel.arrived=true;this.city=q.travel.city;this.emit();}else if(Math.floor(q.travel.distance)!==Math.floor(beforeDistance))this.emit();
 }
 requestMovement(mode,now=Date.now()){
  if(!Object.hasOwn(MOVEMENT_PRESETS,mode))throw Error('Movimento inválido');
  if(now<this.nextMovement)throw Error('Movimento recarregando');
  const form=mode==='dash'?'volt':mode==='fly'?(canMove(this.form,'fly')?this.form:'blaze'):this.pending?.form||this.form;
  this.pendingMovement={mode,form,expires:now+30000};if(form!==this.form)this.requestTransform(form,'movement');this.emit();return this.snapshot();
 }
 startMovement(mode,now=Date.now()){
  if(!canMove(this.form,mode))throw Error('Esta forma não pode usar este movimento');const preset=MOVEMENT_PRESETS[mode],angle=Math.atan2(this.position[0],this.position[2]);
  this.nextMovement=now+preset.cooldown;this.motion={id:++this.sequence,mode,form:this.form,at:now,duration:preset.duration,status:'active',paused:false,fromAngle:angle,toAngle:angle+preset.distance/ROUTE_RADIUS,cityId:this.city,distance:preset.distance};this.emit();return this.motion;
 }
 requestTransform(form,source='chat'){if(!FORM_IDS.includes(form))throw Error('Forma inválida');this.pending={form,source};this.emit();}
 requestPower(form=this.pending?.form||this.form,now=Date.now()){if(!FORM_IDS.includes(form))throw Error('Forma inválida');this.pendingPower={form,expires:now+15000};}
 startMission(now=Date.now()){
  if(this.quest?.status==='active')return this.quest;if(this.missionPromise)return this.missionPromise;
  const finish=(spec,warning=null)=>{if(!spec||!FORM_IDS.includes(spec.form)||typeof spec.title!=='string'||typeof spec.object!=='string')throw Error('Resposta de missão inválida');const from=Math.atan2(this.position[0],this.position[2]),journey=spec.travel&&Object.hasOwn(CITIES_BY_ID,spec.travel.city)&&canMove(spec.form,spec.travel.mode)?spec.travel:null,arc=journey?.mode==='fly'?.98:journey?.mode==='dash'?.82:journey?.mode==='run'?.65:.14;this.quest={...spec,id:++this.sequence,position:routePosition(from+arc),stage:journey?'travel':'objective',travel:journey?{...journey,fromCity:this.city,requiredDistance:arc*ROUTE_RADIUS,distance:0,peakY:0,arrived:false}:null,progress:0,total:3,status:'active',started:now};this.travelTrace={angle:from,time:now};this.history.push(spec.title);this.history=this.history.slice(-8);this.missionState={status:'ready',mode:spec.generatedBy||'local',warning};this.emit();return this.quest;};
  const fallback=()=>{const eligible=MISSIONS.filter(s=>!this.history.slice(-4).includes(s.title)),pool=eligible.length?eligible:MISSIONS;return {...pool[Math.floor(this.random()*pool.length)%pool.length],generatedBy:'local'};};
  let generated;try{generated=this.missionFactory?.({previous:[...this.history]});}catch(error){return finish(fallback(),error.message);}
  if(!generated)return finish(fallback());
  this.missionState={status:'generating',mode:'gemini',warning:null};this.emit();
  this.missionPromise=Promise.resolve(generated).then(spec=>finish(spec)).catch(error=>finish(fallback(),'IA indisponível: '+String(error.message).slice(0,140))).finally(()=>{this.missionPromise=null;});return this.missionPromise;
 }
 usePower(now=Date.now(),busy=false){if(busy)throw Error('Aguarde a fala terminar');if(now<this.nextPower)throw Error('Poder recarregando');const duration=Math.round((POWER_TIMINGS[this.form]||POWER_TIMINGS.base).reduce((a,b)=>a+b,0)*1000);this.nextPower=now+Math.max(2500,duration+100);let result='Efeito livre';const q=this.quest;if(q?.status==='active'){const distance=Math.hypot(this.position[0]-q.position[0],this.position[2]-q.position[2]);if(q.stage==='travel')result='Chegue ao destino da missão primeiro';else if(this.form!==q.form)result='A missão precisa de outra forma';else if(distance>4.5)result='Aproxime-se do pedido de ajuda';else {q.progress++;result='Objetivo progrediu';if(q.progress>=q.total){q.status='complete';q.stage='complete';this.completed++;this.nextMission=now+this.options.missionSeconds*1000;result='Missão concluída';}}}this.power={id:++this.sequence,form:this.form,name:POWERS[this.form].name,position:[...this.position],at:now,duration,result};this.emit();return this.power;}
 tick(now=Date.now(),busy=false){
  if(this.motion?.status==='active'){
   if(busy&&!this.motion.paused){this.motion.paused=true;this.motion.pausedAt=now;this.emit();}
   else if(!busy&&this.motion.paused){this.motion.at+=Math.max(0,now-this.motion.pausedAt);delete this.motion.pausedAt;this.motion.paused=false;this.emit();}
   if(!this.motion.paused&&now-this.motion.at>=this.motion.duration){this.motion.status='complete';this.emit();}
  }
  if(busy)return;
  if(this.pending&&(this.pending.source==='operator'||now-this.lastTransform>=8000)){if(this.motion?.status==='active'&&this.motion.form!==this.pending.form){this.motion.status='complete';this.motion.cancelled=true;this.motion.paused=false;}this.form=this.pending.form;this.pending=null;this.lastTransform=now;this.expires=this.form==='base'?Infinity:now+60000;this.nextTransform=now+this.options.transformSeconds*1000;this.emit();}
  if(this.pendingMovement){if(now>this.pendingMovement.expires){this.pendingMovement=null;this.emit();}else if(this.pendingMovement.form===this.form&&now>=this.nextMovement){const {mode}=this.pendingMovement;this.pendingMovement=null;this.startMovement(mode,now);}}
  if(this.pendingPower){if(now>this.pendingPower.expires)this.pendingPower=null;else if(this.pendingPower.form===this.form&&now>=this.nextPower){this.pendingPower=null;this.usePower(now);}}
  if(this.options.autoMissions&&now>=this.nextMission&&this.quest?.status!=='active')this.startMission(now);
  const q=this.quest;
  if(q?.status==='active'){
   if(this.options.autoTransform&&this.form!==q.form&&!this.pending&&now-q.started>=3000)this.requestTransform(q.form,'mission');
   if(q.stage!=='travel'&&this.options.autoPowers&&this.form===q.form&&now>=this.nextPower&&Math.hypot(this.position[0]-q.position[0],this.position[2]-q.position[2])<=4.5)this.usePower(now);
  }else if(!this.pending&&!this.pendingMovement&&this.motion?.status!=='active'){if(this.form!=='base'&&now>=this.expires)this.requestTransform('base','watch-timeout');else if(this.options.autoTransform&&now>=this.nextTransform)this.requestTransform(FORM_IDS.filter(id=>id!=='nova')[(FORM_IDS.filter(id=>id!=='nova').indexOf(this.form)+1)%10],'automatic');}
 }
}
