import {FORM_IDS,POWERS} from '../public/transformations.js';
export const MISSIONS=[
 {npc:'Lia · florista',title:'Jardim sem vida',request:'As plantas da praça estão murchas! Pode usar Cipó Selvagem para recuperá-las?',form:'wildvine',object:'garden'},
 {npc:'Caio · comerciante',title:'Entrega bloqueada',request:'Essas caixas bloquearam a passagem. Quatro Braços pode abrir o caminho?',form:'fourarms',object:'crates'},
 {npc:'Bia · guia',title:'Cristal partido',request:'A escultura do bairro quebrou! Diamante, precisamos de novos cristais de apoio.',form:'rock',object:'crystal'},
 {npc:'Lia · florista',title:'Estufa congelada',request:'O reservatório da estufa congelou. Chama, pode aquecê-lo com cuidado?',form:'blaze',object:'ice'},
 {npc:'Caio · músico',title:'Fumaça na praça',request:'Um pequeno foco de fogo perto da fonte! Aquático pode apagar com seu jato?',form:'tide',object:'fire'},
 {npc:'Gwen Tennyson',speaker:'gwen',title:'Sinal perdido',request:'Meu transmissor caiu atrás da grade. Fantasmático pode atravessar e recuperar?',form:'shade',object:'signal'},
 {npc:'Vô Max',speaker:'max',title:'Livros espalhados',request:'O vento espalhou meus livros. XLR8, pode recolher tudo num instante?',form:'volt',object:'books'},
 {npc:'Lia · florista',title:'Rastro no parque',request:'Meu cachorro se escondeu. Besta, consegue seguir o cheiro e encontrá-lo?',form:'beast',object:'trail'},
 {npc:'Caio · comerciante',title:'Pedras no caminho',request:'As pedras caíram na trilha. Bola de Canhão pode remover o bloqueio?',form:'cannon',object:'stones'},
 {npc:'Gwen Tennyson',speaker:'gwen',title:'Raízes na praça',request:'Ben, as trepadeiras precisam de apoio. Cipó Selvagem pode criar uma passagem verde?',form:'wildvine',object:'garden'}
];
export class Adventure{
 constructor({now=Date.now(),onChange=()=>{},missionFactory=null,random=Math.random}={}){this.missionFactory=missionFactory;this.random=random;this.missionPromise=null;this.missionState={status:'idle',mode:'local',warning:null};this.history=[];this.revision=0;this.onChange=onChange;this.options={autoTransform:true,autoMissions:true,autoPowers:true,npcSpeech:true,transformSeconds:90,missionSeconds:45};this.form='base';this.pending=null;this.pendingPower=null;this.lastTransform=-Infinity;this.nextTransform=now+90000;this.expires=Infinity;this.nextMission=now+45000;this.quest=null;this.questIndex=0;this.completed=0;this.power=null;this.nextPower=0;this.position=[0,0,19];this.sequence=0;}
 snapshot(){return {missionState:{...this.missionState},revision:this.revision,options:{...this.options},form:this.form,pending:this.pending,quest:this.quest?{...this.quest,position:[...this.quest.position]}:null,completed:this.completed,power:this.power?{...this.power}:null,position:[...this.position]};}
 emit(){this.revision++;this.onChange(this.snapshot());}
 configure(data,now=Date.now()){for(const key of ['autoTransform','autoMissions','autoPowers','npcSpeech'])if(typeof data[key]==='boolean')this.options[key]=data[key];for(const key of ['transformSeconds','missionSeconds'])if(data[key]!==undefined){if(!Number.isFinite(data[key])||data[key]<15||data[key]>600)throw Error('Intervalo precisa estar entre 15 e 600 segundos');this.options[key]=data[key];}this.nextTransform=now+this.options.transformSeconds*1000;this.nextMission=now+this.options.missionSeconds*1000;this.emit();}
 locate(position){if(!Array.isArray(position)||position.length!==3||!position.every(Number.isFinite)||Math.hypot(position[0],position[2])<14||Math.hypot(position[0],position[2])>26||Math.abs(position[1])>4)throw Error('Posição fora do passeio');this.position=[position[0],0,position[2]];}
 requestTransform(form,source='chat'){if(!FORM_IDS.includes(form))throw Error('Forma inválida');this.pending={form,source};this.emit();}
 requestPower(form=this.pending?.form||this.form,now=Date.now()){if(!FORM_IDS.includes(form))throw Error('Forma inválida');this.pendingPower={form,expires:now+15000};}
 startMission(now=Date.now()){
  if(this.quest?.status==='active')return this.quest;if(this.missionPromise)return this.missionPromise;
  const finish=(spec,warning=null)=>{const a=Math.atan2(this.position[0],this.position[2])+.14;this.quest={...spec,id:++this.sequence,position:[Math.sin(a)*19,0,Math.cos(a)*19],progress:0,total:3,status:'active',started:now};this.history.push(spec.title);this.history=this.history.slice(-8);this.missionState={status:'ready',mode:spec.generatedBy||'local',warning};this.emit();return this.quest;};
  const fallback=()=>{const eligible=MISSIONS.filter(s=>!this.history.slice(-4).includes(s.title)),pool=eligible.length?eligible:MISSIONS;return {...pool[Math.floor(this.random()*pool.length)%pool.length],generatedBy:'local'};};
  let generated;try{generated=this.missionFactory?.({previous:[...this.history]});}catch(error){return finish(fallback(),error.message);}
  if(!generated)return finish(fallback());
  this.missionState={status:'generating',mode:'gemini',warning:null};this.emit();
  this.missionPromise=Promise.resolve(generated).then(spec=>finish(spec),error=>finish(fallback(),'IA indisponível: '+String(error.message).slice(0,140))).finally(()=>{this.missionPromise=null;});return this.missionPromise;
 }
 usePower(now=Date.now(),busy=false){if(busy)throw Error('Aguarde a fala terminar');if(now<this.nextPower)throw Error('Poder recarregando');this.nextPower=now+2500;let result='Efeito livre';const q=this.quest;if(q?.status==='active'){const distance=Math.hypot(this.position[0]-q.position[0],this.position[2]-q.position[2]);if(this.form!==q.form)result='A missão precisa de outra forma';else if(distance>4.5)result='Aproxime-se do pedido de ajuda';else {q.progress++;result='Objetivo progrediu';if(q.progress>=q.total){q.status='complete';this.completed++;this.nextMission=now+this.options.missionSeconds*1000;result='Missão concluída';}}}this.power={id:++this.sequence,form:this.form,name:POWERS[this.form].name,position:[...this.position],at:now,result};this.emit();return this.power;}
 tick(now=Date.now(),busy=false){if(busy)return;
  if(this.pending&&(this.pending.source==='operator'||now-this.lastTransform>=8000)){this.form=this.pending.form;this.pending=null;this.lastTransform=now;this.expires=this.form==='base'?Infinity:now+60000;this.nextTransform=now+this.options.transformSeconds*1000;this.emit();}
  if(this.pendingPower){if(now>this.pendingPower.expires)this.pendingPower=null;else if(this.pendingPower.form===this.form&&now>=this.nextPower){this.pendingPower=null;this.usePower(now);}}
  if(this.options.autoMissions&&now>=this.nextMission&&this.quest?.status!=='active')this.startMission(now);
  const q=this.quest;
  if(q?.status==='active'){
   if(this.options.autoTransform&&this.form!==q.form&&!this.pending&&now-q.started>=3000)this.requestTransform(q.form,'mission');
   if(this.options.autoPowers&&this.form===q.form&&now>=this.nextPower&&Math.hypot(this.position[0]-q.position[0],this.position[2]-q.position[2])<=4.5)this.usePower(now);
  }else if(!this.pending){if(this.form!=='base'&&now>=this.expires)this.requestTransform('base','watch-timeout');else if(this.options.autoTransform&&now>=this.nextTransform)this.requestTransform(FORM_IDS.filter(id=>id!=='nova')[(FORM_IDS.filter(id=>id!=='nova').indexOf(this.form)+1)%10],'automatic');}
 }
}
