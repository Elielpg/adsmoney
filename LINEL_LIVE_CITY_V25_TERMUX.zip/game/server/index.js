import http from 'node:http';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {EventHub,SpeechQueue,gemini,localReply,FORMS,DISTRICTS} from './core.js';
import {LiveAdapter} from './live.js';
const root=fileURLToPath(new URL('../',import.meta.url));const hub=new EventHub();const clients=new Set();
function broadcast(type,data){for(const c of clients)c.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`);}
const queue=new SpeechQueue({timeout:120000,onChange:s=>broadcast('queue',s)});const live=new LiveAdapter((e,s)=>hub.ingest(e,s),s=>broadcast('live',s));
let config={music:.15,voice:1,sfx:.3,quality:'balanced',giftRules:hub.giftRules,commandRules:hub.commandRules};
try{const saved=JSON.parse(await readFile(path.join(root,'data/config.json'),'utf8'));config={...config,...saved};if(Array.isArray(saved.giftRules))hub.giftRules=saved.giftRules;if(Array.isArray(saved.commandRules))hub.commandRules=saved.commandRules;}catch{}
const recent=new Map();
hub.listeners.add(e=>{broadcast('event',e);broadcast('ranking',hub.leaders());if(e.type==='comment'){
 const last=recent.get(e.user)||0;if(Date.now()-last<3000)return;recent.set(e.user,Date.now());if(recent.size>5000)recent.delete(recent.keys().next().value);
 queue.enqueue({user:e.user,prompt:e.text,source:e.source,priority:hub.ranking.get(e.user)?.giftCredit||0});const u=hub.ranking.get(e.user);if(u)u.giftCredit=Math.max(0,u.giftCredit-1);
 }});
async function body(req,limit=65536){let bytes=0;const parts=[];for await(const b of req){bytes+=b.length;if(bytes>limit)throw Error('Corpo excede o limite');parts.push(b);}return Buffer.concat(parts);}
function json(res,status,data){res.writeHead(status,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));}
export const server=http.createServer(async(req,res)=>{try{
 const url=new URL(req.url,'http://127.0.0.1');const p=url.pathname;
 if(req.headers.origin && !['http://127.0.0.1:'+port,'http://localhost:'+port].includes(req.headers.origin))return json(res,403,{error:'Origem não permitida'});
 if(p==='/events'){
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive'});clients.add(res);res.write(`event: ready\ndata: ${JSON.stringify({queue:queue.snapshot(),ranking:hub.leaders(),live:live.state})}\n\n`);const heartbeat=setInterval(()=>res.write(': ping\n\n'),15000);req.on('close',()=>{clearInterval(heartbeat);clients.delete(res);});return;
 }
 if(p==='/api/health')return json(res,200,{ok:true,node:process.version,geminiConfigured:!!process.env.GEMINI_API_KEY,live:live.state,forms:FORMS,districts:DISTRICTS,queue:queue.snapshot(),uptime:process.uptime()});
 if(p==='/api/config'&&req.method==='GET')return json(res,200,config);
 if(req.method==='POST'&&p.startsWith('/api/')){
  if(p==='/api/model'){
   const b=await body(req,20*1024*1024);if(b.length<20||b.toString('ascii',0,4)!=='glTF'||b.readUInt32LE(4)!==2||b.readUInt32LE(8)!==b.length)throw Error('GLB 2.0 inválido');
   const jsonLength=b.readUInt32LE(12);if(b.readUInt32LE(16)!==0x4e4f534a||jsonLength%4||jsonLength+20>b.length)throw Error('Chunk JSON GLB inválido');const document=JSON.parse(b.toString('utf8',20,20+jsonLength));if(document.asset?.version!=='2.0')throw Error('Asset GLB 2.0 ausente');if(document.buffers?.some(x=>x.uri)||document.images?.some(x=>x.uri))throw Error('GLB precisa incorporar buffers e texturas');
   await mkdir(path.join(root,'data/models'),{recursive:true});await writeFile(path.join(root,'data/models/avatar.glb'),b);return json(res,201,{url:'/models/avatar.glb',bytes:b.length,note:'GLB armazenado; carregamento disponível no painel.'});
  }
  const data=JSON.parse((await body(req)).toString()||'{}');
  if(p==='/api/event')return json(res,200,{event:hub.ingest(data,'demo')});
  if(p==='/api/ack')return json(res,200,{accepted:queue.ack(data.id)});
  if(p==='/api/connect'){await live.connect(String(data.username||''),data.provider);return json(res,200,live.state);}
  if(p==='/api/disconnect'){await live.disconnect();return json(res,200,live.state);}
  if(p==='/api/answer'){
   if(!queue.active||queue.active.id!==data.id)return json(res,409,{error:'Fala não ativa'});
   try{return json(res,200,{...await gemini(queue.active.prompt),mode:'gemini'});}catch(e){return json(res,200,{text:localReply(queue.active.prompt),mode:'local',warning:e.message});}
  }
  if(p==='/api/tts'){if(typeof data.text!=='string'||data.text.length>1000)throw Error('Texto inválido');return json(res,200,await gemini(data.text,{tts:true}));}
  if(p==='/api/config'){
   for(const k of ['music','voice','sfx'])if(data[k]!==undefined)config[k]=Math.max(0,Math.min(1,Number(data[k])||0));
   if(['economy','balanced','high'].includes(data.quality))config.quality=data.quality;
   if(data.giftRules){if(!Array.isArray(data.giftRules)||data.giftRules.length>50||data.giftRules.some(r=>typeof r.name!=='string'||!FORMS.includes(r.action)||!Number.isFinite(r.points)||r.points<0||r.points>10000))throw Error('Regras inválidas');config.giftRules=data.giftRules;hub.giftRules=data.giftRules;}
   if(data.commandRules){if(!Array.isArray(data.commandRules)||data.commandRules.length>50||data.commandRules.some(r=>typeof r.command!=='string'||!r.command.startsWith('/')||!FORMS.includes(r.action)))throw Error('Comandos inválidos');config.commandRules=data.commandRules;hub.commandRules=data.commandRules;}
   await mkdir(path.join(root,'data'),{recursive:true});await writeFile(path.join(root,'data/config.json'),JSON.stringify(config));return json(res,200,config);
  }
  return json(res,404,{error:'Rota inexistente'});
 }
 if(req.method!=='GET')return json(res,405,{error:'Método não permitido'});
 const base=p.startsWith('/models/')?path.join(root,'data'):path.join(root,'public');const file=path.resolve(base,'.'+decodeURIComponent(p==='/'?'/index.html':p));if(!file.startsWith(base+path.sep))return json(res,403,{error:'Caminho inválido'});
 const b=await readFile(file);res.writeHead(200,{'content-type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.glb':'model/gltf-binary'})[path.extname(file)]||'application/octet-stream','x-content-type-options':'nosniff'});res.end(b);
 }catch(e){json(res,e.code==='ENOENT'?404:400,{error:e.message});}});
const port=Number(process.env.PORT||3000);server.listen(port,'127.0.0.1',()=>console.log('LINEL V25 iniciado na porta '+port));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{queue.close();live.disconnect();for(const c of clients)c.end();server.close(()=>process.exit(0));});
