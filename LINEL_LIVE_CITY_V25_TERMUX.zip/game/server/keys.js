import {readFile,mkdir,writeFile,rename} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
export class KeyStore {
 constructor(file){this.file=file;this.entries=[];this.activeId=null;this.write=Promise.resolve();}
 async load(){try{const d=JSON.parse(await readFile(this.file,'utf8'));this.entries=d.entries||[];this.activeId=d.activeId;}catch(e){if(e.code!=='ENOENT')throw Error('Não foi possível ler as chaves locais');}return this;}
 status(){return {entries:this.entries.map(({id,label})=>({id,label,active:id===this.activeId})),environmentAvailable:!!process.env.GEMINI_API_KEY,activeId:this.activeId};}
 key(){return this.entries.find(e=>e.id===this.activeId)?.key||process.env.GEMINI_API_KEY;}
 async change(action,data){
  const operation=this.write.catch(()=>{}).then(async()=>{let entries=this.entries.map(e=>({...e})),activeId=this.activeId;
  if(action==='add'){if(entries.length>=20)throw Error('Limite de 20 chaves');if(typeof data.key!=='string'||!/^[-_a-zA-Z0-9]{20,200}$/.test(data.key))throw Error('Formato de chave inválido');if(entries.some(e=>e.key===data.key))throw Error('Essa chave já está cadastrada');const entry={id:randomUUID(),label:String(data.label||'Minha chave').slice(0,60),key:data.key};entries.push(entry);activeId??=entry.id;}
  else if(action==='select'){if(data.id!==null&&!entries.some(e=>e.id===data.id))throw Error('Chave não encontrada');activeId=data.id;}
  else if(action==='remove'){entries=entries.filter(e=>e.id!==data.id);if(activeId===data.id)activeId=null;}
  else throw Error('Ação inválida');
  await mkdir(path.dirname(this.file),{recursive:true,mode:0o700});const temp=this.file+'.tmp';await writeFile(temp,JSON.stringify({entries,activeId}),{mode:0o600});await rename(temp,this.file);this.entries=entries;this.activeId=activeId;return this.status();});this.write=operation;return operation;
 }
}
