import {addressedSpeaker,guardIdentity,personaSystem} from './personas.js';
import {classicContext,classicSystem,localClassicReply} from './classic.js';
import {SPEAKERS,speakerId} from '../public/characters.js';
import {namedTransformation,asksPower,asksMovement} from '../public/transformations.js';
import { randomUUID } from 'node:crypto';
export const FORMS=['base','blaze','volt','rock','shade','tide','nova','beast','fourarms','cannon','wildvine'];
export const DISTRICTS=['Praça Aurora','Jardim das Águas','Mercado Solar','Vila Cristal','Parque das Estrelas','Centro Cultural'];
export class EventHub {
 constructor(){this.seen=new Map();this.ranking=new Map();this.giftRules=[{name:'Rose',points:10,action:'blaze'},{name:'Galaxy',points:100,action:'nova'}];this.commandRules=[{command:'/chama',action:'blaze'},{command:'/humano',action:'base'},{command:'/xlr8',action:'volt'}];this.listeners=new Set();}
 ingest(input,source='demo'){
  if(!['comment','gift','like','follow','share','join'].includes(input.type))throw Error('Tipo de evento inválido');
  const id=String(input.id||randomUUID());if(this.seen.has(id))return null;
  if(this.seen.size>5000)this.seen.delete(this.seen.keys().next().value);this.seen.set(id,Date.now());
  const user=String(input.user||'Visitante').slice(0,40).replace(/[<>]/g,'');const text=String(input.text||'').slice(0,500);
  const count=Math.min(1000,Math.max(1,Number(input.count)||1));
  if(input.type==='gift'&&input.repeatEnd===false)return null;
  const rule=this.giftRules.find(r=>r.name.toLowerCase()===String(input.gift||'').toLowerCase());
  const points=input.type==='gift'?(rule?.points||5)*count:input.type==='like'?count:input.type==='follow'?5:1;
  const entry=this.ranking.get(user)||{user,points:0,giftCredit:0};entry.points+=points;if(input.type==='gift')entry.giftCredit=Math.min(3,entry.giftCredit+1);this.ranking.set(user,entry);
  const command=input.type==='comment'?this.commandRules.find(r=>r.command.toLowerCase()===text.trim().toLowerCase()):null;
  const event={id,type:input.type,user,text,gift:String(input.gift||''),count,points,action:command?.action||rule?.action||(input.type==='comment'?namedTransformation(text):null),movement:input.type==='comment'?asksMovement(text):null,speaker:input.type==='comment'?addressedSpeaker(text):null,mission:input.type==='comment'&&/^(?:ben[,! ]*)?(?:quero |nova |uma |pedir |iniciar )?miss[aã]o[!. ]*$/i.test(text.trim()),power:input.type==='comment'&&asksPower(text),source,time:Date.now()};if(event.speaker){event.action=null;event.power=false;event.mission=false;event.movement=null;}for(const f of this.listeners)f(event);return event;
 }
 leaders(){return [...this.ranking.values()].sort((a,b)=>b.points-a.points).slice(0,20);}
}
export class SpeechQueue {
 constructor({onChange=()=>{},timeout=45000}={}){this.items=[];this.active=null;this.onChange=onChange;this.timeout=timeout;this.timer=null;this.completed=0;this.turn=0;}
 enqueue(item){if(this.items.length>=50)return false;this.items.push({...item,id:randomUUID(),created:Date.now()});this.next();this.onChange(this.snapshot());return true;}
 next(){if(this.active||!this.items.length)return;this.turn++;this.items.sort((a,b)=>this.turn%3===0?a.created-b.created:(b.priority||0)-(a.priority||0)||a.created-b.created);this.active=this.items.shift();this.timer=setTimeout(()=>this.ack(this.active?.id),this.timeout);this.timer.unref?.();this.onChange(this.snapshot());}
 ack(id){if(!this.active||this.active.id!==id)return false;clearTimeout(this.timer);this.active=null;this.completed++;this.next();this.onChange(this.snapshot());return true;}
 snapshot(){return {active:this.active,waiting:this.items,completed:this.completed};}
 close(){clearTimeout(this.timer);}
}
export function wav(pcm){const b=Buffer.alloc(44);b.write('RIFF');b.writeUInt32LE(pcm.length+36,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(24000,24);b.writeUInt32LE(48000,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(pcm.length,40);return Buffer.concat([b,pcm]);}
let proxyDispatcher;
export async function providerFetch(url,options){if(!process.env.HTTPS_PROXY&&!process.env.HTTP_PROXY)return fetch(url,options);const {fetch:proxyFetch,EnvHttpProxyAgent}=await import('undici');proxyDispatcher??=new EnvHttpProxyAgent();return proxyFetch(url,{...options,dispatcher:proxyDispatcher});}
export async function gemini(text,{tts=false,fetcher=providerFetch,key=process.env.GEMINI_API_KEY,speaker='base',context={},system,json=false}={}){
 if(!key)throw Error('GEMINI_API_KEY ausente no servidor');
 const model=tts?(process.env.GEMINI_TTS_MODEL||'gemini-2.5-flash-preview-tts'):(process.env.GEMINI_MODEL||'gemini-2.5-flash');
 const profile=SPEAKERS[speakerId(speaker)];
 const body=tts?{contents:[{parts:[{text:'Fale em português brasileiro. Direção de voz: '+profile.direction+'\nTexto: '+text}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:profile.voice}}}}}:{systemInstruction:{parts:[{text:system||personaSystem(context.speaker)||classicSystem(context)}]},contents:[{role:'user',parts:[{text:system?text:'Referência local de continuidade (se relevante):\n'+classicContext(text)+'\nPergunta do espectador:\n'+text}]}],...(json?{generationConfig:{responseMimeType:'application/json',temperature:.95}}:{})};
 const start=Date.now();const r=await fetcher('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model)+':generateContent',{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},body:JSON.stringify(body),signal:AbortSignal.timeout(25000)});
 if(!r.ok)throw Error('Gemini HTTP '+r.status);const data=await r.json();const parts=data.candidates?.[0]?.content?.parts||[];
 if(tts){const audio=parts.find(p=>p.inlineData)?.inlineData;if(!audio||!audio.mimeType?.startsWith('audio/'))throw Error('Resposta sem áudio');const pcm=Buffer.from(audio.data,'base64');return {audio:(audio.mimeType.includes('L16')||audio.mimeType.includes('pcm')?wav(pcm):pcm).toString('base64'),mime:audio.mimeType.includes('L16')||audio.mimeType.includes('pcm')?'audio/wav':audio.mimeType,model,latency:Date.now()-start};}
 const answer=parts.map(p=>p.text||'').join('').trim();if(!answer)throw Error('Resposta vazia ou bloqueada');return {text:system?answer:guardIdentity(answer,context.speaker||context.form),model,latency:Date.now()-start};
}
export const localReply=localClassicReply;
